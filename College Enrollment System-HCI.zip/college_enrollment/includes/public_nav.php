<header class="public-nav">
    <a class="public-brand" href="<?= BASE_URL ?>/index.php" aria-label="UniPortal home">
        <span class="public-brand-icon"><i class="fas fa-graduation-cap" aria-hidden="true"></i></span>
        <span class="public-brand-name">UniPortal<small>College Enrollment</small></span>
    </a>

    <nav class="public-nav-links" aria-label="Main navigation">
        <a href="<?= BASE_URL ?>/index.php">Home</a>
        <a href="<?= basename($_SERVER["SCRIPT_NAME"]) === "login.php" ? "#announcements" : BASE_URL . "/login.php#announcements" ?>">Announcements</a>
        <a href="<?= basename($_SERVER["SCRIPT_NAME"]) === "login.php" ? "#quick-access" : BASE_URL . "/login.php#quick-access" ?>">Student Portal</a>
        <a href="<?= basename($_SERVER["SCRIPT_NAME"]) === "login.php" ? "#help" : BASE_URL . "/login.php#help" ?>">Help</a>
    </nav>

    <a class="public-apply-btn" href="<?= BASE_URL ?>/register.php">
        <i class="fas fa-user-plus" aria-hidden="true"></i>
        <span>Apply</span>
    </a>
</header>
