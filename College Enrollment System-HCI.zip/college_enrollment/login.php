<?php
require_once __DIR__ . "/includes/auth.php";

redirect_if_logged_in();

$error = "";
$email = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email    = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";

    if (!csrf_valid()) {
        $error = "Session expired. Please try again.";
    } elseif ($email === "" || $password === "") {
        $error = "Please enter your email and password.";
    } else {
        $user = attempt_login($pdo, $email, $password, "student");

        if ($user) {
            start_user_session($user);
            redirect(dashboard_url("student"));
        }
        $error = "Invalid email or password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Login | College Enrollment</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/auth.css?v=12">
    <script src="assets/js/password-toggle.js" defer></script>
    <script src="assets/js/dismiss-alerts.js" defer></script>
    <script src="assets/js/public-navigation.js" defer></script>
</head>
<body class="public-auth-page login-page">
<?php require __DIR__ . "/includes/public_nav.php"; ?>
<main class="login-layout">
    <section class="login-intro" aria-labelledby="university-name">
        <div class="login-university-brand">
            <span class="login-university-icon"><i class="fas fa-graduation-cap" aria-hidden="true"></i></span>
            <h1 id="university-name">Portal State University</h1>
        </div>
        <p class="login-system-name">Integrated Registration and Enrollment System</p>
        <h2>Your journey from application to enrollment starts here.</h2>
        <p class="login-intro-description">
            Apply for admission, check your application status, view examination information, and access your student portal in one place.
        </p>
    </section>

<div class="auth-card">
    <div class="auth-head">
        <div class="auth-icon"><i class="fas fa-graduation-cap"></i></div>
        <div>
            <h1>Student Login</h1>
            <p>UniPortal &middot; College Enrollment</p>
        </div>
    </div>

    <div class="auth-body">
        <?php if (isset($_GET["registered"])): ?>
            <div class="alert success">Account created! You can now log in.</div>
        <?php endif; ?>
        <?php if (isset($_GET["loggedout"])): ?>
            <div class="alert success" data-dismiss-after="3000">You have been logged out.</div>
        <?php endif; ?>
        <?php if ($error !== ""): ?>
            <div class="alert error"><?= e($error) ?></div>
        <?php endif; ?>

        <form method="POST" autocomplete="on">
            <?= csrf_field() ?>

            <div class="field">
                <label for="email">Email Address</label>
                <input type="email" id="email" name="email"
                       value="<?= e($email) ?>" required autofocus>
            </div>

            <div class="field">
                <label for="password">Password</label>
                <div class="password-input-wrap">
                    <input type="password" id="password" name="password" required>
                    <button class="password-toggle" type="button" aria-label="Show password"
                            aria-controls="password" aria-pressed="false" data-password-toggle>
                        <i class="fas fa-eye" aria-hidden="true"></i>
                    </button>
                </div>
            </div>

            <button type="submit" class="btn">Log In</button>
        </form>
    </div>

    <div class="auth-foot">
        New student? <a href="register.php">Create an account</a>
        <span class="sep">|</span>
        <a href="admin/login.php">Admin login</a>
    </div>
</div>
</main>
<section class="announcements-section" id="announcements" aria-labelledby="announcements-title">
    <div class="announcements-container">
        <p class="announcements-eyebrow">Stay informed</p>
        <h2 id="announcements-title">Announcements &amp; Admission Information</h2>

        <div class="announcements-card">
            <div class="announcements-card-heading">
                <i class="fa-regular fa-bell" aria-hidden="true"></i>
                <h3>What's New</h3>
            </div>
            <ol class="announcement-list">
                <li class="announcement-item">
                    <time datetime="2026-10-08">Oct 8, 2026</time>
                    <span class="announcement-dot" aria-hidden="true"></span>
                    <div class="announcement-copy">
                        <h4>New Admission &amp; Student Portal Landing Page</h4>
                        <p>The portal home page has been refreshed with an admission guide, separate application and student portal links, an improved login form, and quick access to student services.</p>
                    </div>
                </li>
                <li class="announcement-item">
                    <time datetime="2025-07-22">Jul 22, 2025</time>
                    <span class="announcement-dot" aria-hidden="true"></span>
                    <div class="announcement-copy">
                        <h4>LENS Account Integration for Gonzaga Campus</h4>
                        <p>Students from both the Andrews and Gonzaga campuses can now access and manage their LENS accounts directly through the portal.</p>
                    </div>
                </li>
                <li class="announcement-item">
                    <time datetime="2025-07-10">Jul 10, 2025</time>
                    <span class="announcement-dot" aria-hidden="true"></span>
                    <div class="announcement-copy">
                        <h4>Certificate of Enrollment</h4>
                        <p>Students can now view and print their Certificate of Enrollment directly from their portal.</p>
                    </div>
                </li>
                <li class="announcement-item">
                    <time datetime="2025-07-07">Jul 7, 2025</time>
                    <span class="announcement-dot" aria-hidden="true"></span>
                    <div class="announcement-copy">
                        <h4>Report Issue Button</h4>
                        <p>A new “Report Issue” button has been added for easier support requests.</p>
                    </div>
                </li>
                <li class="announcement-item">
                    <time datetime="2025-06-25">Jun 25, 2025</time>
                    <span class="announcement-dot" aria-hidden="true"></span>
                    <div class="announcement-copy">
                        <h4>Program Update for Pre-enrolled</h4>
                        <p>Pre-enrolled students may now update their program of choice, subject to pre-advising requirements.</p>
                    </div>
                </li>
            </ol>
        </div>
    </div>
</section>
<section class="quick-access-section" id="quick-access" aria-labelledby="quick-access-title">
    <div class="quick-access-container">
        <p class="announcements-eyebrow">Student Portal</p>
        <h2 id="quick-access-title">Quick Access</h2>
        <p class="quick-access-note">
            Items marked <span class="sign-in-badge"><i class="fas fa-lock" aria-hidden="true"></i> Sign-in</span>
            will ask you to log in first.
        </p>

        <div class="quick-access-grid">
            <a class="quick-access-card" href="register.php">
                <span class="quick-access-icon"><i class="fas fa-user-plus" aria-hidden="true"></i></span>
                <span class="quick-access-copy">
                    <strong>Create Account</strong>
                    <span>New applicants start here</span>
                </span>
            </a>
            <a class="quick-access-card" href="student/tracking.php">
                <span class="quick-access-icon"><i class="fas fa-wave-square" aria-hidden="true"></i></span>
                <span class="quick-access-copy">
                    <strong>Application &amp; Exam Status</strong>
                    <span>Schedule, result and admission</span>
                </span>
                <span class="quick-access-lock" aria-label="Sign-in required"><i class="fas fa-lock" aria-hidden="true"></i></span>
            </a>
            <a class="quick-access-card" href="student/enroll.php">
                <span class="quick-access-icon"><i class="far fa-clipboard" aria-hidden="true"></i></span>
                <span class="quick-access-copy">
                    <strong>Enrollment</strong>
                    <span>Enroll for the current term</span>
                </span>
                <span class="quick-access-lock" aria-label="Sign-in required"><i class="fas fa-lock" aria-hidden="true"></i></span>
            </a>
            <a class="quick-access-card" href="student/dashboard.php">
                <span class="quick-access-icon"><i class="fas fa-book" aria-hidden="true"></i></span>
                <span class="quick-access-copy">
                    <strong>My Subjects</strong>
                    <span>View your enrolled subjects</span>
                </span>
                <span class="quick-access-lock" aria-label="Sign-in required"><i class="fas fa-lock" aria-hidden="true"></i></span>
            </a>
        </div>
    </div>
</section>
<section class="help-section" id="help" aria-labelledby="help-title">
    <div class="help-container">
        <p class="announcements-eyebrow">Support</p>
        <h2 id="help-title">Need Help?</h2>
        <p class="help-intro">Here are a few quick answers to help you get started with the student portal.</p>

        <div class="help-grid">
            <article class="help-card">
                <span class="help-icon"><i class="fas fa-user-plus" aria-hidden="true"></i></span>
                <div>
                    <h3>Creating an account</h3>
                    <p>Select Apply or Create Account and register with your email address and a password.</p>
                    <a href="register.php">Create an account</a>
                </div>
            </article>
            <article class="help-card">
                <span class="help-icon"><i class="fas fa-right-to-bracket" aria-hidden="true"></i></span>
                <div>
                    <h3>Can't log in?</h3>
                    <p>Check that you entered the email address and password you used to register. If you still can't access your account, contact your campus admissions office for assistance.</p>
                </div>
            </article>
            <article class="help-card">
                <span class="help-icon"><i class="fas fa-graduation-cap" aria-hidden="true"></i></span>
                <div>
                    <h3>Finding student services</h3>
                    <p>After signing in, use Student Portal Quick Access to find application status, enrollment, and your subjects.</p>
                    <a href="#quick-access">View Student Portal Quick Access</a>
                </div>
            </article>
        </div>
    </div>
</section>
</body>
</html>
