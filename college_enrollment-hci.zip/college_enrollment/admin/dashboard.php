<?php
require_once __DIR__ . "/auth_check.php";

$totalStudents = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'student'")->fetchColumn();
$pending = (int) $pdo->query("SELECT COUNT(*) FROM enrollments WHERE status = 'pending'")->fetchColumn();
$approved = (int) $pdo->query("SELECT COUNT(*) FROM enrollments WHERE status = 'approved'")->fetchColumn();
$rejected = (int) $pdo->query("SELECT COUNT(*) FROM enrollments WHERE status = 'rejected'")->fetchColumn();

$recent = $pdo->query(
    "SELECT e.id, e.status, e.submitted_at, u.first_name, u.last_name, u.email,
            p.code AS program_code, ay.name AS academic_year
     FROM enrollments e
     JOIN users u ON u.id = e.student_id
     JOIN programs p ON p.id = e.program_id
     JOIN academic_years ay ON ay.id = e.academic_year_id
     ORDER BY e.submitted_at DESC, e.id DESC
     LIMIT 8"
)->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = "Dashboard";
$activeNav = "dashboard";
require __DIR__ . "/header.php";
?>

<section class="admin-welcome">
    <h2>Welcome back, <?= e($_SESSION["name"] ?? "Administrator") ?>.</h2>
    <p>Enrollment activity and application review at a glance.</p>
</section>

<section class="admin-stats">
    <div class="admin-stat"><p>Total students</p><strong><?= $totalStudents ?></strong><span>Registered student accounts</span></div>
    <div class="admin-stat"><p>Pending applications</p><strong><?= $pending ?></strong><span>Awaiting admissions review</span></div>
    <div class="admin-stat"><p>Approved applications</p><strong><?= $approved ?></strong><span>Approved enrollments</span></div>
    <div class="admin-stat"><p>Rejected applications</p><strong><?= $rejected ?></strong><span>Applications not approved</span></div>
</section>

<section class="admin-panel">
    <div class="admin-panel-head">
        <div><h2>Recent applications</h2><p>Latest enrollment submissions across all academic years.</p></div>
        <a href="applications.php">View application queue <i class="fas fa-arrow-right"></i></a>
    </div>
    <?php if ($recent): ?>
        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead><tr><th>Applicant</th><th>Program</th><th>Academic year</th><th>Submitted</th><th>Status</th><th></th></tr></thead>
                <tbody>
                <?php foreach ($recent as $app): ?>
                    <tr>
                        <td><?= e($app["first_name"] . " " . $app["last_name"]) ?><span class="subline"><?= e($app["email"]) ?></span></td>
                        <td><?= e($app["program_code"]) ?></td>
                        <td><?= e($app["academic_year"]) ?></td>
                        <td><?= e(date("M d, Y", strtotime($app["submitted_at"]))) ?></td>
                        <td><span class="admin-badge <?= e($app["status"]) ?>"><?= e($app["status"]) ?></span></td>
                        <td><a class="admin-btn small" href="review_application.php?id=<?= (int) $app["id"] ?>">Review</a></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="admin-empty">No enrollment applications have been submitted yet.</div>
    <?php endif; ?>
</section>

<?php require __DIR__ . "/footer.php"; ?>
