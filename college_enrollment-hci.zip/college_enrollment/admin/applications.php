<?php
require_once __DIR__ . "/auth_check.php";

$search = trim($_GET["search"] ?? "");
$status = $_GET["status"] ?? "all";
$validStatuses = ["all", "pending", "approved", "rejected"];
if (!in_array($status, $validStatuses, true)) {
    $status = "all";
}
$page = max(1, (int) ($_GET["page"] ?? 1));
$perPage = 25;
$where = ["1 = 1"];
$params = [];

if ($status !== "all") {
    $where[] = "e.status = ?";
    $params[] = $status;
}
if ($search !== "") {
    $where[] = "(u.first_name LIKE ? OR u.last_name LIKE ? OR u.email LIKE ?
                 OR p.name LIKE ? OR p.code LIKE ? OR ay.name LIKE ?)";
    $term = "%" . $search . "%";
    array_push($params, $term, $term, $term, $term, $term, $term);
}
$whereSql = implode(" AND ", $where);

$countStmt = $pdo->prepare(
    "SELECT COUNT(*) FROM enrollments e
     JOIN users u ON u.id = e.student_id
     JOIN programs p ON p.id = e.program_id
     JOIN academic_years ay ON ay.id = e.academic_year_id
     WHERE $whereSql"
);
$countStmt->execute($params);
$total = (int) $countStmt->fetchColumn();
$pages = max(1, (int) ceil($total / $perPage));
$page = min($page, $pages);
$offset = ($page - 1) * $perPage;

$stmt = $pdo->prepare(
    "SELECT e.id, e.status, e.submitted_at, e.year_level, e.semester,
            u.first_name, u.last_name, u.email, p.code AS program_code,
            p.name AS program_name, ay.name AS academic_year,
            (SELECT COUNT(*) FROM enrollment_requirements er
             WHERE er.enrollment_id = e.id AND er.file_path IS NOT NULL) AS uploaded_documents
     FROM enrollments e
     JOIN users u ON u.id = e.student_id
     JOIN programs p ON p.id = e.program_id
     JOIN academic_years ay ON ay.id = e.academic_year_id
     WHERE $whereSql
     ORDER BY CASE e.status WHEN 'pending' THEN 0 ELSE 1 END, e.submitted_at DESC, e.id DESC
     LIMIT $perPage OFFSET $offset"
);
$stmt->execute($params);
$applications = $stmt->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = "Applications";
$activeNav = "applications";
require __DIR__ . "/header.php";
?>

<section class="admin-panel">
    <div class="admin-panel-head">
        <div><h2>Application queue</h2><p><?= $total ?> application<?= $total === 1 ? "" : "s" ?> found. Pending applications appear first.</p></div>
    </div>
    <form method="GET" class="admin-form">
        <input type="search" name="search" value="<?= e($search) ?>" placeholder="Search student, program or academic year">
        <select name="status" aria-label="Filter by status">
            <?php foreach ($validStatuses as $option): ?>
                <option value="<?= e($option) ?>" <?= $status === $option ? "selected" : "" ?>><?= e(ucfirst($option)) ?></option>
            <?php endforeach; ?>
        </select>
        <button class="admin-btn" type="submit"><i class="fas fa-filter"></i> Filter</button>
        <?php if ($search !== "" || $status !== "all"): ?><a class="admin-btn secondary" href="applications.php">Clear</a><?php endif; ?>
    </form>

    <?php if ($applications): ?>
        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead><tr><th>Applicant</th><th>Program</th><th>Academic year</th><th>Level / semester</th><th>Documents</th><th>Submitted</th><th>Status</th><th></th></tr></thead>
                <tbody>
                <?php foreach ($applications as $app): ?>
                    <tr>
                        <td><?= e($app["first_name"] . " " . $app["last_name"]) ?><span class="subline"><?= e($app["email"]) ?></span></td>
                        <td><?= e($app["program_code"]) ?><span class="subline"><?= e($app["program_name"]) ?></span></td>
                        <td><?= e($app["academic_year"]) ?></td>
                        <td>Year <?= (int) $app["year_level"] ?><span class="subline"><?= e(ucfirst($app["semester"])) ?> semester</span></td>
                        <td><?= (int) $app["uploaded_documents"] ?> uploaded</td>
                        <td><?= e(date("M d, Y", strtotime($app["submitted_at"]))) ?></td>
                        <td><span class="admin-badge <?= e($app["status"]) ?>"><?= e($app["status"]) ?></span></td>
                        <td><a class="admin-btn small" href="review_application.php?id=<?= (int) $app["id"] ?>"><?= $app["status"] === "pending" ? "Review" : "View" ?></a></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="admin-pagination">
            <span>Page <?= $page ?> of <?= $pages ?></span>
            <div class="admin-actions">
                <?php if ($page > 1): ?><a class="admin-btn secondary small" href="?<?= e(http_build_query(["search" => $search, "status" => $status, "page" => $page - 1])) ?>">Previous</a><?php endif; ?>
                <?php if ($page < $pages): ?><a class="admin-btn secondary small" href="?<?= e(http_build_query(["search" => $search, "status" => $status, "page" => $page + 1])) ?>">Next</a><?php endif; ?>
            </div>
        </div>
    <?php else: ?>
        <div class="admin-empty">No applications matched these filters.</div>
    <?php endif; ?>
</section>

<?php require __DIR__ . "/footer.php"; ?>
