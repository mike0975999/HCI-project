<?php
require_once __DIR__ . "/auth_check.php";

$applicationId = (int) ($_GET["id"] ?? $_POST["application_id"] ?? 0);
if ($applicationId < 1) {
    header("Location: applications.php");
    exit;
}

$error = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $remarks = trim($_POST["remarks"] ?? "");
    $remarksLength = function_exists("mb_strlen") ? mb_strlen($remarks, "UTF-8") : strlen($remarks);

    if (!csrf_valid()) {
        $error = "Your session expired. Please try again.";
    } elseif ($remarksLength > 255) {
        $error = "Remarks must be 255 characters or fewer.";
    } else {
        $action = $_POST["action"] ?? "";
        try {
            $pdo->beginTransaction();
            $lock = $pdo->prepare("SELECT status FROM enrollments WHERE id = ? FOR UPDATE");
            $lock->execute([$applicationId]);
            $applicationStatus = $lock->fetchColumn();

            if ($applicationStatus === false) {
                $pdo->rollBack();
                http_response_code(404);
                exit("Application not found.");
            }
            if ($applicationStatus !== "pending") {
                $pdo->rollBack();
                $error = "This application has already been decided and can no longer be changed.";
            } elseif ($action === "review_document") {
                $documentId = (int) ($_POST["document_id"] ?? 0);
                $documentStatus = $_POST["document_status"] ?? "";
                if (!in_array($documentStatus, ["verified", "rejected"], true)) {
                    $error = "Choose a valid document review status.";
                } elseif ($documentStatus === "rejected" && $remarks === "") {
                    $error = "Add a reason before rejecting a document.";
                } else {
                    $document = $pdo->prepare(
                        "SELECT id FROM enrollment_requirements
                         WHERE id = ? AND enrollment_id = ? AND file_path IS NOT NULL
                         FOR UPDATE"
                    );
                    $document->execute([$documentId, $applicationId]);
                    if (!$document->fetchColumn()) {
                        $error = "The uploaded document could not be found.";
                    } else {
                        $update = $pdo->prepare(
                            "UPDATE enrollment_requirements SET status = ?, remarks = ?
                             WHERE id = ? AND enrollment_id = ?"
                        );
                        $update->execute([$documentStatus, $remarks !== "" ? $remarks : null, $documentId, $applicationId]);
                    }
                }
                if ($error !== "") {
                    $pdo->rollBack();
                } else {
                    $pdo->commit();
                    $_SESSION["admin_flash"] = ["success", "Document review saved."];
                    header("Location: review_application.php?id=" . $applicationId);
                    exit;
                }
            } elseif ($action === "decide_application") {
                $decision = $_POST["decision"] ?? "";
                if (!in_array($decision, ["approved", "rejected"], true)) {
                    $error = "Choose approve or reject.";
                } elseif ($decision === "rejected" && $remarks === "") {
                    $error = "Add a reason before rejecting an application.";
                } else {
                    if ($decision === "approved") {
                        $missing = $pdo->prepare(
                            "SELECT COUNT(*)
                             FROM requirements r
                             LEFT JOIN enrollment_requirements er
                               ON er.requirement_id = r.id AND er.enrollment_id = ?
                             WHERE r.is_required = 1
                               AND (er.id IS NULL OR er.status <> 'verified' OR er.file_path IS NULL)"
                        );
                        $missing->execute([$applicationId]);
                        if ((int) $missing->fetchColumn() > 0) {
                            $error = "Approval is blocked until every required document is uploaded and verified.";
                        }
                    }
                    if ($error !== "") {
                        $pdo->rollBack();
                    } else {
                        $update = $pdo->prepare(
                            "UPDATE enrollments
                             SET status = ?, remarks = ?, reviewed_by = ?, reviewed_at = NOW()
                             WHERE id = ? AND status = 'pending'"
                        );
                        $update->execute([$decision, $remarks !== "" ? $remarks : null, (int) $_SESSION["user_id"], $applicationId]);
                        if ($update->rowCount() !== 1) {
                            $pdo->rollBack();
                            $error = "The application changed while you were reviewing it. Reload and try again.";
                        } else {
                            $pdo->commit();
                            $_SESSION["admin_flash"] = ["success", "Application " . $decision . " successfully."];
                            header("Location: review_application.php?id=" . $applicationId);
                            exit;
                        }
                    }
                }
            } else {
                $pdo->rollBack();
                $error = "Unknown review action.";
            }
        } catch (PDOException $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $exception;
        }
    }
}

$stmt = $pdo->prepare(
    "SELECT e.*, u.first_name, u.last_name, u.email, u.status AS account_status,
            sp.student_number, sp.phone, sp.birthdate, sp.gender, sp.address,
            sp.guardian_name, sp.guardian_phone,
            p.code AS program_code, p.name AS program_name,
            ay.name AS academic_year
     FROM enrollments e
     JOIN users u ON u.id = e.student_id
     LEFT JOIN student_profiles sp ON sp.user_id = u.id
     JOIN programs p ON p.id = e.program_id
     JOIN academic_years ay ON ay.id = e.academic_year_id
     WHERE e.id = ?"
);
$stmt->execute([$applicationId]);
$app = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$app) {
    http_response_code(404);
    exit("Application not found.");
}

$docStmt = $pdo->prepare(
    "SELECT r.id AS requirement_id, r.name, r.description, r.is_required,
            er.id AS document_id, er.file_path, er.status AS document_status,
            er.remarks AS document_remarks, er.uploaded_at
     FROM requirements r
     LEFT JOIN enrollment_requirements er
       ON er.requirement_id = r.id AND er.enrollment_id = ?
     ORDER BY r.is_required DESC, r.id"
);
$docStmt->execute([$applicationId]);
$documents = $docStmt->fetchAll(PDO::FETCH_ASSOC);

$requiredCount = 0;
$verifiedCount = 0;
foreach ($documents as $document) {
    if ((int) $document["is_required"] === 1) {
        $requiredCount++;
        if ($document["document_status"] === "verified" && $document["file_path"]) {
            $verifiedCount++;
        }
    }
}

$pageTitle = "Review Application";
$activeNav = "applications";
require __DIR__ . "/header.php";
?>

<?php if ($error !== ""): ?><div class="admin-alert error"><?= e($error) ?></div><?php endif; ?>

<section class="admin-panel">
    <div class="admin-panel-head">
        <div>
            <h2>Application #<?= (int) $app["id"] ?></h2>
            <p><?= e($app["program_code"] . " · " . $app["program_name"]) ?>, academic year <?= e($app["academic_year"]) ?></p>
        </div>
        <span class="admin-badge <?= e($app["status"]) ?>"><?= e($app["status"]) ?></span>
    </div>
    <div class="admin-details">
        <div><span>Student</span><strong><?= e($app["first_name"] . " " . $app["last_name"]) ?></strong></div>
        <div><span>Email</span><strong><?= e($app["email"]) ?></strong></div>
        <div><span>Student number</span><strong><?= e($app["student_number"] ?? "Not assigned") ?></strong></div>
        <div><span>Phone</span><strong><?= e($app["phone"] ?? "Not provided") ?></strong></div>
        <div><span>Date of birth / gender</span><strong><?= e($app["birthdate"] ?? "—") ?> / <?= e($app["gender"] ?? "—") ?></strong></div>
        <div><span>Address</span><strong><?= e($app["address"] ?? "Not provided") ?></strong></div>
        <div><span>Guardian</span><strong><?= e($app["guardian_name"] ?? "Not provided") ?></strong></div>
        <div><span>Guardian phone</span><strong><?= e($app["guardian_phone"] ?? "Not provided") ?></strong></div>
        <div><span>Application details</span><strong>Year <?= (int) $app["year_level"] ?> · <?= e(ucfirst($app["semester"])) ?> semester</strong></div>
        <div><span>Submitted</span><strong><?= e(date("M d, Y H:i", strtotime($app["submitted_at"]))) ?></strong></div>
        <div><span>Required documents verified</span><strong><?= $verifiedCount ?> / <?= $requiredCount ?></strong></div>
        <div><span>Last reviewed</span><strong><?= $app["reviewed_at"] ? e(date("M d, Y H:i", strtotime($app["reviewed_at"]))) : "Not reviewed" ?></strong></div>
    </div>
    <?php if ($app["remarks"]): ?>
        <p class="admin-muted"><strong>Application remarks:</strong> <?= e($app["remarks"]) ?></p>
    <?php endif; ?>
</section>

<section class="admin-panel">
    <div class="admin-panel-head">
        <div><h2>Required documents</h2><p>Review each uploaded file. Only verified required documents qualify the application for approval.</p></div>
    </div>
    <?php foreach ($documents as $document): ?>
        <article class="admin-document">
            <div class="admin-document-head">
                <div>
                    <h3><?= e($document["name"]) ?><?= (int) $document["is_required"] ? "" : " (Optional)" ?></h3>
                    <p><?= e($document["description"] ?? "") ?></p>
                    <?php if ($document["document_id"] && $document["file_path"]): ?>
                        <p>Uploaded <?= e(date("M d, Y H:i", strtotime($document["uploaded_at"]))) ?> ·
                            <a href="<?= BASE_URL ?>/download.php?id=<?= (int) $document["document_id"] ?>" target="_blank" rel="noopener">Open document</a>
                        </p>
                    <?php endif; ?>
                    <?php if ($document["document_remarks"]): ?>
                        <p><strong>Previous review note:</strong> <?= e($document["document_remarks"]) ?></p>
                    <?php endif; ?>
                </div>
                <span class="admin-badge <?= e($document["document_status"] ?? "missing") ?>"><?= e($document["document_status"] ?? "missing") ?></span>
            </div>
            <?php if ($app["status"] === "pending" && $document["document_id"] && $document["file_path"]): ?>
                <form method="POST" class="admin-form">
                    <?= csrf_field() ?>
                    <input type="hidden" name="application_id" value="<?= (int) $app["id"] ?>">
                    <input type="hidden" name="document_id" value="<?= (int) $document["document_id"] ?>">
                    <input type="hidden" name="action" value="review_document">
                    <input type="text" name="remarks" maxlength="255" value="<?= e($document["document_remarks"] ?? "") ?>" placeholder="Note or rejection reason (max 255 chars)">
                    <button class="admin-btn small" type="submit" name="document_status" value="verified">Verify</button>
                    <button class="admin-btn danger small" type="submit" name="document_status" value="rejected">Reject</button>
                </form>
            <?php elseif (!$document["file_path"]): ?>
                <p class="admin-muted">No file uploaded.</p>
            <?php endif; ?>
        </article>
    <?php endforeach; ?>
</section>

<section class="admin-panel">
    <div class="admin-panel-head"><div><h2>Application decision</h2><p>Rejection requires a reason. Approval is enabled only after required documents are verified.</p></div></div>
    <?php if ($app["status"] === "pending"): ?>
        <form method="POST">
            <?= csrf_field() ?>
            <input type="hidden" name="application_id" value="<?= (int) $app["id"] ?>">
            <input type="hidden" name="action" value="decide_application">
            <div class="admin-field">
                <label for="remarks">Remarks for student (optional for approval, required for rejection)</label>
                <textarea id="remarks" name="remarks" maxlength="255" rows="3"><?= e($app["remarks"] ?? "") ?></textarea>
            </div>
            <?php if ($verifiedCount < $requiredCount): ?>
                <p class="admin-error-text">Approval unavailable until all required documents are verified.</p>
            <?php endif; ?>
            <div class="admin-actions">
                <button class="admin-btn" type="submit" name="decision" value="approved" <?= $verifiedCount < $requiredCount ? "disabled" : "" ?>>
                    <i class="fas fa-check"></i> Approve application
                </button>
                <button class="admin-btn danger" type="submit" name="decision" value="rejected">
                    <i class="fas fa-xmark"></i> Reject application
                </button>
                <a class="admin-btn secondary" href="applications.php">Back to applications</a>
            </div>
        </form>
    <?php else: ?>
        <p class="admin-muted">This application is finalized and cannot be changed here.</p>
        <a class="admin-btn secondary" href="applications.php">Back to applications</a>
    <?php endif; ?>
</section>

<?php require __DIR__ . "/footer.php"; ?>
