<?php
require_once __DIR__ . "/includes/auth.php";

redirect_if_logged_in();

$error = "";
$email = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email    = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";

    if (!csrf_valid()) {
        $error = "Session expired. Please try again.";
    } elseif ($email === "" || $password === "") {
        $error = "Please enter your email and password.";
    } else {
        $user = attempt_login($pdo, $email, $password, "student");

        if ($user) {
            start_user_session($user);
            redirect(dashboard_url("student"));
        }
        $error = "Invalid email or password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Login | College Enrollment</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/auth.css">
    <script src="assets/js/password-toggle.js" defer></script>
    <script src="assets/js/dismiss-alerts.js" defer></script>
</head>
<body>
<div class="auth-card">
    <div class="auth-head">
        <div class="auth-icon"><i class="fas fa-graduation-cap"></i></div>
        <div>
            <h1>Student Login</h1>
            <p>UniPortal &middot; College Enrollment</p>
        </div>
    </div>

    <div class="auth-body">
        <?php if (isset($_GET["registered"])): ?>
            <div class="alert success">Account created! You can now log in.</div>
        <?php endif; ?>
        <?php if (isset($_GET["loggedout"])): ?>
            <div class="alert success" data-dismiss-after="3000">You have been logged out.</div>
        <?php endif; ?>
        <?php if ($error !== ""): ?>
            <div class="alert error"><?= e($error) ?></div>
        <?php endif; ?>

        <form method="POST" autocomplete="on">
            <?= csrf_field() ?>

            <div class="field">
                <label for="email">Email Address</label>
                <input type="email" id="email" name="email"
                       value="<?= e($email) ?>" required autofocus>
            </div>

            <div class="field">
                <label for="password">Password</label>
                <div class="password-input-wrap">
                    <input type="password" id="password" name="password" required>
                    <button class="password-toggle" type="button" aria-label="Show password"
                            aria-controls="password" aria-pressed="false" data-password-toggle>
                        <i class="fas fa-eye" aria-hidden="true"></i>
                    </button>
                </div>
            </div>

            <button type="submit" class="btn">Log In</button>
        </form>
    </div>

    <div class="auth-foot">
        New student? <a href="register.php">Create an account</a>
        <span class="sep">|</span>
        <a href="admin/login.php">Admin login</a>
    </div>
</div>
</body>
</html>
