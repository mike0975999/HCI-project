<?php
require_once __DIR__ . "/includes/auth.php";

redirect_if_logged_in();

$error = "";
$old = ["first_name" => "", "last_name" => "", "email" => "", "phone" => ""];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    foreach ($old as $key => $_) {
        $old[$key] = trim($_POST[$key] ?? "");
    }
    $password = $_POST["password"] ?? "";
    $confirm  = $_POST["confirm_password"] ?? "";

    if (!csrf_valid()) {
        $error = "Session expired. Please try again.";
    } elseif ($old["first_name"] === "" || $old["last_name"] === ""
              || $old["email"] === "" || $password === "") {
        $error = "Please fill in all required fields.";
    } elseif (!filter_var($old["email"], FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } elseif ($old["phone"] !== "" && !preg_match('/^[0-9+\-\s()]{7,20}$/', $old["phone"])) {
        $error = "Please enter a valid phone number.";
    } elseif (strlen($password) < 8) {
        $error = "Password must be at least 8 characters.";
    } elseif ($password !== $confirm) {
        $error = "Passwords do not match.";
    } else {
        try {
            $pdo->beginTransaction();

            // Role is always 'student' for self-registration.
            $stmt = $pdo->prepare(
                "INSERT INTO users (first_name, last_name, email, password, role)
                 VALUES (?, ?, ?, ?, 'student')"
            );
            $stmt->execute([
                $old["first_name"],
                $old["last_name"],
                $old["email"],
                password_hash($password, PASSWORD_DEFAULT),
            ]);
            $user_id = (int) $pdo->lastInsertId();

            // Auto-generate a student number like 2026-0003
            $student_number = date("Y") . "-" . str_pad((string) $user_id, 4, "0", STR_PAD_LEFT);
            $check = $pdo->prepare("SELECT 1 FROM student_profiles WHERE student_number = ?");
            $check->execute([$student_number]);
            if ($check->fetchColumn()) {
                $student_number .= "-" . $user_id;
            }

            $stmt = $pdo->prepare(
                "INSERT INTO student_profiles (user_id, student_number, phone)
                 VALUES (?, ?, ?)"
            );
            $stmt->execute([$user_id, $student_number, $old["phone"] ?: null]);

            $pdo->commit();
            redirect(BASE_URL . "/login.php?registered=1");

        } catch (PDOException $ex) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = $ex->getCode() === "23000"
                ? "That email address is already registered."
                : "Unable to create your account. Please try again.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration | College Enrollment</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/auth.css">
</head>
<body>
<div class="auth-card wide">
    <div class="auth-head">
        <div class="auth-icon"><i class="fas fa-user-plus"></i></div>
        <div>
            <h1>Create Student Account</h1>
            <p>Register to start your enrollment</p>
        </div>
    </div>

    <div class="auth-body">
        <?php if ($error !== ""): ?>
            <div class="alert error"><?= e($error) ?></div>
        <?php endif; ?>

        <form method="POST" autocomplete="on">
            <?= csrf_field() ?>

            <div class="form-row">
                <div class="field">
                    <label for="first_name">First Name *</label>
                    <input type="text" id="first_name" name="first_name"
                           value="<?= e($old["first_name"]) ?>" maxlength="100" required>
                </div>
                <div class="field">
                    <label for="last_name">Last Name *</label>
                    <input type="text" id="last_name" name="last_name"
                           value="<?= e($old["last_name"]) ?>" maxlength="100" required>
                </div>
            </div>

            <div class="form-row">
                <div class="field">
                    <label for="email">Email Address *</label>
                    <input type="email" id="email" name="email"
                           value="<?= e($old["email"]) ?>" maxlength="150" required>
                </div>
                <div class="field">
                    <label for="phone">Phone Number</label>
                    <input type="text" id="phone" name="phone"
                           value="<?= e($old["phone"]) ?>" maxlength="20">
                </div>
            </div>

            <div class="form-row">
                <div class="field">
                    <label for="password">Password *</label>
                    <input type="password" id="password" name="password" minlength="8" required>
                    <p class="hint">At least 8 characters.</p>
                </div>
                <div class="field">
                    <label for="confirm_password">Confirm Password *</label>
                    <input type="password" id="confirm_password" name="confirm_password" minlength="8" required>
                </div>
            </div>

            <button type="submit" class="btn">Create Account</button>
        </form>
    </div>

    <div class="auth-foot">
        Already have an account? <a href="login.php">Log in</a>
    </div>
</div>
</body>
</html>
