<?php
require_once __DIR__ . "/includes/auth.php";

$wasAdmin = ($_SESSION["role"] ?? "") === "admin";
logout_user();

redirect(BASE_URL . ($wasAdmin ? "/admin/login.php" : "/login.php") . "?loggedout=1");
