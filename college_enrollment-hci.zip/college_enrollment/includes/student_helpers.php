<?php
/**
 * Shared helpers for the student portal (Phase 4).
 */

require_once __DIR__ . "/auth.php";

/* ---------- flash messages (shown once after a redirect) ---------- */

function flash(string $type, string $message): void
{
    $_SESSION["flash"][] = [$type, $message];
}

function flash_render(): string
{
    $html = "";
    foreach ($_SESSION["flash"] ?? [] as [$type, $message]) {
        $html .= '<div class="sp-alert ' . e($type) . '">' . e($message) . '</div>';
    }
    unset($_SESSION["flash"]);
    return $html;
}

/** Character count that works even if the mbstring extension is off. */
function text_len(string $value): int
{
    return function_exists("mb_strlen") ? mb_strlen($value, "UTF-8") : strlen($value);
}

/* ---------- data helpers ---------- */

function get_active_year(PDO $pdo): ?array
{
    $row = $pdo->query(
        "SELECT * FROM academic_years WHERE is_active = 1
         ORDER BY start_date DESC LIMIT 1"
    )->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

/** Returns user + profile fields; creates the profile row if it is missing. */
function get_profile(PDO $pdo, int $userId): array
{
    $sql = "SELECT u.first_name, u.last_name, u.email,
                   sp.id AS profile_id, sp.student_number, sp.phone, sp.birthdate,
                   sp.gender, sp.address, sp.guardian_name, sp.guardian_phone
            FROM users u
            LEFT JOIN student_profiles sp ON sp.user_id = u.id
            WHERE u.id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$userId]);
    $profile = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($profile && $profile["profile_id"] === null) {
        $number = date("Y") . "-" . str_pad((string) $userId, 4, "0", STR_PAD_LEFT);
        try {
            $pdo->prepare("INSERT INTO student_profiles (user_id, student_number) VALUES (?, ?)")
                ->execute([$userId, $number]);
        } catch (PDOException $ex) {
            $pdo->prepare("INSERT INTO student_profiles (user_id, student_number) VALUES (?, ?)")
                ->execute([$userId, $number . "-" . $userId]);
        }
        $stmt->execute([$userId]);
        $profile = $stmt->fetch(PDO::FETCH_ASSOC);
    }
    return $profile;
}

/** Fields a student must fill in before applying. */
function profile_required_fields(): array
{
    return [
        "birthdate" => "Date of birth",
        "gender"    => "Gender",
        "address"   => "Home address",
    ];
}

/** Returns [percent complete, list of missing field labels] for all profile fields. */
function profile_completion(array $profile): array
{
    $fields = [
        "phone"          => "Phone number",
        "birthdate"      => "Date of birth",
        "gender"         => "Gender",
        "address"        => "Home address",
        "guardian_name"  => "Guardian name",
        "guardian_phone" => "Guardian phone",
    ];
    $missing = [];
    foreach ($fields as $key => $label) {
        if (trim((string) ($profile[$key] ?? "")) === "") {
            $missing[] = $label;
        }
    }
    $percent = (int) round((count($fields) - count($missing)) / count($fields) * 100);
    return [$percent, $missing];
}

function profile_ready_to_enroll(array $profile): bool
{
    foreach (array_keys(profile_required_fields()) as $key) {
        if (trim((string) ($profile[$key] ?? "")) === "") {
            return false;
        }
    }
    return true;
}

/** All of a student's applications, newest first. */
function get_enrollments(PDO $pdo, int $userId): array
{
    $stmt = $pdo->prepare(
        "SELECT e.*, p.code AS program_code, p.name AS program_name,
                ay.name AS academic_year
         FROM enrollments e
         JOIN programs p        ON p.id  = e.program_id
         JOIN academic_years ay ON ay.id = e.academic_year_id
         WHERE e.student_id = ?
         ORDER BY e.submitted_at DESC, e.id DESC"
    );
    $stmt->execute([$userId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/** The application the student is currently working on (latest one). */
function get_current_enrollment(PDO $pdo, int $userId): ?array
{
    $all = get_enrollments($pdo, $userId);
    return $all[0] ?? null;
}

/** [required total, required submitted (not rejected), required verified] */
function requirement_progress(PDO $pdo, int $enrollmentId): array
{
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) AS total,
                COALESCE(SUM(er.id IS NOT NULL AND er.status <> 'rejected'), 0) AS submitted,
                COALESCE(SUM(er.status = 'verified'), 0) AS verified
         FROM requirements r
         LEFT JOIN enrollment_requirements er
                ON er.requirement_id = r.id AND er.enrollment_id = ?
         WHERE r.is_required = 1"
    );
    $stmt->execute([$enrollmentId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return [(int) $row["total"], (int) $row["submitted"], (int) $row["verified"]];
}

function status_badge(string $status): string
{
    return '<span class="sp-badge ' . e($status) . '">' . e(ucfirst($status)) . '</span>';
}

/* ---------- file uploads ---------- */

const UPLOAD_DIR_NAME = "uploads";
const UPLOAD_MAX_BYTES = 5 * 1024 * 1024; // 5 MB
const UPLOAD_TYPES = [
    "application/pdf" => "pdf",
    "image/jpeg"      => "jpg",
    "image/png"       => "png",
];

function upload_dir(): string
{
    $dir = dirname(__DIR__) . DIRECTORY_SEPARATOR . UPLOAD_DIR_NAME;
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    return $dir;
}

/** Delete a stored upload (path is the value kept in file_path). Safe against odd paths. */
function delete_stored_file(?string $relativePath): void
{
    if (!$relativePath) {
        return;
    }
    $base = realpath(upload_dir());
    $full = realpath(dirname(__DIR__) . DIRECTORY_SEPARATOR . $relativePath);
    if ($base && $full && strpos($full, $base . DIRECTORY_SEPARATOR) === 0 && is_file($full)) {
        @unlink($full);
    }
}
