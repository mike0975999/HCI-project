<?php
/**
 * Authentication helpers: sessions, login, role checks, CSRF.
 * Include this at the very top of any page that needs login or role checks.
 */

require_once __DIR__ . "/../config/database.php";

// URL of the project folder inside htdocs (change if you rename the folder)
define("BASE_URL", "/college_enrollment");

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        "httponly" => true,
        "samesite" => "Lax",
    ]);
    session_start();
}

function e(?string $value): string
{
    return htmlspecialchars($value ?? "", ENT_QUOTES, "UTF-8");
}

function is_logged_in(): bool
{
    return isset($_SESSION["user_id"], $_SESSION["role"]);
}

function session_account_is_active(): bool
{
    global $pdo;

    $stmt = $pdo->prepare("SELECT role, status FROM users WHERE id = ? LIMIT 1");
    $stmt->execute([(int) $_SESSION["user_id"]]);
    $account = $stmt->fetch(PDO::FETCH_ASSOC);

    return $account
        && $account["status"] === "active"
        && $account["role"] === $_SESSION["role"];
}

function dashboard_url(string $role): string
{
    return BASE_URL . ($role === "admin"
        ? "/admin/dashboard.php"
        : "/student/dashboard.php");
}

function redirect(string $url): void
{
    header("Location: " . $url);
    exit;
}

/** Send logged-in users straight to their own dashboard. */
function redirect_if_logged_in(): void
{
    if (is_logged_in()) {
        redirect(dashboard_url($_SESSION["role"]));
    }
}

/** Page requires any logged-in user. */
function require_login(string $loginPage = "/login.php"): void
{
    if (!is_logged_in()) {
        redirect(BASE_URL . $loginPage);
    }

    if (!session_account_is_active()) {
        logout_user();
        redirect(BASE_URL . $loginPage);
    }
}

/** Page requires a specific role. Wrong role goes to their own dashboard. */
function require_role(string $role): void
{
    if (!is_logged_in()) {
        redirect(BASE_URL . ($role === "admin" ? "/admin/login.php" : "/login.php"));
    }

    if (!session_account_is_active()) {
        $loginPage = $_SESSION["role"] === "admin" ? "/admin/login.php" : "/login.php";
        logout_user();
        redirect(BASE_URL . $loginPage);
    }

    if ($_SESSION["role"] !== $role) {
        redirect(dashboard_url($_SESSION["role"]));
    }
}

/**
 * Check credentials for the given role.
 * Returns the user row on success, or null on failure.
 */
function attempt_login(PDO $pdo, string $email, string $password, string $role): ?array
{
    $stmt = $pdo->prepare(
        "SELECT id, first_name, last_name, email, password, role, status
         FROM users WHERE email = ? LIMIT 1"
    );
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Always run password_verify so response time does not reveal
    // whether the email exists.
    $hash = $user["password"] ?? password_hash("dummy-password", PASSWORD_DEFAULT);
    $valid = password_verify($password, $hash);

    if (!$user || !$valid || $user["role"] !== $role || $user["status"] !== "active") {
        return null;
    }

    if (password_needs_rehash($user["password"], PASSWORD_DEFAULT)) {
        $upd = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
        $upd->execute([password_hash($password, PASSWORD_DEFAULT), $user["id"]]);
    }

    return $user;
}

function start_user_session(array $user): void
{
    session_regenerate_id(true);
    $_SESSION["user_id"] = (int) $user["id"];
    $_SESSION["role"]    = $user["role"];
    $_SESSION["name"]    = $user["first_name"] . " " . $user["last_name"];
    $_SESSION["email"]   = $user["email"];
}

function logout_user(): void
{
    $_SESSION = [];
    if (ini_get("session.use_cookies")) {
        $p = session_get_cookie_params();
        setcookie(session_name(), "", time() - 42000,
            $p["path"], $p["domain"], $p["secure"], $p["httponly"]);
    }
    session_destroy();
}

/* ---------- CSRF protection for forms ---------- */

function csrf_token(): string
{
    if (empty($_SESSION["csrf"])) {
        $_SESSION["csrf"] = bin2hex(random_bytes(32));
    }
    return $_SESSION["csrf"];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . csrf_token() . '">';
}

function csrf_valid(): bool
{
    return isset($_POST["csrf"], $_SESSION["csrf"])
        && hash_equals($_SESSION["csrf"], $_POST["csrf"]);
}
