<?php
/**
 * Student portal layout (top half). Set these before including:
 *   $pageTitle  - heading shown in the top bar
 *   $activeNav  - dashboard | profile | enroll | requirements | tracking
 */
require_once __DIR__ . "/student_helpers.php";
require_role("student");

// Buffer output so pages can still redirect after this header has been included.
ob_start();

$pageTitle = $pageTitle ?? "Student Portal";
$activeNav = $activeNav ?? "";
$initial   = strtoupper(substr($_SESSION["name"], 0, 1));

$nav = [
    "dashboard"    => ["/student/dashboard.php",    "fa-house",            "Dashboard"],
    "profile"      => ["/student/profile.php",      "fa-user",             "My Profile"],
    "enroll"       => ["/student/enroll.php",       "fa-file-signature",   "Enroll"],
    "requirements" => ["/student/requirements.php", "fa-folder-open",      "Requirements"],
    "tracking"     => ["/student/tracking.php",     "fa-route",            "Track Enrollment"],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?> | College Enrollment</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/student.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/confirm.css">
    <script src="<?= BASE_URL ?>/assets/js/logout-confirm.js" defer></script>
</head>
<body>
<div class="dashboard">

    <aside class="sidebar">
        <div class="brand">
            <div class="brand-icon"><i class="fas fa-graduation-cap"></i></div>
            <div><h2>UniPortal</h2><span>Student Portal</span></div>
        </div>

        <div class="menu-label">MAIN MENU</div>
        <nav>
            <?php foreach ($nav as $key => [$href, $icon, $label]): ?>
                <a href="<?= BASE_URL . $href ?>"
                   class="nav-link<?= $key === $activeNav ? " active" : "" ?>">
                    <i class="fas <?= $icon ?>"></i><span><?= $label ?></span>
                </a>
            <?php endforeach; ?>
        </nav>

        <div class="menu-label">ACCOUNT</div>
        <nav>
            <a href="<?= BASE_URL ?>/logout.php" class="nav-link" data-confirm-logout>
                <i class="fas fa-right-from-bracket"></i><span>Log Out</span>
            </a>
        </nav>

        <div class="sidebar-bottom">
            <div class="profile">
                <div class="avatar"><?= e($initial) ?></div>
                <div><strong><?= e($_SESSION["name"]) ?></strong><span>Student</span></div>
            </div>
        </div>
    </aside>

    <dialog class="confirm-dialog" id="logout-confirm-dialog" aria-labelledby="logout-confirm-title" aria-describedby="logout-confirm-message">
        <div class="confirm-icon"><i class="fas fa-right-from-bracket" aria-hidden="true"></i></div>
        <h2 id="logout-confirm-title">Log out?</h2>
        <p id="logout-confirm-message">Are you sure you want to log out of your account?</p>
        <div class="confirm-actions">
            <button type="button" class="confirm-button secondary" data-cancel-logout>Stay logged in</button>
            <button type="button" class="confirm-button primary" data-accept-logout>Log out</button>
        </div>
    </dialog>

    <main class="main-content">
        <header class="topbar">
            <div>
                <p class="breadcrumb">Student / <?= e($pageTitle) ?></p>
                <h1><?= e($pageTitle) ?></h1>
            </div>
        </header>

        <?= flash_render() ?>
