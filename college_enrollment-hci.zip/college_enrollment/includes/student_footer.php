        <footer>© 2026 UniPortal. College Enrollment Management System.</footer>
    </main>
</div>
</body>
</html>
