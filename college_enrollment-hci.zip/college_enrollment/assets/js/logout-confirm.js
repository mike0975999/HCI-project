(() => {
    const dialog = document.getElementById("logout-confirm-dialog");
    const cancelButton = dialog?.querySelector("[data-cancel-logout]");
    const acceptButton = dialog?.querySelector("[data-accept-logout]");

    if (!dialog || !cancelButton || !acceptButton) {
        return;
    }

    let logoutUrl = "";

    document.querySelectorAll("[data-confirm-logout]").forEach((link) => {
        link.addEventListener("click", (event) => {
            event.preventDefault();
            logoutUrl = link.href;
            dialog.showModal();
            cancelButton.focus();
        });
    });

    cancelButton.addEventListener("click", () => {
        logoutUrl = "";
        dialog.close();
    });

    acceptButton.addEventListener("click", () => {
        if (logoutUrl) {
            window.location.assign(logoutUrl);
        }
    });
})();
