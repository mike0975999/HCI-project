-- =====================================================================
-- College Enrollment System  |  Phase 2: Database Development
-- Import via phpMyAdmin: Import tab -> choose this file -> Go
-- Engine: InnoDB (required for foreign keys) | Charset: utf8mb4
-- =====================================================================

CREATE DATABASE IF NOT EXISTS college_enrollment
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE college_enrollment;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS enrollment_requirements;
DROP TABLE IF EXISTS enrollments;
DROP TABLE IF EXISTS requirements;
DROP TABLE IF EXISTS programs;
DROP TABLE IF EXISTS academic_years;
DROP TABLE IF EXISTS student_profiles;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------------------
-- 1. users  (students and admins share one login table; role decides access)
-- ---------------------------------------------------------------------
CREATE TABLE users (
    id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    first_name  VARCHAR(100) NOT NULL,
    last_name   VARCHAR(100) NOT NULL,
    email       VARCHAR(150) NOT NULL,
    password    VARCHAR(255) NOT NULL,              -- password_hash() output
    role        ENUM('student','admin') NOT NULL DEFAULT 'student',
    status      ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_users_email (email),
    KEY idx_users_role (role)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 2. student_profiles  (1-to-1 with users where role = 'student')
-- ---------------------------------------------------------------------
CREATE TABLE student_profiles (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id         INT UNSIGNED NOT NULL,
    student_number  VARCHAR(30) NOT NULL,
    phone           VARCHAR(30) NULL,
    birthdate       DATE NULL,
    gender          ENUM('male','female','other') NULL,
    address         VARCHAR(255) NULL,
    guardian_name   VARCHAR(150) NULL,
    guardian_phone  VARCHAR(30) NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_profiles_user (user_id),
    UNIQUE KEY uq_profiles_student_number (student_number),
    CONSTRAINT fk_profiles_user
        FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 3. academic_years
-- ---------------------------------------------------------------------
CREATE TABLE academic_years (
    id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    name        VARCHAR(20) NOT NULL,               -- e.g. 2026-2027
    start_date  DATE NOT NULL,
    end_date    DATE NOT NULL,
    is_active   TINYINT(1) NOT NULL DEFAULT 0,      -- enrollment open for this year
    created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_academic_years_name (name)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 4. programs
-- ---------------------------------------------------------------------
CREATE TABLE programs (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    code            VARCHAR(20) NOT NULL,           -- e.g. BSIT
    name            VARCHAR(150) NOT NULL,
    description     TEXT NULL,
    department      VARCHAR(100) NULL,
    duration_years  TINYINT UNSIGNED NOT NULL DEFAULT 4,
    slots           INT UNSIGNED NOT NULL DEFAULT 100,
    is_active       TINYINT(1) NOT NULL DEFAULT 1,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_programs_code (code),
    UNIQUE KEY uq_programs_name (name)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 5. requirements  (master list of documents a student must submit)
-- ---------------------------------------------------------------------
CREATE TABLE requirements (
    id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    name         VARCHAR(150) NOT NULL,
    description  VARCHAR(255) NULL,
    is_required  TINYINT(1) NOT NULL DEFAULT 1,
    created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_requirements_name (name)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 6. enrollments  (one application per student per academic year)
-- ---------------------------------------------------------------------
CREATE TABLE enrollments (
    id                INT UNSIGNED NOT NULL AUTO_INCREMENT,
    student_id        INT UNSIGNED NOT NULL,        -- users.id
    program_id        INT UNSIGNED NOT NULL,
    academic_year_id  INT UNSIGNED NOT NULL,
    year_level        TINYINT UNSIGNED NOT NULL DEFAULT 1,
    semester          ENUM('1st','2nd','summer') NOT NULL DEFAULT '1st',
    status            ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
    remarks           VARCHAR(255) NULL,            -- admin note, e.g. rejection reason
    reviewed_by       INT UNSIGNED NULL,            -- users.id of the admin
    reviewed_at       DATETIME NULL,
    submitted_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_enrollment_student_year (student_id, academic_year_id),
    KEY idx_enrollments_status (status),
    KEY idx_enrollments_program (program_id),
    CONSTRAINT fk_enrollments_student
        FOREIGN KEY (student_id) REFERENCES users(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_enrollments_program
        FOREIGN KEY (program_id) REFERENCES programs(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_enrollments_year
        FOREIGN KEY (academic_year_id) REFERENCES academic_years(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_enrollments_reviewer
        FOREIGN KEY (reviewed_by) REFERENCES users(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 7. enrollment_requirements  (documents submitted per application)
-- ---------------------------------------------------------------------
CREATE TABLE enrollment_requirements (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    enrollment_id   INT UNSIGNED NOT NULL,
    requirement_id  INT UNSIGNED NOT NULL,
    file_path       VARCHAR(255) NULL,
    status          ENUM('submitted','verified','rejected') NOT NULL DEFAULT 'submitted',
    remarks         VARCHAR(255) NULL,
    uploaded_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_enrollment_requirement (enrollment_id, requirement_id),
    CONSTRAINT fk_er_enrollment
        FOREIGN KEY (enrollment_id) REFERENCES enrollments(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_er_requirement
        FOREIGN KEY (requirement_id) REFERENCES requirements(id)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- SEED DATA
-- Test logins (change these before going live):
--   Admin   : admin@college.edu    / Admin@12345
--   Student : student@college.edu  / Student@12345
-- =====================================================================

INSERT INTO users (first_name, last_name, email, password, role) VALUES
('System', 'Administrator', 'admin@college.edu',
 '$2y$10$lsJNNORblYppCHIsQplfieUGEJqwpamGyq.18klcCySURSi4K8DgK', 'admin'),
('Juan', 'Dela Cruz', 'student@college.edu',
 '$2y$10$mMDrSlNWHqdPi4.LDJz7U.YQ5ewl7/j1jfftS3W0PaDnUTPQl/11y', 'student');

INSERT INTO student_profiles (user_id, student_number, phone, gender, address) VALUES
(2, '2026-0001', '09171234567', 'male', 'Cebu City, Philippines');

INSERT INTO academic_years (name, start_date, end_date, is_active) VALUES
('2025-2026', '2025-08-01', '2026-05-31', 0),
('2026-2027', '2026-08-01', '2027-05-31', 1);

INSERT INTO programs (code, name, description, department, duration_years, slots) VALUES
('BSIT',  'BS Information Technology',   'Software, networks, and systems.',        'College of Computing',  4, 120),
('BSCS',  'BS Computer Science',         'Algorithms, theory, and software design.', 'College of Computing',  4, 100),
('BSBA',  'BS Business Administration',  'Management, marketing, and finance.',      'College of Business',   4, 150),
('BSN',   'BS Nursing',                  'Clinical and community health nursing.',   'College of Health',     4,  80),
('BSED',  'BS Education',                'Teacher education and pedagogy.',          'College of Education',  4, 100);

INSERT INTO requirements (name, description, is_required) VALUES
('Birth Certificate (PSA)',  'Photocopy of PSA-issued birth certificate.', 1),
('Form 138 / Report Card',   'Latest report card from previous school.',   1),
('Certificate of Good Moral','Issued by the previous school.',             1),
('2x2 ID Photo',             'Recent photo, white background.',            1),
('Medical Certificate',      'Issued within the last 6 months.',           0);

INSERT INTO enrollments (student_id, program_id, academic_year_id, year_level, semester, status)
VALUES (2, 1, 2, 1, '1st', 'pending');

INSERT INTO enrollment_requirements (enrollment_id, requirement_id, file_path, status) VALUES
(1, 1, 'uploads/sample_birth_certificate.pdf', 'submitted'),
(1, 2, 'uploads/sample_form138.pdf',           'submitted');
