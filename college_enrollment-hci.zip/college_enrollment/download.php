<?php
/**
 * Serves an uploaded requirement document.
 * Only the student who owns it, or an admin, may open it.
 */
require_once __DIR__ . "/includes/auth.php";
require_login();

$id = (int) ($_GET["id"] ?? 0);

$stmt = $pdo->prepare(
    "SELECT er.file_path, e.student_id
     FROM enrollment_requirements er
     JOIN enrollments e ON e.id = er.enrollment_id
     WHERE er.id = ?"
);
$stmt->execute([$id]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row || !$row["file_path"]) {
    http_response_code(404);
    exit("File not found.");
}

if ($_SESSION["role"] !== "admin" && (int) $row["student_id"] !== (int) $_SESSION["user_id"]) {
    http_response_code(403);
    exit("You don't have access to this file.");
}

// The stored path must resolve to a real file inside uploads/
$base = realpath(__DIR__ . "/uploads");
$full = realpath(__DIR__ . "/" . $row["file_path"]);

if (!$base || !$full || strpos($full, $base . DIRECTORY_SEPARATOR) !== 0 || !is_file($full)) {
    http_response_code(404);
    exit("This file is no longer available.");
}

$mime = (new finfo(FILEINFO_MIME_TYPE))->file($full);
$ext  = pathinfo($full, PATHINFO_EXTENSION);

header("Content-Type: " . $mime);
header("Content-Length: " . filesize($full));
header("Content-Disposition: inline; filename=\"document-" . $id . "." . $ext . "\"");
header("X-Content-Type-Options: nosniff");
readfile($full);
exit;
