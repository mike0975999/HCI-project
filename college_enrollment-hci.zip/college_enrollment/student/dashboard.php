<?php
$pageTitle = "My Dashboard";
$activeNav = "dashboard";
require_once __DIR__ . "/../includes/student_header.php";

$uid        = (int) $_SESSION["user_id"];
$profile    = get_profile($pdo, $uid);
$enrollment = get_current_enrollment($pdo, $uid);
$year       = get_active_year($pdo);

[$percent, $missing] = profile_completion($profile);

$reqText = "-";
$reqSub  = "No application yet";
$reqPct  = 0;
if ($enrollment) {
    [$total, $submitted] = requirement_progress($pdo, (int) $enrollment["id"]);
    $reqText = "$submitted / $total";
    $reqSub  = "Required documents submitted";
    $reqPct  = $total > 0 ? (int) round($submitted / $total * 100) : 100;
}

// What should the student do next?
if (!$enrollment) {
    if (!profile_ready_to_enroll($profile)) {
        $next = ["Complete your profile", "Add your date of birth, gender and address, then you can apply.", "profile.php", "Go to profile"];
    } elseif ($year) {
        $next = ["Start your enrollment", "Enrollment is open for " . $year["name"] . ". Choose your program and apply.", "enroll.php", "Enroll now"];
    } else {
        $next = ["Enrollment is closed", "There is no open academic year right now. Please check back later.", null, null];
    }
} elseif ($enrollment["status"] === "pending") {
    [$total, $submitted] = requirement_progress($pdo, (int) $enrollment["id"]);
    $next = $submitted < $total
        ? ["Upload your requirements", ($total - $submitted) . " required document(s) still missing.", "requirements.php", "Upload documents"]
        : ["Application under review", "All documents are in. The admissions office will review your application.", "tracking.php", "Track progress"];
} elseif ($enrollment["status"] === "approved") {
    $next = ["You are enrolled!", "Your application for " . $enrollment["program_name"] . " was approved.", "tracking.php", "View details"];
} else {
    $next = ["Application not approved", "See the admissions remarks for the reason.", "tracking.php", "View details"];
}
?>

<section class="welcome">
    <div>
        <h2>Welcome, <?= e($_SESSION["name"]) ?>!</h2>
        <p>Student No. <?= e($profile["student_number"]) ?> &middot; <?= e($profile["email"]) ?></p>
    </div>
</section>

<div class="sp-card" style="display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap;">
    <div>
        <h3><?= e($next[0]) ?></h3>
        <p class="sub" style="margin:4px 0 0;"><?= e($next[1]) ?></p>
    </div>
    <?php if ($next[2]): ?>
        <a class="sp-btn" href="<?= e($next[2]) ?>"><?= e($next[3]) ?></a>
    <?php endif; ?>
</div>

<section class="sp-stats">
    <div class="sp-stat">
        <p>Profile completeness</p>
        <h2><?= $percent ?>%</h2>
        <div class="sp-progress"><div style="width:<?= $percent ?>%"></div></div>
        <span><?= $missing ? "Missing: " . e(implode(", ", $missing)) : "Your profile is complete" ?></span>
    </div>
    <div class="sp-stat">
        <p>Requirements</p>
        <h2><?= e($reqText) ?></h2>
        <div class="sp-progress"><div style="width:<?= $reqPct ?>%"></div></div>
        <span><?= e($reqSub) ?></span>
    </div>
    <div class="sp-stat">
        <p>Enrollment status</p>
        <h2 style="font-size:20px;margin-top:6px;">
            <?= $enrollment ? status_badge($enrollment["status"]) : '<span class="sp-badge missing">Not applied</span>' ?>
        </h2>
        <span style="display:block;margin-top:12px;">
            <?= $enrollment ? e($enrollment["program_name"] . " · " . $enrollment["academic_year"]) : "Submit an application to begin" ?>
        </span>
    </div>
</section>

<?php require __DIR__ . "/../includes/student_footer.php"; ?>
