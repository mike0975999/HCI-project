<?php
require_once __DIR__ . "/../includes/auth.php";
require_role("admin");

$sql = "SELECT
            users.id,
            users.first_name,
            users.last_name,
            users.email,
            student_profiles.student_number,
            student_profiles.phone
        FROM users
        LEFT JOIN student_profiles
            ON users.id = student_profiles.user_id
        WHERE users.role = 'student'
        ORDER BY users.id DESC";

$stmt = $pdo->query($sql);
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Student Management | College Enrollment</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">
</head>

<body class="bg-light">

<div class="container py-5">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>
            <h2>Student Management</h2>
            <p class="text-muted mb-0">
                Manage registered student records.
            </p>
        </div>

        <a href="create.php" class="btn btn-primary">
            + Add Student
        </a>

    </div>

    <?php if (isset($_GET["success"])): ?>
        <div class="alert alert-success">
            Student added successfully!
        </div>
    <?php endif; ?>

    <div class="card shadow-sm">

        <div class="card-body">

            <div class="table-responsive">

                <table class="table table-hover align-middle">

                    <thead class="table-dark">
                        <tr>
                            <th>Student No.</th>
                            <th>Full Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                        </tr>
                    </thead>

                    <tbody>

                    <?php if (count($students) > 0): ?>

                        <?php foreach ($students as $student): ?>

                            <tr>
                                <td>
                                    <?= htmlspecialchars(
                                        $student["student_number"] ?? ""
                                    ) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        $student["first_name"] . " " .
                                        $student["last_name"]
                                    ) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars($student["email"]) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        $student["phone"] ?? ""
                                    ) ?>
                                </td>
                            </tr>

                        <?php endforeach; ?>

                    <?php else: ?>

                        <tr>
                            <td colspan="4" class="text-center py-4">
                                No student records found.
                            </td>
                        </tr>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

            <p class="text-muted mb-0">
                Total Students: <?= count($students) ?>
            </p>

        </div>
    </div>

</div>

</body>
</html>
