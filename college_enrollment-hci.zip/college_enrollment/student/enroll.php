<?php
$pageTitle = "Enrollment Form";
$activeNav = "enroll";
require_once __DIR__ . "/../includes/student_header.php";

$uid     = (int) $_SESSION["user_id"];
$profile = get_profile($pdo, $uid);
$year    = get_active_year($pdo);
$error   = "";

// Enrollment must be open
if (!$year) {
    echo '<div class="sp-card sp-empty"><i class="fas fa-lock"></i>
          <p>Enrollment is currently closed. Please check back later.</p></div>';
    require __DIR__ . "/../includes/student_footer.php";
    exit;
}

// One application per academic year
$stmt = $pdo->prepare("SELECT id FROM enrollments WHERE student_id = ? AND academic_year_id = ?");
$stmt->execute([$uid, $year["id"]]);
if ($stmt->fetchColumn()) {
    flash("info", "You already have an application for " . $year["name"] . ".");
    redirect(BASE_URL . "/student/tracking.php");
}

// Profile must be filled in first
if (!profile_ready_to_enroll($profile)) {
    flash("info", "Please complete your date of birth, gender and address before applying.");
    redirect(BASE_URL . "/student/profile.php");
}

// Programs with seats already taken (pending + approved applications)
$stmt = $pdo->prepare(
    "SELECT p.*,
            (SELECT COUNT(*) FROM enrollments e
             WHERE e.program_id = p.id AND e.academic_year_id = ?
               AND e.status IN ('pending','approved')) AS taken
     FROM programs p
     WHERE p.is_active = 1
     ORDER BY p.name"
);
$stmt->execute([$year["id"]]);
$programs = $stmt->fetchAll(PDO::FETCH_ASSOC);

$selected = (int) ($_POST["program_id"] ?? 0);
$level    = (int) ($_POST["year_level"] ?? 1);
$semester = $_POST["semester"] ?? "1st";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $program = null;
    foreach ($programs as $p) {
        if ((int) $p["id"] === $selected) {
            $program = $p;
        }
    }

    if (!csrf_valid()) {
        $error = "Session expired. Please try again.";
    } elseif (!$program) {
        $error = "Please choose a program.";
    } elseif ($level < 1 || $level > (int) $program["duration_years"]) {
        $error = "Please choose a valid year level for this program.";
    } elseif (!in_array($semester, ["1st", "2nd", "summer"], true)) {
        $error = "Please choose a valid semester.";
    } elseif (empty($_POST["confirm"])) {
        $error = "Please confirm that your information is correct.";
    } else {
        try {
            $pdo->beginTransaction();

            // Lock the program row so two students can't take the last seat together
            $lock = $pdo->prepare("SELECT slots FROM programs WHERE id = ? AND is_active = 1 FOR UPDATE");
            $lock->execute([$selected]);
            $slots = $lock->fetchColumn();

            $count = $pdo->prepare(
                "SELECT COUNT(*) FROM enrollments
                 WHERE program_id = ? AND academic_year_id = ? AND status IN ('pending','approved')"
            );
            $count->execute([$selected, $year["id"]]);

            if ($slots === false || (int) $count->fetchColumn() >= (int) $slots) {
                $pdo->rollBack();
                $error = "Sorry, that program has no slots left.";
            } else {
                $pdo->prepare(
                    "INSERT INTO enrollments (student_id, program_id, academic_year_id, year_level, semester)
                     VALUES (?, ?, ?, ?, ?)"
                )->execute([$uid, $selected, $year["id"], $level, $semester]);
                $pdo->commit();

                flash("success", "Application submitted! Now upload your requirements.");
                redirect(BASE_URL . "/student/requirements.php");
            }
        } catch (PDOException $ex) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = $ex->getCode() === "23000"
                ? "You already have an application for this academic year."
                : "Unable to submit your application. Please try again.";
        }
    }
}
?>

<form method="POST">
    <?= csrf_field() ?>

    <div class="sp-card">
        <h3>1. Choose your program</h3>
        <p class="sub">Academic year <?= e($year["name"]) ?>. Programs with no slots left can't be selected.</p>

        <?php if ($error !== ""): ?>
            <div class="sp-alert error"><?= e($error) ?></div>
        <?php endif; ?>

        <div class="sp-programs">
            <?php foreach ($programs as $p):
                $left = max(0, (int) $p["slots"] - (int) $p["taken"]); ?>
                <label class="sp-program">
                    <input type="radio" name="program_id" value="<?= (int) $p["id"] ?>"
                           <?= $left === 0 ? "disabled" : "" ?>
                           <?= $selected === (int) $p["id"] ? "checked" : "" ?>>
                    <span class="box">
                        <span class="code"><?= e($p["code"]) ?></span>
                        <span class="name"><?= e($p["name"]) ?></span>
                        <span class="desc"><?= e($p["description"]) ?></span>
                        <span class="meta">
                            <span><?= e($p["department"]) ?> &middot; <?= (int) $p["duration_years"] ?> yrs</span>
                            <strong><?= $left > 0 ? "$left slots left" : "Full" ?></strong>
                        </span>
                    </span>
                </label>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="sp-card">
        <h3>2. Year level and semester</h3>
        <p class="sub">First-time students should choose 1st year, 1st semester.</p>

        <div class="sp-grid">
            <div class="sp-field">
                <label>Year level</label>
                <select name="year_level">
                    <?php for ($i = 1; $i <= 5; $i++): ?>
                        <option value="<?= $i ?>" <?= $level === $i ? "selected" : "" ?>>Year <?= $i ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="sp-field">
                <label>Semester</label>
                <select name="semester">
                    <?php foreach (["1st" => "1st Semester", "2nd" => "2nd Semester", "summer" => "Summer"] as $v => $l): ?>
                        <option value="<?= $v ?>" <?= $semester === $v ? "selected" : "" ?>><?= $l ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
    </div>

    <div class="sp-card">
        <h3>3. Review and submit</h3>
        <p class="sub">Applying as <strong><?= e($profile["first_name"] . " " . $profile["last_name"]) ?></strong>
            (<?= e($profile["student_number"]) ?>). <a href="profile.php" style="color:#2563eb;">Edit profile</a></p>

        <label style="display:flex;gap:8px;font-size:13px;margin-bottom:18px;">
            <input type="checkbox" name="confirm" value="1" required>
            I confirm that the information I provided is correct.
        </label>

        <button type="submit" class="sp-btn">Submit application</button>
    </div>
</form>

<?php require __DIR__ . "/../includes/student_footer.php"; ?>
