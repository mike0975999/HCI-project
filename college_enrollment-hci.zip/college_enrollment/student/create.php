<?php
require_once __DIR__ . "/../includes/auth.php";
require_role("admin");

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $first_name = trim($_POST["first_name"] ?? "");
    $last_name = trim($_POST["last_name"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $student_number = trim($_POST["student_number"] ?? "");
    $phone = trim($_POST["phone"] ?? "");
    $password = $_POST["password"] ?? "";

    if (
        $first_name === "" ||
        $last_name === "" ||
        $email === "" ||
        $student_number === "" ||
        $password === ""
    ) {
        $message = "Please fill in all required fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Please enter a valid email address.";
    } elseif (strlen($password) < 8) {
        $message = "Password must be at least 8 characters.";
    } else {
        try {
            $pdo->beginTransaction();

            $hashed_password = password_hash(
                $password,
                PASSWORD_DEFAULT
            );

            $sql = "INSERT INTO users
                    (first_name, last_name, email, password, role)
                    VALUES (?, ?, ?, ?, 'student')";

            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $first_name,
                $last_name,
                $email,
                $hashed_password
            ]);

            $user_id = $pdo->lastInsertId();

            $sql = "INSERT INTO student_profiles
                    (user_id, student_number, phone)
                    VALUES (?, ?, ?)";

            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $user_id,
                $student_number,
                $phone
            ]);

            $pdo->commit();

            header("Location: index.php?success=added");
            exit;

        } catch (PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            if ($e->getCode() === "23000") {
                $message = "Email or student number already exists.";
            } else {
                $message = "Unable to save student. Please try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Student | College Enrollment</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">
</head>

<body class="bg-light">

<div class="container py-5">

    <div class="card shadow-sm mx-auto" style="max-width: 700px;">

        <div class="card-header bg-primary text-white p-3">
            <h4 class="mb-0">Add New Student</h4>
        </div>

        <div class="card-body p-4">

            <?php if ($message !== ""): ?>
                <div class="alert alert-danger">
                    <?= htmlspecialchars($message) ?>
                </div>
            <?php endif; ?>

            <form method="POST">

                <div class="row">

                    <div class="col-md-6 mb-3">
                        <label class="form-label">First Name *</label>
                        <input type="text" name="first_name"
                               class="form-control" required>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Last Name *</label>
                        <input type="text" name="last_name"
                               class="form-control" required>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Email Address *</label>
                        <input type="email" name="email"
                               class="form-control" required>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Student Number *</label>
                        <input type="text" name="student_number"
                               class="form-control" required>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Phone Number</label>
                        <input type="text" name="phone"
                               class="form-control">
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Temporary Password *</label>
                        <input type="password" name="password"
                               class="form-control"
                               minlength="8" required>
                    </div>

                </div>

                <div class="d-flex justify-content-between mt-3">

                    <a href="index.php" class="btn btn-secondary">
                        Cancel
                    </a>

                    <button type="submit" class="btn btn-primary">
                        Save Student
                    </button>

                </div>

            </form>

        </div>
    </div>

</div>

</body>
</html>
