<?php
$pageTitle = "Track Enrollment";
$activeNav = "tracking";
require_once __DIR__ . "/../includes/student_header.php";

$uid = (int) $_SESSION["user_id"];

/* ---------- cancel a pending application ---------- */
if ($_SERVER["REQUEST_METHOD"] === "POST" && ($_POST["action"] ?? "") === "cancel") {
    $id = (int) ($_POST["enrollment_id"] ?? 0);

    if (!csrf_valid()) {
        flash("error", "Session expired. Please try again.");
    } else {
        // Only the owner can cancel, and only while it is still pending
        $stmt = $pdo->prepare("SELECT id FROM enrollments WHERE id = ? AND student_id = ? AND status = 'pending'");
        $stmt->execute([$id, $uid]);

        if ($stmt->fetchColumn()) {
            $files = $pdo->prepare("SELECT file_path FROM enrollment_requirements WHERE enrollment_id = ?");
            $files->execute([$id]);
            $paths = $files->fetchAll(PDO::FETCH_COLUMN);

            $pdo->prepare("DELETE FROM enrollments WHERE id = ?")->execute([$id]); // documents cascade
            foreach ($paths as $path) {
                delete_stored_file($path);
            }
            flash("success", "Your application was cancelled. You can apply again.");
        } else {
            flash("error", "That application can't be cancelled.");
        }
    }
    redirect(BASE_URL . "/student/tracking.php");
}

$enrollments = get_enrollments($pdo, $uid);

if (!$enrollments) {
    echo '<div class="sp-card sp-empty"><i class="fas fa-route"></i>
          <p>You have not applied yet.</p>
          <a class="sp-btn" href="enroll.php">Start enrollment</a></div>';
    require __DIR__ . "/../includes/student_footer.php";
    exit;
}

foreach ($enrollments as $en):
    $status = $en["status"];
    [$total, $submitted, $verified] = requirement_progress($pdo, (int) $en["id"]);
    $pct = $total > 0 ? (int) round($submitted / $total * 100) : 100;

    $docsDone = $submitted >= $total;
    $decided  = $status !== "pending";
    $decisionClass = $status === "approved" ? "ok" : ($status === "rejected" ? "bad" : "");
?>
<div class="sp-card">
    <div class="sp-track-head">
        <div>
            <h3><?= e($en["program_name"]) ?></h3>
            <p class="sub" style="margin:2px 0 0;"><?= e($en["program_code"]) ?> &middot; Academic year <?= e($en["academic_year"]) ?></p>
        </div>
        <?= status_badge($status) ?>
    </div>

    <div class="sp-steps">
        <div class="sp-step done">
            <div class="dot"><i class="fas fa-check"></i></div>
            Submitted
            <small><?= e(date("M d, Y", strtotime($en["submitted_at"]))) ?></small>
        </div>
        <div class="sp-step <?= $docsDone ? "done" : "current" ?>">
            <div class="dot"><i class="fas <?= $docsDone ? "fa-check" : "fa-folder-open" ?>"></i></div>
            Documents
            <small><?= $submitted ?> / <?= $total ?> required</small>
        </div>
        <div class="sp-step <?= $decided ? "done" : ($docsDone ? "current" : "") ?>">
            <div class="dot"><i class="fas <?= $decided ? "fa-check" : "fa-hourglass-half" ?>"></i></div>
            Under review
            <small><?= $decided ? "Completed" : "Waiting for admissions" ?></small>
        </div>
        <div class="sp-step <?= $decisionClass ?>">
            <div class="dot"><i class="fas <?= $status === "approved" ? "fa-check" : ($status === "rejected" ? "fa-xmark" : "fa-flag") ?>"></i></div>
            Decision
            <small><?= $decided
                ? e(ucfirst($status) . ($en["reviewed_at"] ? " · " . date("M d, Y", strtotime($en["reviewed_at"])) : ""))
                : "Pending" ?></small>
        </div>
    </div>

    <div class="sp-detail">
        <div><span>Year level</span><strong>Year <?= (int) $en["year_level"] ?></strong></div>
        <div><span>Semester</span><strong><?= e(ucfirst($en["semester"])) ?></strong></div>
        <div><span>Documents verified</span><strong><?= $verified ?> / <?= $total ?></strong></div>
        <div><span>Last update</span><strong><?= e(date("M d, Y", strtotime($en["updated_at"]))) ?></strong></div>
    </div>

    <?php if ($status === "approved"): ?>
        <div class="sp-remarks ok"><strong>Congratulations!</strong> Your enrollment was approved.
            <?= $en["remarks"] ? "<br>" . e($en["remarks"]) : "" ?></div>
    <?php elseif ($status === "rejected"): ?>
        <div class="sp-remarks"><strong>Not approved.</strong>
            <?= $en["remarks"] ? e($en["remarks"]) : "Please contact the admissions office for details." ?></div>
    <?php endif; ?>

    <?php if ($status === "pending"): ?>
        <div style="display:flex;gap:10px;flex-wrap:wrap;">
            <?php if (!$docsDone): ?>
                <a class="sp-btn" href="requirements.php">Upload missing documents</a>
            <?php else: ?>
                <a class="sp-btn secondary" href="requirements.php">View documents</a>
            <?php endif; ?>

            <form method="POST" onsubmit="return confirm('Cancel this application? Your uploaded documents will be deleted.');">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="cancel">
                <input type="hidden" name="enrollment_id" value="<?= (int) $en["id"] ?>">
                <button type="submit" class="sp-btn danger">Cancel application</button>
            </form>
        </div>
    <?php endif; ?>
</div>
<?php endforeach; ?>

<?php require __DIR__ . "/../includes/student_footer.php"; ?>
