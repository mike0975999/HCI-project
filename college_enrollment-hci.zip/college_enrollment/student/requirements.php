<?php
$pageTitle = "Requirements";
$activeNav = "requirements";
require_once __DIR__ . "/../includes/student_header.php";

$uid        = (int) $_SESSION["user_id"];
$enrollment = get_current_enrollment($pdo, $uid);

if (!$enrollment) {
    echo '<div class="sp-card sp-empty"><i class="fas fa-folder-open"></i>
          <p>Submit an enrollment application first, then upload your documents here.</p>
          <a class="sp-btn" href="enroll.php">Go to enrollment form</a></div>';
    require __DIR__ . "/../includes/student_footer.php";
    exit;
}

$enrollmentId = (int) $enrollment["id"];
$canUpload    = $enrollment["status"] === "pending";

/* ---------- handle an upload ---------- */
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $reqId = (int) ($_POST["requirement_id"] ?? 0);
    $file  = $_FILES["document"] ?? null;
    $fail  = "";

    if (!csrf_valid()) {
        $fail = "Session expired. Please try again.";
    } elseif (!$canUpload) {
        $fail = "This application is no longer open for changes.";
    } elseif (!$file || $file["error"] === UPLOAD_ERR_NO_FILE) {
        $fail = "Please choose a file to upload.";
    } elseif ($file["error"] !== UPLOAD_ERR_OK) {
        $fail = $file["error"] === UPLOAD_ERR_INI_SIZE || $file["error"] === UPLOAD_ERR_FORM_SIZE
            ? "That file is too large (maximum 5 MB)."
            : "The upload failed. Please try again.";
    } elseif ($file["size"] > UPLOAD_MAX_BYTES) {
        $fail = "That file is too large (maximum 5 MB).";
    } else {
        $check = $pdo->prepare("SELECT id FROM requirements WHERE id = ?");
        $check->execute([$reqId]);
        if (!$check->fetchColumn()) {
            $fail = "Unknown requirement.";
        } else {
            // Trust the file's real content, not its name or the browser's claim
            $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file["tmp_name"]);
            if (!isset(UPLOAD_TYPES[$mime])) {
                $fail = "Only PDF, JPG or PNG files are allowed.";
            }
        }
    }

    if ($fail === "") {
        $name = bin2hex(random_bytes(16)) . "." . UPLOAD_TYPES[$mime];
        $dest = upload_dir() . DIRECTORY_SEPARATOR . $name;

        if (!move_uploaded_file($file["tmp_name"], $dest)) {
            $fail = "Could not save the file on the server.";
        } else {
            $old = $pdo->prepare(
                "SELECT file_path, status FROM enrollment_requirements
                 WHERE enrollment_id = ? AND requirement_id = ?"
            );
            $old->execute([$enrollmentId, $reqId]);
            $prev = $old->fetch(PDO::FETCH_ASSOC);

            if ($prev && $prev["status"] === "verified") {
                @unlink($dest);
                $fail = "That document was already verified and can't be replaced.";
            } else {
                $pdo->prepare(
                    "INSERT INTO enrollment_requirements (enrollment_id, requirement_id, file_path, status)
                     VALUES (?, ?, ?, 'submitted')
                     ON DUPLICATE KEY UPDATE file_path = VALUES(file_path), status = 'submitted',
                                             remarks = NULL, uploaded_at = CURRENT_TIMESTAMP"
                )->execute([$enrollmentId, $reqId, UPLOAD_DIR_NAME . "/" . $name]);

                if ($prev) {
                    delete_stored_file($prev["file_path"]);
                }
                flash("success", "Document uploaded.");
                redirect(BASE_URL . "/student/requirements.php");
            }
        }
    }
    flash("error", $fail);
    redirect(BASE_URL . "/student/requirements.php");
}

/* ---------- list requirements with the student's submissions ---------- */
$stmt = $pdo->prepare(
    "SELECT r.id, r.name, r.description, r.is_required,
            er.id AS er_id, er.file_path, er.status, er.remarks
     FROM requirements r
     LEFT JOIN enrollment_requirements er
            ON er.requirement_id = r.id AND er.enrollment_id = ?
     ORDER BY r.is_required DESC, r.id"
);
$stmt->execute([$enrollmentId]);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

[$total, $submitted] = requirement_progress($pdo, $enrollmentId);
$pct = $total > 0 ? (int) round($submitted / $total * 100) : 100;
?>

<div class="sp-card">
    <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;">
        <div>
            <h3><?= e($enrollment["program_name"]) ?> &middot; <?= e($enrollment["academic_year"]) ?></h3>
            <p class="sub" style="margin-bottom:0;">Accepted files: PDF, JPG or PNG, up to 5 MB each.</p>
        </div>
        <div><?= status_badge($enrollment["status"]) ?></div>
    </div>
    <div class="sp-progress"><div style="width:<?= $pct ?>%"></div></div>
    <span style="font-size:12px;color:#64748b;"><?= $submitted ?> of <?= $total ?> required documents submitted</span>
</div>

<?php if (!$canUpload): ?>
    <div class="sp-alert info">This application has been <?= e($enrollment["status"]) ?>, so documents can no longer be changed.</div>
<?php endif; ?>

<div class="sp-card">
    <?php foreach ($rows as $r):
        $state = $r["status"] ?? "missing"; ?>
        <div class="sp-req">
            <div class="info">
                <h4>
                    <?= e($r["name"]) ?>
                    <?= $r["is_required"] ? "" : '<span class="sp-badge optional">Optional</span>' ?>
                    <?= status_badge($state) ?>
                </h4>
                <p><?= e($r["description"]) ?></p>
                <?php if ($r["er_id"]): ?>
                    <p class="file"><a href="<?= BASE_URL ?>/download.php?id=<?= (int) $r["er_id"] ?>" target="_blank">View uploaded file</a></p>
                <?php endif; ?>
                <?php if ($state === "rejected" && $r["remarks"]): ?>
                    <p class="note">Reason: <?= e($r["remarks"]) ?></p>
                <?php endif; ?>
            </div>

            <?php if ($canUpload && $state !== "verified"): ?>
                <form method="POST" enctype="multipart/form-data">
                    <?= csrf_field() ?>
                    <input type="hidden" name="requirement_id" value="<?= (int) $r["id"] ?>">
                    <input type="file" name="document" accept=".pdf,.jpg,.jpeg,.png" required>
                    <button type="submit" class="sp-btn small">
                        <?= $r["er_id"] ? "Replace" : "Upload" ?>
                    </button>
                </form>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</div>

<?php require __DIR__ . "/../includes/student_footer.php"; ?>
