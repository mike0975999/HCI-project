<?php

declare(strict_types=1);

/**
 * Append-only application audit logging.
 * Call this inside the same PDO transaction as the action being recorded.
 */
function log_application_event(
    PDO $pdo,
    int $enrollmentId,
    ?int $actorUserId,
    string $action,
    ?string $oldStatus = null,
    ?string $newStatus = null,
    ?string $details = null
): void {
    $stmt = $pdo->prepare(
        "INSERT INTO application_audit_logs
            (enrollment_id, actor_user_id, action, old_status, new_status, details)
         VALUES (?, ?, ?, ?, ?, ?)"
    );
    $stmt->execute([
        $enrollmentId,
        $actorUserId,
        $action,
        $oldStatus,
        $newStatus,
        $details,
    ]);
}

/** Resolve an uploads-relative path without allowing traversal outside uploads/. */
function resolve_stored_upload(?string $relativePath): ?string
{
    if (!$relativePath || str_contains($relativePath, "\\")) {
        return null;
    }

    $prefix = "uploads/";
    if (!str_starts_with($relativePath, $prefix)) {
        return null;
    }

    $base = realpath(__DIR__ . "/../uploads");
    $full = realpath(__DIR__ . "/../" . $relativePath);

    if (!$base || !$full || !is_file($full)) {
        return null;
    }

    $basePrefix = rtrim($base, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR;
    if (!str_starts_with($full, $basePrefix)) {
        return null;
    }

    return $full;
}
