<?php

declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| Login rate limiting
|--------------------------------------------------------------------------
| Email + IP: 5 failed attempts in 15 minutes.
| IP: 20 failed attempts in 15 minutes.
|--------------------------------------------------------------------------
*/

const LOGIN_WINDOW_MINUTES = 15;
const LOGIN_EMAIL_IP_LIMIT = 5;
const LOGIN_IP_LIMIT = 20;

function client_ip_address(): string
{
    // Do not trust X-Forwarded-For unless the deployment uses a trusted proxy.
    return $_SERVER["REMOTE_ADDR"] ?? "0.0.0.0";
}

function normalize_login_email(string $email): string
{
    return strtolower(trim($email));
}

function login_rate_identifier(string $scope, string $email, string $ip): string
{
    $value = $scope === "email_ip"
        ? normalize_login_email($email) . "|" . $ip
        : $ip;

    return hash("sha256", $value);
}

function login_rate_limits(PDO $pdo, string $email): array
{
    $ip = client_ip_address();
    $emailIpIdentifier = login_rate_identifier("email_ip", $email, $ip);
    $ipIdentifier = login_rate_identifier("ip", $email, $ip);

    $stmt = $pdo->prepare(
        "SELECT scope, failed_attempts, first_failed_at, blocked_until
         FROM login_attempts
         WHERE (scope = 'email_ip' AND identifier = ?)
            OR (scope = 'ip' AND identifier = ?)"
    );
    $stmt->execute([$emailIpIdentifier, $ipIdentifier]);

    $rows = $stmt->fetchAll();
    $now = new DateTimeImmutable("now");

    foreach ($rows as $row) {
        if (!empty($row["blocked_until"])) {
            $blockedUntil = new DateTimeImmutable($row["blocked_until"]);
            if ($blockedUntil > $now) {
                return ["blocked" => true, "until" => $blockedUntil];
            }
        }

        $firstFailed = new DateTimeImmutable($row["first_failed_at"]);
        $windowEnd = $firstFailed->modify("+" . LOGIN_WINDOW_MINUTES . " minutes");
        if ($windowEnd <= $now) {
            continue;
        }

        $limit = $row["scope"] === "email_ip"
            ? LOGIN_EMAIL_IP_LIMIT
            : LOGIN_IP_LIMIT;

        if ((int) $row["failed_attempts"] >= $limit) {
            return ["blocked" => true, "until" => $windowEnd];
        }
    }

    return ["blocked" => false, "until" => null];
}

function record_login_failure(PDO $pdo, string $email): void
{
    $ip = client_ip_address();
    $items = [
        [
            "scope" => "email_ip",
            "identifier" => login_rate_identifier("email_ip", $email, $ip),
            "limit" => LOGIN_EMAIL_IP_LIMIT,
        ],
        [
            "scope" => "ip",
            "identifier" => login_rate_identifier("ip", $email, $ip),
            "limit" => LOGIN_IP_LIMIT,
        ],
    ];

    foreach ($items as $item) {
        $stmt = $pdo->prepare(
            "SELECT id, failed_attempts, first_failed_at
             FROM login_attempts
             WHERE scope = ? AND identifier = ?
             LIMIT 1"
        );
        $stmt->execute([$item["scope"], $item["identifier"]]);
        $row = $stmt->fetch();
        $now = new DateTimeImmutable("now");

        if (!$row) {
            $insert = $pdo->prepare(
                "INSERT INTO login_attempts
                 (scope, identifier, failed_attempts, first_failed_at, last_failed_at)
                 VALUES (?, ?, 1, NOW(), NOW())"
            );
            $insert->execute([$item["scope"], $item["identifier"]]);
            continue;
        }

        $firstFailed = new DateTimeImmutable($row["first_failed_at"]);
        $windowExpired = $firstFailed->modify("+" . LOGIN_WINDOW_MINUTES . " minutes") <= $now;

        if ($windowExpired) {
            $reset = $pdo->prepare(
                "UPDATE login_attempts
                 SET failed_attempts = 1, first_failed_at = NOW(), last_failed_at = NOW(), blocked_until = NULL
                 WHERE id = ?"
            );
            $reset->execute([$row["id"]]);
            continue;
        }

        $newCount = (int) $row["failed_attempts"] + 1;
        $blockedUntil = null;

        if ($newCount >= $item["limit"]) {
            $blockedUntil = $now->modify("+" . LOGIN_WINDOW_MINUTES . " minutes")->format("Y-m-d H:i:s");
        }

        $update = $pdo->prepare(
            "UPDATE login_attempts
             SET failed_attempts = ?, last_failed_at = NOW(), blocked_until = ?
             WHERE id = ?"
        );
        $update->execute([$newCount, $blockedUntil, $row["id"]]);
    }
}

function clear_login_failures(PDO $pdo, string $email): void
{
    $identifier = login_rate_identifier("email_ip", $email, client_ip_address());
    $stmt = $pdo->prepare(
        "DELETE FROM login_attempts
         WHERE scope = 'email_ip' AND identifier = ?"
    );
    $stmt->execute([$identifier]);
}

function clean_old_login_attempts(PDO $pdo): void
{
    $stmt = $pdo->prepare(
        "DELETE FROM login_attempts
         WHERE last_failed_at < DATE_SUB(NOW(), INTERVAL 1 DAY)"
    );
    $stmt->execute();
}
