<?php

declare(strict_types=1);

/**
 * Authentication helpers: sessions, login, role checks, CSRF and security headers.
 * Include this at the very top of any page that needs login or role checks.
 */

require_once __DIR__ . "/../config/database.php";
require_once __DIR__ . "/login_throttle.php";

// URL of the project folder inside htdocs (change if you rename the folder).
define("BASE_URL", "/college_enrollment");

function is_https_request(): bool
{
    return !empty($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] !== "off";
}

function send_security_headers(): void
{
    static $sent = false;
    if ($sent) {
        return;
    }
    $sent = true;

    header("X-Content-Type-Options: nosniff");
    header("X-Frame-Options: SAMEORIGIN");
    header("Referrer-Policy: strict-origin-when-cross-origin");
    header("Permissions-Policy: camera=(), microphone=(), geolocation=()");
    header(
        "Content-Security-Policy: " .
        "default-src 'self'; " .
        "base-uri 'self'; " .
        "form-action 'self'; " .
        "frame-ancestors 'self'; " .
        "object-src 'none'; " .
        "script-src 'self'; " .
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://cdnjs.cloudflare.com; " .
        "font-src 'self' data: https://fonts.gstatic.com https://cdnjs.cloudflare.com; " .
        "img-src 'self' data: blob:; " .
        "connect-src 'self';"
    );

    // Avoid HSTS on local development hosts.
    $host = strtolower((string) ($_SERVER["HTTP_HOST"] ?? ""));
    $isLocalHost = str_starts_with($host, "localhost")
        || str_starts_with($host, "127.0.0.1")
        || str_starts_with($host, "[::1]");

    if (is_https_request() && !$isLocalHost) {
        header("Strict-Transport-Security: max-age=31536000; includeSubDomains");
    }
}

send_security_headers();

if (session_status() === PHP_SESSION_NONE) {
    ini_set("session.use_strict_mode", "1");
    ini_set("session.use_only_cookies", "1");
    ini_set("session.use_trans_sid", "0");

    session_set_cookie_params([
        "lifetime" => 0,
        "path" => BASE_URL,
        "secure" => is_https_request(),
        "httponly" => true,
        "samesite" => "Lax",
    ]);

    session_start();
}

function e(?string $value): string
{
    return htmlspecialchars(
        $value ?? "",
        ENT_QUOTES | ENT_SUBSTITUTE,
        "UTF-8"
    );
}

function is_logged_in(): bool
{
    return isset($_SESSION["user_id"], $_SESSION["role"]);
}

function session_account_is_active(): bool
{
    global $pdo;

    if (!isset($_SESSION["user_id"])) {
        return false;
    }

    $stmt = $pdo->prepare(
        "SELECT role, status FROM users WHERE id = ? LIMIT 1"
    );
    $stmt->execute([(int) $_SESSION["user_id"]]);
    $account = $stmt->fetch();

    return $account
        && $account["status"] === "active"
        && $account["role"] === $_SESSION["role"];
}

function dashboard_url(string $role): string
{
    return BASE_URL . ($role === "admin"
        ? "/admin/dashboard.php"
        : "/student/dashboard.php");
}

function redirect(string $url): void
{
    header("Location: " . $url);
    exit;
}

function redirect_if_logged_in(): void
{
    if (is_logged_in()) {
        redirect(dashboard_url((string) $_SESSION["role"]));
    }
}

function require_login(string $loginPage = "/login.php"): void
{
    if (!is_logged_in()) {
        redirect(BASE_URL . $loginPage);
    }

    if (!session_account_is_active()) {
        logout_user();
        redirect(BASE_URL . $loginPage);
    }
}

function require_role(string $role): void
{
    if (!is_logged_in()) {
        redirect(BASE_URL . ($role === "admin" ? "/admin/login.php" : "/login.php"));
    }

    if (!session_account_is_active()) {
        $loginPage = ($_SESSION["role"] ?? "") === "admin"
            ? "/admin/login.php"
            : "/login.php";
        logout_user();
        redirect(BASE_URL . $loginPage);
    }

    if ($_SESSION["role"] !== $role) {
        redirect(dashboard_url((string) $_SESSION["role"]));
    }
}

function attempt_login(PDO $pdo, string $email, string $password, string $role): ?array
{
    $email = normalize_login_email($email);

    // Fixed dummy hash so unknown accounts do not trigger a fresh bcrypt hash.
    $dummyHash = '$2y$12$p7R1yF4qesO8j0HnK34LneuuzFyaZFqMVE/b4jEPtxe4H80h9tFei';

    $stmt = $pdo->prepare(
        "SELECT id, first_name, last_name, email, password, role, status
         FROM users WHERE email = ? LIMIT 1"
    );
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    $hash = $user["password"] ?? $dummyHash;
    $valid = password_verify($password, $hash);

    if (!$user || !$valid || $user["role"] !== $role || $user["status"] !== "active") {
        return null;
    }

    if (password_needs_rehash($user["password"], PASSWORD_DEFAULT)) {
        $upd = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
        $upd->execute([password_hash($password, PASSWORD_DEFAULT), $user["id"]]);
    }

    return $user;
}

function start_user_session(array $user): void
{
    session_regenerate_id(true);

    $_SESSION["user_id"] = (int) $user["id"];
    $_SESSION["role"] = $user["role"];
    $_SESSION["name"] = trim($user["first_name"] . " " . $user["last_name"]);
    $_SESSION["email"] = $user["email"];
    $_SESSION["csrf"] = bin2hex(random_bytes(32));
}

function logout_user(): void
{
    $_SESSION = [];

    if (ini_get("session.use_cookies")) {
        $p = session_get_cookie_params();
        setcookie(session_name(), "", [
            "expires" => time() - 42000,
            "path" => $p["path"],
            "domain" => $p["domain"] ?? "",
            "secure" => $p["secure"],
            "httponly" => $p["httponly"],
            "samesite" => $p["samesite"] ?? "Lax",
        ]);
    }

    session_destroy();
}

function csrf_token(): string
{
    if (empty($_SESSION["csrf"])) {
        $_SESSION["csrf"] = bin2hex(random_bytes(32));
    }

    return $_SESSION["csrf"];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_valid(): bool
{
    return isset($_POST["csrf"], $_SESSION["csrf"])
        && is_string($_POST["csrf"])
        && hash_equals($_SESSION["csrf"], $_POST["csrf"]);
}
