<?php
/**
 * Student portal layout (top half). Set these before including:
 *   $pageTitle  - heading shown in the top bar
 *   $activeNav  - dashboard | profile | enroll | requirements | tracking
 */
require_once __DIR__ . "/student_helpers.php";
require_once __DIR__ . "/brand.php";
require_once __DIR__ . "/notifications.php";
require_role("student");
$notificationSummary = get_notification_summary($pdo, (int) $_SESSION["user_id"]);

// Buffer output so pages can still redirect after this header has been included.
ob_start();

$pageTitle = $pageTitle ?? "Student Portal";
$activeNav = $activeNav ?? "";
$initial   = strtoupper(substr($_SESSION["name"], 0, 1));

$nav = [
    "dashboard"    => ["/student/dashboard.php",    "fa-house",            "Dashboard"],
    "notifications" => ["/student/notifications.php", "fa-bell", "Notifications"],
    "profile"      => ["/student/profile.php",      "fa-user",             "My Profile"],
    "enroll"       => ["/student/enroll.php",       "fa-file-signature",   "Enroll"],
    "requirements" => ["/student/requirements.php", "fa-folder-open",      "Requirements"],
    "tracking"     => ["/student/tracking.php",     "fa-route",            "Track Enrollment"],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?= e(csrf_token()) ?>">
    <title><?= e($pageTitle) ?> | UniPortal</title>
    <link rel="icon" href="<?= BASE_URL ?>/assets/images/uniportal-mark.svg" type="image/svg+xml">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/student.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/confirm.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/brand.css?v=1">
    <script src="<?= BASE_URL ?>/assets/js/logout-confirm.js" defer></script>
    <script src="<?= BASE_URL ?>/assets/js/student-notifications.js" defer></script>
</head>
<body>
<div class="dashboard">

    <aside class="sidebar">
        <?= uniportal_brand("Student Portal", BASE_URL . "/student/dashboard.php", "brand-lockup brand-lockup--sidebar", "UniPortal student dashboard") ?>

        <div class="menu-label">MAIN MENU</div>
        <nav>
            <?php foreach ($nav as $key => [$href, $icon, $label]): ?>
                <a href="<?= BASE_URL . $href ?>"
                   class="nav-link<?= $key === $activeNav ? " active" : "" ?>">
                    <i class="fas <?= $icon ?>"></i><span><?= $label ?></span>
                </a>
            <?php endforeach; ?>
        </nav>

        <div class="menu-label">ACCOUNT</div>
        <nav>
            <a href="<?= BASE_URL ?>/logout.php" class="nav-link" data-confirm-logout>
                <i class="fas fa-right-from-bracket"></i><span>Log Out</span>
            </a>
        </nav>

        <div class="sidebar-bottom">
            <div class="profile">
                <div class="avatar"><?= e($initial) ?></div>
                <div><strong><?= e($_SESSION["name"]) ?></strong><span>Student</span></div>
            </div>
        </div>
    </aside>

    <dialog class="confirm-dialog" id="logout-confirm-dialog" aria-labelledby="logout-confirm-title" aria-describedby="logout-confirm-message">
        <div class="confirm-icon"><i class="fas fa-right-from-bracket" aria-hidden="true"></i></div>
        <h2 id="logout-confirm-title">Log out?</h2>
        <p id="logout-confirm-message">Are you sure you want to log out of your account?</p>
        <div class="confirm-actions">
            <button type="button" class="confirm-button secondary" data-cancel-logout>Stay logged in</button>
            <button type="button" class="confirm-button primary" data-accept-logout>Log out</button>
        </div>
    </dialog>

    <main class="main-content">
        <header class="topbar">
            <div>
                <p class="breadcrumb">Student / <?= e($pageTitle) ?></p>
                <h1><?= e($pageTitle) ?></h1>
            </div>
            <div class="student-notification" data-notification-widget>
                <button class="notification-toggle" type="button" aria-expanded="false" aria-controls="student-notification-panel" data-notification-toggle>
                    <i class="fas fa-bell" aria-hidden="true"></i>
                    <span class="sr-only">Notifications</span>
                    <?php if ($notificationSummary["unread"] > 0): ?>
                        <span class="notification-count"><?= $notificationSummary["unread"] > 99 ? "99+" : (int) $notificationSummary["unread"] ?></span>
                    <?php endif; ?>
                </button>
                <div class="notification-panel" id="student-notification-panel" hidden data-notification-panel>
                    <div class="notification-panel-head">
                        <strong>Notifications</strong>
                        <span><?= (int) $notificationSummary["unread"] ?> unread</span>
                    </div>
                    <?php if ($notificationSummary["recent"]): ?>
                        <div class="notification-list">
                            <?php foreach ($notificationSummary["recent"] as $notice): ?>
                                <a class="notification-item<?= (int) $notice["is_read"] === 0 ? " unread" : "" ?>" href="<?= e(notification_url($notice["link_url"] ?? null)) ?>">
                                    <span class="notification-item-title"><?= e($notice["title"]) ?></span>
                                    <span class="notification-item-message"><?= e($notice["message"]) ?></span>
                                    <time datetime="<?= e(date(DATE_ATOM, strtotime($notice["created_at"]))) ?>"><?= e(date("M d, Y g:i A", strtotime($notice["created_at"]))) ?></time>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <p class="notification-empty">You're all caught up. New enrollment updates will appear here.</p>
                    <?php endif; ?>
                    <a class="notification-view-all" href="<?= BASE_URL ?>/student/notifications.php">View all notifications</a>
                </div>
            </div>
        </header>

        <?= flash_render() ?>
