<?php
/**
 * Shared UniPortal branding.
 * Every public, student, and admin surface uses this same local SVG mark.
 */

if (!function_exists("uniportal_brand_mark")) {
    function uniportal_brand_mark(string $class = "brand-lockup__mark"): string
    {
        $src = BASE_URL . "/assets/images/uniportal-mark.svg";
        return '<img class="' . e($class) . '" src="' . e($src) . '" alt="" width="48" height="48" aria-hidden="true">';
    }
}

if (!function_exists("uniportal_brand")) {
    function uniportal_brand(
        string $subtitle,
        string $href,
        string $class = "brand-lockup",
        string $ariaLabel = "UniPortal home",
        string $id = ""
    ): string {
        $idAttribute = $id !== "" ? ' id="' . e($id) . '"' : "";
        return '<a class="' . e($class) . '" href="' . e($href) . '" aria-label="' . e($ariaLabel) . '"' . $idAttribute . '>'
            . uniportal_brand_mark()
            . '<span class="brand-lockup__copy"><strong class="brand-lockup__name">UniPortal</strong><small class="brand-lockup__subtitle">' . e($subtitle) . '</small></span>'
            . '</a>';
    }
}
