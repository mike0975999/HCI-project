<?php

declare(strict_types=1);

/**
 * Student notification helpers.
 * Create notifications inside the same transaction as the event being recorded.
 */
function create_notification(
    PDO $pdo,
    int $userId,
    ?int $enrollmentId,
    string $type,
    string $title,
    string $message,
    ?string $linkUrl = null
): void {
    $allowedTypes = [
        "application_submitted",
        "document_submitted",
        "document_verified",
        "document_rejected",
        "application_approved",
        "application_rejected",
        "application_cancelled",
    ];

    if (!in_array($type, $allowedTypes, true)) {
        throw new InvalidArgumentException("Unsupported notification type.");
    }

    // Only store links to the student portal; never accept arbitrary external URLs.
    if ($linkUrl !== null && (!preg_match('~^/student/[a-zA-Z0-9_./-]*$~', $linkUrl) || str_contains($linkUrl, '..') || str_contains($linkUrl, '//'))) {
        throw new InvalidArgumentException("Notification link must be a local student portal path.");
    }

    $stmt = $pdo->prepare(
        "INSERT INTO notifications
            (user_id, enrollment_id, type, title, message, link_url)
         VALUES (?, ?, ?, ?, ?, ?)"
    );
    $safeTitle = function_exists("mb_substr")
        ? mb_substr($title, 0, 160, "UTF-8")
        : substr($title, 0, 160);
    $safeMessage = function_exists("mb_substr")
        ? mb_substr($message, 0, 1000, "UTF-8")
        : substr($message, 0, 1000);

    $stmt->execute([
        $userId,
        $enrollmentId,
        $type,
        $safeTitle,
        $safeMessage,
        $linkUrl,
    ]);
}

/** Return unread count and the five most recent notifications for a student. */
function get_notification_summary(PDO $pdo, int $userId): array
{
    $count = $pdo->prepare(
        "SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0"
    );
    $count->execute([$userId]);

    $recent = $pdo->prepare(
        "SELECT id, type, title, message, link_url, is_read, created_at
         FROM notifications
         WHERE user_id = ?
         ORDER BY created_at DESC, id DESC
         LIMIT 5"
    );
    $recent->execute([$userId]);

    return [
        "unread" => (int) $count->fetchColumn(),
        "recent" => $recent->fetchAll(PDO::FETCH_ASSOC),
    ];
}

/** Build a safe internal notification URL. */
function notification_url(?string $linkUrl): string
{
    if (!$linkUrl || !preg_match('~^/student/[a-zA-Z0-9_./-]*$~', $linkUrl) || str_contains($linkUrl, '..') || str_contains($linkUrl, '//')) {
        return BASE_URL . "/student/notifications.php";
    }

    return BASE_URL . $linkUrl;
}

/** Convert stored event types to readable labels. */
function notification_type_label(string $type): string
{
    $labels = [
        "application_submitted" => "Application submitted",
        "document_submitted" => "Document submitted",
        "document_verified" => "Document verified",
        "document_rejected" => "Document rejected",
        "application_approved" => "Application approved",
        "application_rejected" => "Application rejected",
        "application_cancelled" => "Application cancelled",
    ];

    return $labels[$type] ?? "Enrollment update";
}
