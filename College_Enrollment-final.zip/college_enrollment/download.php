<?php

/**
 * Serves an uploaded requirement document.
 * Only the student who owns it, or an admin, may open it.
 */

declare(strict_types=1);

require_once __DIR__ . "/includes/auth.php";
require_login();

$id = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    http_response_code(400);
    exit("Invalid document.");
}

$stmt = $pdo->prepare(
    "SELECT er.file_path, er.id, e.student_id
     FROM enrollment_requirements er
     JOIN enrollments e ON e.id = er.enrollment_id
     WHERE er.id = ?
     LIMIT 1"
);
$stmt->execute([$id]);
$row = $stmt->fetch();

if (!$row || empty($row["file_path"])) {
    http_response_code(404);
    exit("File not found.");
}

if ($_SESSION["role"] !== "admin"
    && (int) $row["student_id"] !== (int) $_SESSION["user_id"]) {
    http_response_code(403);
    exit("You don't have access to this file.");
}

$base = realpath(__DIR__ . "/uploads");
$full = realpath(__DIR__ . "/" . $row["file_path"]);

if (!$base || !$full
    || strpos($full, $base . DIRECTORY_SEPARATOR) !== 0
    || !is_file($full)) {
    http_response_code(404);
    exit("This file is no longer available.");
}

$finfo = new finfo(FILEINFO_MIME_TYPE);
$mime = $finfo->file($full);

$allowedMimes = [
    "application/pdf" => "pdf",
    "image/jpeg" => "jpg",
    "image/png" => "png",
];

if (!isset($allowedMimes[$mime])) {
    http_response_code(415);
    exit("Unsupported document type.");
}

$extension = $allowedMimes[$mime];

header("Content-Type: " . $mime);
header("Content-Length: " . filesize($full));
header("Content-Disposition: inline; filename=\"document-" . (int) $id . "." . $extension . "\"");
header("Cache-Control: private, no-store, no-cache, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");
header("X-Content-Type-Options: nosniff");
header("Content-Security-Policy: default-src 'none'; frame-ancestors 'self';");

readfile($full);
exit;
