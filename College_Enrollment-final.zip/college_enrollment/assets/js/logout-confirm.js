(() => {
    const logoutDialog = document.getElementById("logout-confirm-dialog");
    const cancelButton = logoutDialog?.querySelector("[data-cancel-logout]");
    const acceptButton = logoutDialog?.querySelector("[data-accept-logout]");
    const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute("content") || "";

    if (logoutDialog && cancelButton && acceptButton) {
        let logoutUrl = "";

        document.querySelectorAll("[data-confirm-logout]").forEach((link) => {
            link.addEventListener("click", (event) => {
                event.preventDefault();
                logoutUrl = link.href;
                logoutDialog.showModal();
                cancelButton.focus();
            });
        });

        cancelButton.addEventListener("click", () => {
            logoutUrl = "";
            logoutDialog.close();
        });

        acceptButton.addEventListener("click", () => {
            if (!logoutUrl || !csrfToken) {
                window.alert("Security token is missing. Please refresh the page and try again.");
                return;
            }

            const form = document.createElement("form");
            form.method = "POST";
            form.action = logoutUrl;
            form.style.display = "none";

            const input = document.createElement("input");
            input.type = "hidden";
            input.name = "csrf";
            input.value = csrfToken;
            form.appendChild(input);

            document.body.appendChild(form);
            form.submit();
        });
    }

    document.querySelectorAll("[data-confirm-submit]").forEach((form) => {
        form.addEventListener("submit", (event) => {
            const message = form.getAttribute("data-confirm-submit");
            if (message && !window.confirm(message)) {
                event.preventDefault();
            }
        });
    });
})();
