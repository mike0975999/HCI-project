(() => {
    let timer = null;
    let controller = null;
    let requestNumber = 0;

    const selector = 'form[data-live-search]';
    const resultsSelector = "#admin-search-content";

    async function refresh(form) {
        const currentResults = document.querySelector(resultsSelector);
        if (!currentResults) {
            form.submit();
            return;
        }

        if (controller) controller.abort();
        controller = new AbortController();
        const thisRequest = ++requestNumber;

        const focused = document.activeElement;
        const fieldName = focused && form.contains(focused) ? focused.name : "";
        const caret = fieldName && typeof focused.selectionStart === "number" ? focused.selectionStart : null;

        const url = new URL(form.action || window.location.href, window.location.href);
        url.search = new URLSearchParams(new FormData(form)).toString();
        url.searchParams.delete("page");
        const targetUrl = url.toString();

        currentResults.setAttribute("aria-busy", "true");
        currentResults.classList.add("is-searching");

        try {
            const response = await fetch(targetUrl, {
                method: "GET",
                credentials: "same-origin",
                headers: { "X-Requested-With": "XMLHttpRequest" },
                signal: controller.signal
            });
            if (!response.ok) throw new Error("Search request failed");

            const html = await response.text();
            if (thisRequest !== requestNumber) return;

            const parsed = new DOMParser().parseFromString(html, "text/html");
            const incoming = parsed.querySelector(resultsSelector);
            const live = document.querySelector(resultsSelector);
            if (!incoming || !live) throw new Error("Search results were not found");

            live.replaceWith(incoming);
            history.replaceState({}, "", targetUrl);

            if (fieldName) {
                const replacement = document.querySelector(`${selector} [name="${CSS.escape(fieldName)}"]`);
                if (replacement) {
                    replacement.focus({ preventScroll: true });
                    if (caret !== null && typeof replacement.setSelectionRange === "function") {
                        replacement.setSelectionRange(caret, caret);
                    }
                }
            }
        } catch (error) {
            if (error.name !== "AbortError") {
                // Keep the normal form behavior available when JavaScript/AJAX fails.
                form.submit();
            }
        } finally {
            const current = document.querySelector(resultsSelector);
            if (current) {
                current.removeAttribute("aria-busy");
                current.classList.remove("is-searching");
            }
        }
    }

    document.addEventListener("input", (event) => {
        const form = event.target.closest(selector);
        if (!form || event.target.type !== "search") return;
        window.clearTimeout(timer);
        timer = window.setTimeout(() => refresh(form), 350);
    });

    document.addEventListener("change", (event) => {
        const form = event.target.closest(selector);
        if (!form) return;
        if (event.target.matches("select")) {
            window.clearTimeout(timer);
            refresh(form);
        }
    });

    document.addEventListener("submit", (event) => {
        const form = event.target.closest(selector);
        if (!form) return;
        event.preventDefault();
        window.clearTimeout(timer);
        refresh(form);
    });
})();
