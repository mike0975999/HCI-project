document.querySelectorAll("[data-dismiss-after]").forEach((alert) => {
    const delay = Number.parseInt(alert.dataset.dismissAfter, 10);
    if (Number.isFinite(delay) && delay > 0) {
        window.setTimeout(() => alert.remove(), delay);
    }
});
