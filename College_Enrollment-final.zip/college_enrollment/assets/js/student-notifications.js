(() => {
    const widget = document.querySelector("[data-notification-widget]");
    if (!widget) return;

    const toggle = widget.querySelector("[data-notification-toggle]");
    const panel = widget.querySelector("[data-notification-panel]");
    if (!toggle || !panel) return;

    const close = () => {
        panel.hidden = true;
        toggle.setAttribute("aria-expanded", "false");
    };

    toggle.addEventListener("click", () => {
        const willOpen = panel.hidden;
        panel.hidden = !willOpen;
        toggle.setAttribute("aria-expanded", willOpen ? "true" : "false");
    });

    document.addEventListener("click", (event) => {
        if (!widget.contains(event.target)) close();
    });

    document.addEventListener("keydown", (event) => {
        if (event.key === "Escape") close();
    });
})();
