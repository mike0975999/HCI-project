document.addEventListener("click", event => {
    const link = event.target.closest('.public-nav-links a[href="#announcements"]');
    const section = document.getElementById("announcements");

    if (!link || !section) {
        return;
    }

    event.preventDefault();
    history.replaceState(null, "", "#announcements");
    window.scrollTo(0, section.offsetTop);
});
