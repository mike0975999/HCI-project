<?php
require_once __DIR__ . "/includes/auth.php";

if (is_logged_in()) {
    if (session_account_is_active()) {
        redirect(dashboard_url($_SESSION["role"]));
    }

    $loginPage = ($_SESSION["role"] ?? "") === "admin" ? "/admin/login.php" : "/login.php";
    logout_user();
    redirect(BASE_URL . $loginPage);
}

redirect(BASE_URL . "/login.php");
