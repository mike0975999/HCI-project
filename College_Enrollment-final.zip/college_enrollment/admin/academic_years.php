<?php
declare(strict_types=1);
require_once __DIR__ . "/auth_check.php";

$error = "";
$editYear = null;
$editId = (int) ($_GET["edit"] ?? 0);

function valid_academic_year_input(string $name, string $startDate, string $endDate): bool
{
    if (!preg_match('/^(\d{4})-(\d{4})$/', $name, $matches)) return false;
    if ((int) $matches[2] !== (int) $matches[1] + 1) return false;
    $start = DateTimeImmutable::createFromFormat("!Y-m-d", $startDate);
    $end = DateTimeImmutable::createFromFormat("!Y-m-d", $endDate);
    $startErrors = DateTimeImmutable::getLastErrors();
    $endErrors = DateTimeImmutable::getLastErrors();
    return $start && $end
        && ($startErrors === false || ($startErrors["warning_count"] === 0 && $startErrors["error_count"] === 0))
        && ($endErrors === false || ($endErrors["warning_count"] === 0 && $endErrors["error_count"] === 0))
        && $start->format("Y-m-d") === $startDate
        && $end->format("Y-m-d") === $endDate
        && $startDate <= $endDate;
}

function academic_year_overlaps(PDO $pdo, string $startDate, string $endDate, int $excludeId = 0): bool
{
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM academic_years
         WHERE id <> ? AND start_date <= ? AND end_date >= ?"
    );
    $stmt->execute([$excludeId, $endDate, $startDate]);
    return (int) $stmt->fetchColumn() > 0;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $action = (string) ($_POST["action"] ?? "");
    if (!csrf_valid()) {
        $error = "Your session expired. Please refresh and try again.";
    } elseif (in_array($action, ["create_year", "update_year"], true)) {
        $yearId = (int) ($_POST["academic_year_id"] ?? 0);
        $name = trim((string) ($_POST["name"] ?? ""));
        $startDate = (string) ($_POST["start_date"] ?? "");
        $endDate = (string) ($_POST["end_date"] ?? "");

        if (!valid_academic_year_input($name, $startDate, $endDate)) {
            $error = "Enter a consecutive academic-year name (for example, 2027-2028) and valid dates. The end date must not be before the start date.";
        } elseif (academic_year_overlaps($pdo, $startDate, $endDate, $action === "update_year" ? $yearId : 0)) {
            $error = "These dates overlap another configured academic year.";
        } else {
            try {
                if ($action === "create_year") {
                    $stmt = $pdo->prepare("INSERT INTO academic_years (name, start_date, end_date, is_active) VALUES (?, ?, ?, 0)");
                    $stmt->execute([$name, $startDate, $endDate]);
                    $_SESSION["admin_flash"] = ["success", "Academic year " . $name . " was created as inactive."];
                } else {
                    $check = $pdo->prepare("SELECT COUNT(*) FROM enrollments WHERE academic_year_id = ?");
                    $check->execute([$yearId]);
                    if ($yearId < 1 || (int) $check->fetchColumn() > 0) {
                        throw new RuntimeException("Academic years with application history are locked to preserve historical records.");
                    }
                    $stmt = $pdo->prepare("UPDATE academic_years SET name = ?, start_date = ?, end_date = ? WHERE id = ?");
                    $stmt->execute([$name, $startDate, $endDate, $yearId]);
                    if ($stmt->rowCount() === 0) {
                        $exists = $pdo->prepare("SELECT COUNT(*) FROM academic_years WHERE id = ?");
                        $exists->execute([$yearId]);
                        if (!(int) $exists->fetchColumn()) throw new RuntimeException("Academic year not found.");
                    }
                    $_SESSION["admin_flash"] = ["success", "Academic year updated. It remains in its previous active/inactive state."];
                }
                header("Location: academic_years.php"); exit;
            } catch (RuntimeException $exception) {
                $error = $exception->getMessage();
            } catch (PDOException $exception) {
                if ($exception->getCode() === "23000") $error = "That academic-year name already exists.";
                else { error_log("Academic year save failed: " . $exception->getMessage()); $error = "The academic year could not be saved."; }
            }
        }
        $editId = $action === "update_year" ? $yearId : 0;
    } elseif ($action === "delete_year") {
        $yearId = (int) ($_POST["academic_year_id"] ?? 0);
        $stmt = $pdo->prepare("SELECT is_active FROM academic_years WHERE id = ?");
        $stmt->execute([$yearId]);
        $year = $stmt->fetch(PDO::FETCH_ASSOC);
        $applications = $pdo->prepare("SELECT COUNT(*) FROM enrollments WHERE academic_year_id = ?");
        $applications->execute([$yearId]);
        if (!$year) $error = "Academic year not found.";
        elseif ((int) $year["is_active"] === 1) $error = "The active academic year cannot be deleted. Set another year active first.";
        elseif ((int) $applications->fetchColumn() > 0) $error = "This academic year has application history and cannot be deleted.";
        else {
            try {
                $pdo->prepare("DELETE FROM academic_years WHERE id = ?")->execute([$yearId]);
                $_SESSION["admin_flash"] = ["success", "Academic year permanently deleted."];
                header("Location: academic_years.php"); exit;
            } catch (PDOException $exception) {
                error_log("Academic year deletion failed: " . $exception->getMessage());
                $error = "The academic year could not be deleted because it is still referenced by an application.";
            }
        }
    } elseif ($action === "set_active") {
        $yearId = (int) ($_POST["academic_year_id"] ?? 0);
        try {
            $pdo->beginTransaction();
            $pdo->query("SELECT id FROM academic_years FOR UPDATE")->fetchAll(PDO::FETCH_COLUMN);
            $lock = $pdo->prepare("SELECT id, name FROM academic_years WHERE id = ? FOR UPDATE");
            $lock->execute([$yearId]);
            $selectedYear = $lock->fetch(PDO::FETCH_ASSOC);
            if (!$selectedYear) throw new RuntimeException("The selected academic year does not exist.");
            $pdo->exec("UPDATE academic_years SET is_active = 0 WHERE is_active = 1");
            $pdo->prepare("UPDATE academic_years SET is_active = 1 WHERE id = ?")->execute([$yearId]);
            $pdo->commit();
            $_SESSION["admin_flash"] = ["success", "Academic year " . $selectedYear["name"] . " is now active for new applications."];
            header("Location: academic_years.php"); exit;
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            if ($exception instanceof RuntimeException) $error = $exception->getMessage();
            else { error_log("Academic year activation failed: " . $exception->getMessage()); $error = "The active academic year could not be changed."; }
        }
    } else {
        $error = "Unknown academic-year action.";
    }
}

$yearSearch = trim((string) ($_GET["search"] ?? ""));
$yearSql =
    "SELECT ay.id, ay.name, ay.start_date, ay.end_date, ay.is_active,
            COUNT(e.id) AS application_count
     FROM academic_years ay LEFT JOIN enrollments e ON e.academic_year_id = ay.id";
if ($yearSearch !== "") $yearSql .= " WHERE ay.name LIKE ?";
$yearSql .= " GROUP BY ay.id, ay.name, ay.start_date, ay.end_date, ay.is_active
              ORDER BY ay.start_date DESC, ay.id DESC";
$yearStmt = $pdo->prepare($yearSql);
$yearStmt->execute($yearSearch !== "" ? ["%" . $yearSearch . "%"] : []);
$years = $yearStmt->fetchAll(PDO::FETCH_ASSOC);
$activeCount = (int) $pdo->query("SELECT COUNT(*) FROM academic_years WHERE is_active = 1")->fetchColumn();

if ($editId > 0) {
    $stmt = $pdo->prepare(
        "SELECT ay.*, (SELECT COUNT(*) FROM enrollments e WHERE e.academic_year_id = ay.id) AS application_count
         FROM academic_years ay WHERE ay.id = ?"
    );
    $stmt->execute([$editId]); $editYear = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    if (!$editYear) $error = "Academic year not found.";
    elseif ((int) $editYear["application_count"] > 0) { $error = "This academic year has application history and is locked to preserve historical records."; $editYear = null; }
}

$pageTitle = "Academic Years"; $activeNav = "academic_years";
require __DIR__ . "/header.php";
?>
<?php if ($error !== ""): ?><div class="admin-alert error"><?= e($error) ?></div><?php endif; ?>
<section class="admin-panel">
    <div class="admin-panel-head"><div><h2><?= $editYear ? "Edit academic year" : "Create academic year" ?></h2><p><?= $editYear ? "Only years without application history can be edited." : "Create an academic-year record. New years remain inactive until explicitly activated." ?></p></div></div>
    <form method="POST" class="admin-student-form">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="<?= $editYear ? "update_year" : "create_year" ?>">
        <?php if ($editYear): ?><input type="hidden" name="academic_year_id" value="<?= (int) $editYear["id"] ?>"><?php endif; ?>
        <div class="admin-field"><label for="year_name">Academic-year name *</label><input id="year_name" name="name" type="text" maxlength="20" placeholder="2027-2028" pattern="[0-9]{4}-[0-9]{4}" value="<?= e($editYear["name"] ?? "") ?>" required></div>
        <div class="admin-field"><label for="year_start">Start date *</label><input id="year_start" name="start_date" type="date" value="<?= e($editYear["start_date"] ?? "") ?>" required></div>
        <div class="admin-field"><label for="year_end">End date *</label><input id="year_end" name="end_date" type="date" value="<?= e($editYear["end_date"] ?? "") ?>" required></div>
        <div class="admin-form-actions"><button class="admin-btn" type="submit"><?= $editYear ? "Save changes" : "Create academic year" ?></button><?php if ($editYear): ?><a class="admin-btn secondary" href="academic_years.php">Cancel edit</a><?php endif; ?></div>
    </form>
</section>
<div id="admin-search-content" aria-live="polite" aria-busy="false">
<section class="admin-panel">
    <div class="admin-panel-head"><div><h2>Academic-year records</h2><p>Active year controls new applications. Historical years with applications cannot be edited or deleted.</p></div></div>
    <form method="GET" action="academic_years.php" class="admin-form" data-live-search>
        <label class="sr-only" for="academic-year-search">Search academic years</label>
        <input id="academic-year-search" type="search" name="search" value="<?= e($yearSearch) ?>" placeholder="Search academic-year name" autocomplete="off">
        <?php if ($yearSearch !== ""): ?><a class="admin-btn secondary" href="academic_years.php">Clear</a><?php endif; ?>
    </form>
    <?php if ($activeCount === 0): ?><div class="admin-alert error">No academic year is currently active. Students cannot submit new applications.</div><?php elseif ($activeCount > 1): ?><div class="admin-alert error">More than one academic year is marked active. Review the database configuration.</div><?php endif; ?>
    <?php if ($years): ?>
    <div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Academic year</th><th>Start date</th><th>End date</th><th>Applications</th><th>Status</th><th>Actions</th></tr></thead><tbody>
    <?php foreach ($years as $year): $hasHistory = (int) $year["application_count"] > 0; ?>
        <tr><td><strong><?= e($year["name"]) ?></strong></td><td><?= e(date("M d, Y", strtotime($year["start_date"]))) ?></td><td><?= e(date("M d, Y", strtotime($year["end_date"]))) ?></td><td><?= (int) $year["application_count"] ?></td>
        <td><span class="admin-badge <?= (int) $year["is_active"] === 1 ? "active" : "inactive" ?>"><?= (int) $year["is_active"] === 1 ? "Active" : "Inactive" ?></span></td>
        <td><div class="admin-actions">
            <?php if (!$hasHistory): ?><a class="admin-btn secondary small" href="academic_years.php?edit=<?= (int) $year["id"] ?>">Edit</a><?php else: ?><span class="admin-muted">Historical record</span><?php endif; ?>
            <?php if ((int) $year["is_active"] !== 1): ?>
                <form method="POST" class="admin-inline" data-confirm-submit="Set this as the active academic year? New applications will use this year."><?= csrf_field() ?><input type="hidden" name="action" value="set_active"><input type="hidden" name="academic_year_id" value="<?= (int) $year["id"] ?>"><button class="admin-btn small" type="submit">Set active</button></form>
            <?php endif; ?>
            <?php if (!$hasHistory && (int) $year["is_active"] !== 1): ?>
                <form method="POST" class="admin-inline" data-confirm-submit="Permanently delete this unused academic year?"><?= csrf_field() ?><input type="hidden" name="action" value="delete_year"><input type="hidden" name="academic_year_id" value="<?= (int) $year["id"] ?>"><button class="admin-btn danger small" type="submit">Delete</button></form>
            <?php endif; ?>
        </div></td></tr>
    <?php endforeach; ?>
    </tbody></table></div>
    <?php else: ?><div class="admin-empty">No academic years have been configured yet.</div><?php endif; ?>
</section>
</div>
<?php require __DIR__ . "/footer.php"; ?>
