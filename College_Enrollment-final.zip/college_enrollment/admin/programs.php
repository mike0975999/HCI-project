<?php
declare(strict_types=1);
require_once __DIR__ . "/auth_check.php";

$search = trim((string) ($_GET["search"] ?? ""));
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $action = (string) ($_POST["action"] ?? "");
    $programId = (int) ($_POST["program_id"] ?? 0);

    if (!csrf_valid()) {
        $error = "Your session expired. Please refresh and try again.";
    } elseif ($programId < 1) {
        $error = "Choose a valid program.";
    } elseif ($action === "toggle_program") {
        $stmt = $pdo->prepare("SELECT is_active, code FROM programs WHERE id = ? FOR UPDATE");
        $stmt->execute([$programId]);
        $program = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$program) {
            $error = "Program not found.";
        } else {
            $next = (int) $program["is_active"] === 1 ? 0 : 1;
            if ($next === 0 && (int) $pdo->query("SELECT COUNT(*) FROM programs WHERE is_active = 1")->fetchColumn() <= 1) {
                $error = "At least one active program must remain available for enrollment.";
            }
            if ($error === "") {
            $update = $pdo->prepare("UPDATE programs SET is_active = ? WHERE id = ?");
            $update->execute([$next, $programId]);
            $_SESSION["admin_flash"] = ["success", "Program " . $program["code"] . ($next ? " was activated for future applications." : " was archived. Existing applications were kept.")];
            header("Location: programs.php");
            exit;
            }
        }
    } elseif ($action === "delete_program") {
        $count = $pdo->prepare("SELECT COUNT(*) FROM enrollments WHERE program_id = ?");
        $count->execute([$programId]);
        if ((int) $count->fetchColumn() > 0) {
            $error = "This program has enrollment history and cannot be permanently deleted. Archive it instead.";
        } else {
            try {
                $delete = $pdo->prepare("DELETE FROM programs WHERE id = ?");
                $delete->execute([$programId]);
                $_SESSION["admin_flash"] = ["success", "Program permanently deleted."];
                header("Location: programs.php");
                exit;
            } catch (PDOException $exception) {
                error_log("Program deletion failed: " . $exception->getMessage());
                $error = "The program could not be deleted because it is still in use. Archive it instead.";
            }
        }
    } else {
        $error = "Unknown program action.";
    }
}

$where = "1 = 1";
$params = [];
if ($search !== "") {
    $where .= " AND (p.code LIKE ? OR p.name LIKE ? OR p.department LIKE ? OR p.description LIKE ?)";
    $term = "%" . $search . "%";
    $params = [$term, $term, $term, $term];
}
$stmt = $pdo->prepare(
    "SELECT p.*,
            (SELECT COUNT(*) FROM enrollments e WHERE e.program_id = p.id) AS application_count,
            (SELECT COUNT(*) FROM enrollments e WHERE e.program_id = p.id AND e.status IN ('pending','approved')) AS active_application_count
     FROM programs p WHERE $where ORDER BY p.is_active DESC, p.name ASC"
);
$stmt->execute($params);
$programs = $stmt->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = "Program Management";
$activeNav = "programs";
require __DIR__ . "/header.php";
?>
<div id="admin-search-content" aria-live="polite" aria-busy="false">
<section class="admin-panel">
    <div class="admin-panel-head">
        <div><h2>Programs</h2><p>Create, view, edit, archive, restore, or permanently remove program records. Archived programs are hidden from new enrollment forms; existing applications remain intact.</p></div>
        <a class="admin-btn" href="program_form.php"><i class="fas fa-plus"></i> Add program</a>
    </div>
    <?php if ($error !== ""): ?><div class="admin-alert error"><?= e($error) ?></div><?php endif; ?>
    <form method="GET" action="programs.php" class="admin-form" data-live-search>
        <label class="sr-only" for="program-search">Search programs</label>
        <input id="program-search" type="search" name="search" value="<?= e($search) ?>" placeholder="Search code, name, department or description" autocomplete="off">
        <?php if ($search !== ""): ?><a class="admin-btn secondary" href="programs.php">Clear</a><?php endif; ?>
    </form>
    <?php if ($programs): ?>
        <div class="admin-table-wrap"><table class="admin-table">
            <thead><tr><th>Program</th><th>Department</th><th>Duration</th><th>Slots</th><th>Applications</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
            <?php foreach ($programs as $program): ?>
                <tr>
                    <td><strong><?= e($program["code"]) ?></strong><span class="subline"><?= e($program["name"]) ?></span></td>
                    <td><?= e($program["department"] ?: "—") ?></td>
                    <td><?= (int) $program["duration_years"] ?> years</td>
                    <td><?= (int) $program["slots"] ?></td>
                    <td><?= (int) $program["application_count"] ?><span class="subline"><?= (int) $program["active_application_count"] ?> pending/approved</span></td>
                    <td><span class="admin-badge <?= (int) $program["is_active"] === 1 ? "active" : "inactive" ?>"><?= (int) $program["is_active"] === 1 ? "Active" : "Archived" ?></span></td>
                    <td><div class="admin-actions">
                        <a class="admin-btn secondary small" href="program_form.php?id=<?= (int) $program["id"] ?>">Edit</a>
                        <form method="POST" class="admin-inline" data-confirm-submit="<?= (int) $program["is_active"] === 1 ? "Archive this program? It will no longer appear for new applications." : "Restore this program for new applications?" ?>">
                            <?= csrf_field() ?><input type="hidden" name="action" value="toggle_program"><input type="hidden" name="program_id" value="<?= (int) $program["id"] ?>">
                            <button class="admin-btn small <?= (int) $program["is_active"] === 1 ? "danger" : "secondary" ?>" type="submit"><?= (int) $program["is_active"] === 1 ? "Archive" : "Restore" ?></button>
                        </form>
                        <?php if ((int) $program["application_count"] === 0): ?>
                            <form method="POST" class="admin-inline" data-confirm-submit="Permanently delete this program? This cannot be undone.">
                                <?= csrf_field() ?><input type="hidden" name="action" value="delete_program"><input type="hidden" name="program_id" value="<?= (int) $program["id"] ?>">
                                <button class="admin-btn danger small" type="submit">Delete</button>
                            </form>
                        <?php endif; ?>
                    </div></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div>
    <?php else: ?><div class="admin-empty">No programs matched your search. Add a program to begin.</div><?php endif; ?>
</section>
</div>
<?php require __DIR__ . "/footer.php"; ?>
