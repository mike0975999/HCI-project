<?php
declare(strict_types=1);
require_once __DIR__ . "/auth_check.php";

$programId = (int) ($_GET["id"] ?? $_POST["program_id"] ?? 0);
$isEdit = $programId > 0;
$program = ["code" => "", "name" => "", "description" => "", "department" => "", "duration_years" => 4, "slots" => 100, "is_active" => 1];
$error = "";

if ($isEdit) {
    $stmt = $pdo->prepare("SELECT * FROM programs WHERE id = ?");
    $stmt->execute([$programId]);
    $found = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$found) { http_response_code(404); exit("Program not found."); }
    $program = $found;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $program["code"] = strtoupper(trim((string) ($_POST["code"] ?? "")));
    $program["name"] = trim((string) ($_POST["name"] ?? ""));
    $program["description"] = trim((string) ($_POST["description"] ?? ""));
    $program["department"] = trim((string) ($_POST["department"] ?? ""));
    $program["duration_years"] = (int) ($_POST["duration_years"] ?? 0);
    $program["slots"] = (int) ($_POST["slots"] ?? -1);
    $program["is_active"] = isset($_POST["is_active"]) ? 1 : 0;

    if (!csrf_valid()) {
        $error = "Your session expired. Please refresh and try again.";
    } elseif (!preg_match('/^[A-Z0-9][A-Z0-9-]{1,19}$/', $program["code"])) {
        $error = "Program code must contain 2–20 letters, numbers, or hyphens.";
    } elseif ($program["name"] === "" || strlen($program["name"]) > 150 || strlen($program["department"]) > 100 || strlen($program["description"]) > 6000) {
        $error = "Enter a program name and keep the fields within their allowed lengths.";
    } elseif ($program["duration_years"] < 1 || $program["duration_years"] > 10 || $program["slots"] < 0 || $program["slots"] > 100000) {
        $error = "Duration must be 1–10 years and slots must be between 0 and 100,000.";
    }

    if ($error === "") {
        $duplicate = $pdo->prepare("SELECT id FROM programs WHERE (code = ? OR name = ?) AND id <> ? LIMIT 1");
        $duplicate->execute([$program["code"], $program["name"], $programId]);
        if ($duplicate->fetchColumn()) {
            $error = "That program code or name is already in use.";
        }
    }

    if ($error === "") {
        $activeCount = (int) $pdo->query("SELECT COUNT(*) FROM programs WHERE is_active = 1")->fetchColumn();
        $wasActive = false;
        if ($isEdit) {
            $currentActive = $pdo->prepare("SELECT is_active FROM programs WHERE id = ?");
            $currentActive->execute([$programId]);
            $wasActive = (int) $currentActive->fetchColumn() === 1;
        }
        $projectedActiveCount = $activeCount - ($wasActive ? 1 : 0) + (int) $program["is_active"];
        if ($projectedActiveCount < 1) {
            $error = "At least one active program must remain available for enrollment.";
        }
    }

    if ($error === "" && $isEdit) {
        $usage = $pdo->prepare(
            "SELECT COALESCE(MAX(year_level), 0) FROM enrollments WHERE program_id = ?"
        );
        $usage->execute([$programId]);
        if ($error === "" && (int) $usage->fetchColumn() > $program["duration_years"]) {
            $error = "Duration cannot be shorter than a year level already recorded in an application.";
        }
        $maxSeats = $pdo->prepare(
            "SELECT COALESCE(MAX(app_count), 0) FROM (
                SELECT COUNT(*) AS app_count FROM enrollments
                WHERE program_id = ? AND status IN ('pending','approved')
                GROUP BY academic_year_id
            ) AS year_counts"
        );
        $maxSeats->execute([$programId]);
        if ($error === "" && $program["slots"] < (int) $maxSeats->fetchColumn()) {
            $error = "Slots cannot be lower than the current pending/approved application count for an academic year.";
        }
    }

    if ($error === "") {
        try {
            if ($isEdit) {
                $save = $pdo->prepare(
                    "UPDATE programs SET code = ?, name = ?, description = ?, department = ?, duration_years = ?, slots = ?, is_active = ? WHERE id = ?"
                );
                $save->execute([$program["code"], $program["name"], $program["description"] ?: null, $program["department"] ?: null, $program["duration_years"], $program["slots"], $program["is_active"], $programId]);
            } else {
                $save = $pdo->prepare(
                    "INSERT INTO programs (code, name, description, department, duration_years, slots, is_active) VALUES (?, ?, ?, ?, ?, ?, ?)"
                );
                $save->execute([$program["code"], $program["name"], $program["description"] ?: null, $program["department"] ?: null, $program["duration_years"], $program["slots"], $program["is_active"]]);
            }
            $_SESSION["admin_flash"] = ["success", $isEdit ? "Program updated. Existing application snapshots remain unchanged." : "Program created successfully."];
            header("Location: programs.php");
            exit;
        } catch (PDOException $exception) {
            if ($exception->getCode() === "23000") { $error = "That program code or name is already in use."; }
            else { error_log("Program save failed: " . $exception->getMessage()); $error = "The program could not be saved. Please try again."; }
        }
    }
}

$pageTitle = $isEdit ? "Edit Program" : "Create Program";
$activeNav = "programs";
require __DIR__ . "/header.php";
?>
<section class="admin-panel">
    <div class="admin-panel-head"><div><h2><?= $isEdit ? "Update program details" : "Add a new program" ?></h2><p>Programs marked active appear on the student enrollment form. Changes apply to future applications only.</p></div></div>
    <?php if ($error !== ""): ?><div class="admin-alert error"><?= e($error) ?></div><?php endif; ?>
    <form method="POST" class="admin-student-form" autocomplete="off">
        <?= csrf_field() ?><?php if ($isEdit): ?><input type="hidden" name="program_id" value="<?= $programId ?>"><?php endif; ?>
        <div class="admin-field"><label for="code">Program code *</label><input id="code" name="code" maxlength="20" value="<?= e($program["code"]) ?>" placeholder="BSIT" required></div>
        <div class="admin-field"><label for="name">Program name *</label><input id="name" name="name" maxlength="150" value="<?= e($program["name"]) ?>" required></div>
        <div class="admin-field"><label for="department">Department</label><input id="department" name="department" maxlength="100" value="<?= e($program["department"] ?? "") ?>"></div>
        <div class="admin-field"><label for="duration_years">Duration (years) *</label><input id="duration_years" name="duration_years" type="number" min="1" max="10" value="<?= (int) $program["duration_years"] ?>" required></div>
        <div class="admin-field"><label for="slots">Available slots per academic year *</label><input id="slots" name="slots" type="number" min="0" max="100000" value="<?= (int) $program["slots"] ?>" required></div>
        <div class="admin-field"><label for="description">Description</label><textarea id="description" name="description" rows="4" maxlength="6000"><?= e($program["description"] ?? "") ?></textarea></div>
        <div class="admin-field admin-checkbox-field"><label><input type="checkbox" name="is_active" value="1" <?= (int) $program["is_active"] === 1 ? "checked" : "" ?>> Active for new applications</label></div>
        <div class="admin-form-actions"><button class="admin-btn" type="submit"><?= $isEdit ? "Save changes" : "Create program" ?></button><a class="admin-btn secondary" href="programs.php">Cancel</a></div>
    </form>
</section>
<?php require __DIR__ . "/footer.php"; ?>
