<?php
require_once __DIR__ . "/auth_check.php";

$search = trim($_GET["search"] ?? "");
$page = max(1, (int) ($_GET["page"] ?? 1));
$perPage = 20;
$offset = ($page - 1) * $perPage;
$actionError = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $postAction = (string) ($_POST["action"] ?? "");
    $studentId = (int) ($_POST["student_id"] ?? 0);
    if (!csrf_valid()) {
        $actionError = "Your session expired. Please try again.";
    } elseif ($studentId < 1) {
        $actionError = "Invalid student account.";
    } elseif ($postAction === "toggle_status") {
        $lookup = $pdo->prepare("SELECT status FROM users WHERE id = ? AND role = 'student'");
        $lookup->execute([$studentId]);
        $currentStatus = $lookup->fetchColumn();
        if (!in_array($currentStatus, ["active", "inactive"], true)) {
            $actionError = "Student account not found.";
        } else {
            $nextStatus = $currentStatus === "active" ? "inactive" : "active";
            $update = $pdo->prepare("UPDATE users SET status = ? WHERE id = ? AND role = 'student' AND status = ?");
            $update->execute([$nextStatus, $studentId, $currentStatus]);
            if ($update->rowCount() === 1) {
                $_SESSION["admin_flash"] = ["success", $nextStatus === "inactive" ? "Student archived (deactivated). Their applications and records were kept." : "Student account restored (activated)."];
                $query = http_build_query(array_filter(["search" => $search, "page" => $page > 1 ? $page : null], static fn($value) => $value !== null && $value !== ""));
                header("Location: students.php" . ($query !== "" ? "?" . $query : "")); exit;
            }
            $actionError = "Student account status changed. Refresh the directory and try again.";
        }
    } elseif ($postAction === "delete_student") {
        try {
            $pdo->beginTransaction();
            $lock = $pdo->prepare("SELECT id FROM users WHERE id = ? AND role = 'student' FOR UPDATE");
            $lock->execute([$studentId]);
            if (!$lock->fetchColumn()) throw new RuntimeException("Student account not found.");
            $appCount = $pdo->prepare("SELECT COUNT(*) FROM enrollments WHERE student_id = ?");
            $appCount->execute([$studentId]);
            if ((int) $appCount->fetchColumn() > 0) {
                throw new RuntimeException("This student has application history. Archive the account instead; permanent deletion is disabled to preserve records.");
            }
            $delete = $pdo->prepare("DELETE FROM users WHERE id = ? AND role = 'student'");
            $delete->execute([$studentId]);
            $pdo->commit();
            $_SESSION["admin_flash"] = ["success", "Student account permanently deleted because it had no enrollment history."];
            header("Location: students.php"); exit;
        } catch (RuntimeException $exception) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $actionError = $exception->getMessage();
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            error_log("Student deletion failed: " . $exception->getMessage());
            $actionError = "The student account could not be deleted.";
        }
    } elseif ($postAction !== "") {
        $actionError = "Unknown student action.";
    }
}

$where = "u.role = 'student'";
$params = [];

if ($search !== "") {
    $where .= " AND (u.first_name LIKE ? OR u.last_name LIKE ? OR u.email LIKE ?
                      OR sp.student_number LIKE ? OR sp.phone LIKE ?)";
    $term = "%" . $search . "%";
    $params = [$term, $term, $term, $term, $term];
}

$countStmt = $pdo->prepare(
    "SELECT COUNT(*) FROM users u
     LEFT JOIN student_profiles sp ON sp.user_id = u.id
     WHERE $where"
);
$countStmt->execute($params);
$total = (int) $countStmt->fetchColumn();
$pages = max(1, (int) ceil($total / $perPage));
$page = min($page, $pages);
$offset = ($page - 1) * $perPage;

$stmt = $pdo->prepare(
    "SELECT u.id, u.first_name, u.last_name, u.email, u.status, u.created_at,
            sp.student_number, sp.phone, sp.address,
            (SELECT COUNT(*) FROM enrollments ec WHERE ec.student_id = u.id) AS application_count,
            (SELECT el.id FROM enrollments el WHERE el.student_id = u.id
             ORDER BY el.submitted_at DESC, el.id DESC LIMIT 1) AS latest_application_id,
            (SELECT el.status FROM enrollments el WHERE el.student_id = u.id
             ORDER BY el.submitted_at DESC, el.id DESC LIMIT 1) AS latest_application_status
     FROM users u
     LEFT JOIN student_profiles sp ON sp.user_id = u.id
     WHERE $where
     ORDER BY u.created_at DESC, u.id DESC
     LIMIT $perPage OFFSET $offset"
);
$stmt->execute($params);
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = "Student Management";
$activeNav = "students";
require __DIR__ . "/header.php";
?>

<div id="admin-search-content" aria-live="polite" aria-busy="false">
<section class="admin-panel">
    <div class="admin-panel-head">
        <div><h2>Student directory</h2><p><?= $total ?> student account<?= $total === 1 ? "" : "s" ?> registered. Archive is reversible and keeps applications and uploaded files.</p></div>
        <a class="admin-btn" href="student_form.php"><i class="fas fa-user-plus"></i> Create student</a>
    </div>
    <?php if ($actionError !== ""): ?><div class="admin-alert error"><?= e($actionError) ?></div><?php endif; ?>
    <form method="GET" action="students.php" class="admin-form" data-live-search>
        <label class="sr-only" for="student-search">Search students</label>
        <input id="student-search" type="search" name="search" value="<?= e($search) ?>" placeholder="Search name, email, student number or phone" autocomplete="off">
        <?php if ($search !== ""): ?><a class="admin-btn secondary" href="students.php">Clear</a><?php endif; ?>
    </form>

    <?php if ($students): ?>
        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead><tr><th>Student</th><th>Student number</th><th>Contact</th><th>Applications</th><th>Latest application</th><th>Account</th><th>Registered</th><th>Actions</th></tr></thead>
                <tbody>
                <?php foreach ($students as $student): ?>
                    <tr>
                        <td><?= e($student["first_name"] . " " . $student["last_name"]) ?><span class="subline"><?= e($student["email"]) ?></span></td>
                        <td><?= e($student["student_number"] ?? "Not assigned") ?></td>
                        <td><?= e($student["phone"] ?? "—") ?><?php if ($student["address"]): ?><span class="subline"><?= e($student["address"]) ?></span><?php endif; ?></td>
                        <td><?= (int) $student["application_count"] ?></td>
                        <td>
                            <?php if ($student["latest_application_status"]): ?>
                                <span class="admin-badge <?= e($student["latest_application_status"]) ?>"><?= e($student["latest_application_status"]) ?></span>
                            <?php else: ?>
                                <span class="admin-badge missing">Not applied</span>
                            <?php endif; ?>
                        </td>
                        <td><span class="admin-badge <?= e($student["status"]) ?>"><?= e($student["status"]) ?></span></td>
                        <td><?= e(date("M d, Y", strtotime($student["created_at"]))) ?></td>
                        <td>
                            <div class="admin-actions">
                                <a class="admin-btn secondary small" href="student_form.php?id=<?= (int) $student["id"] ?>">Edit</a>
                            <?php if ($student["latest_application_id"]): ?>
                                <a class="admin-btn small" href="review_application.php?id=<?= (int) $student["latest_application_id"] ?>">Latest app</a>
                            <?php endif; ?>
                                <form method="POST" class="admin-inline" data-confirm-submit="<?= e($student["status"] === "active" ? "Archive this student account? Their applications and uploaded files will be kept." : "Restore this student account?") ?>">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="toggle_status">
                                    <input type="hidden" name="student_id" value="<?= (int) $student["id"] ?>">
                                    <button class="admin-btn small <?= $student["status"] === "active" ? "danger" : "secondary" ?>" type="submit">
                                        <?= $student["status"] === "active" ? "Archive" : "Restore" ?>
                                    </button>
                                </form>
                                <?php if ((int) $student["application_count"] === 0): ?>
                                    <form method="POST" class="admin-inline" data-confirm-submit="Permanently delete this student account? This is allowed only because no applications are attached.">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="delete_student">
                                        <input type="hidden" name="student_id" value="<?= (int) $student["id"] ?>">
                                        <button class="admin-btn danger small" type="submit">Delete</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="admin-pagination">
            <span>Page <?= $page ?> of <?= $pages ?></span>
            <div class="admin-actions">
                <?php if ($page > 1): ?><a class="admin-btn secondary small" href="?<?= e(http_build_query(["search" => $search, "page" => $page - 1])) ?>">Previous</a><?php endif; ?>
                <?php if ($page < $pages): ?><a class="admin-btn secondary small" href="?<?= e(http_build_query(["search" => $search, "page" => $page + 1])) ?>">Next</a><?php endif; ?>
            </div>
        </div>
    <?php else: ?>
        <div class="admin-empty">No students matched your search.</div>
    <?php endif; ?>
</section>
</div>

<?php require __DIR__ . "/footer.php"; ?>
