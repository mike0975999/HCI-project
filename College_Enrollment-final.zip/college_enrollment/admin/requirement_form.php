<?php
declare(strict_types=1);
require_once __DIR__ . "/auth_check.php";

$requirementId = (int) ($_GET["id"] ?? $_POST["requirement_id"] ?? 0);
$isEdit = $requirementId > 0;
$item = ["name" => "", "description" => "", "is_required" => 1, "is_active" => 1];
$error = "";
if ($isEdit) {
    $stmt = $pdo->prepare("SELECT * FROM requirements WHERE id = ?"); $stmt->execute([$requirementId]);
    $found = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$found) { http_response_code(404); exit("Requirement not found."); }
    $item = $found;
}
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $item["name"] = trim((string) ($_POST["name"] ?? ""));
    $item["description"] = trim((string) ($_POST["description"] ?? ""));
    $item["is_required"] = isset($_POST["is_required"]) ? 1 : 0;
    $item["is_active"] = isset($_POST["is_active"]) ? 1 : 0;
    if (!csrf_valid()) { $error = "Your session expired. Please refresh and try again."; }
    elseif ($item["name"] === "" || strlen($item["name"]) > 150 || strlen($item["description"]) > 255) { $error = "Enter a requirement name and keep the fields within their allowed lengths."; }
    if ($error === "") {
        $duplicate = $pdo->prepare("SELECT id FROM requirements WHERE name = ? AND id <> ? LIMIT 1"); $duplicate->execute([$item["name"], $requirementId]);
        if ($duplicate->fetchColumn()) { $error = "A requirement with that name already exists."; }
    }
    if ($error === "") {
        $activeCount = (int) $pdo->query("SELECT COUNT(*) FROM requirements WHERE is_active = 1")->fetchColumn();
        $wasActive = false;
        if ($isEdit) {
            $currentActive = $pdo->prepare("SELECT is_active FROM requirements WHERE id = ?");
            $currentActive->execute([$requirementId]);
            $wasActive = (int) $currentActive->fetchColumn() === 1;
        }
        $projectedActiveCount = $activeCount - ($wasActive ? 1 : 0) + (int) $item["is_active"];
        if ($projectedActiveCount < 1) {
            $error = "At least one active document requirement must remain for new applications.";
        }
    }
    if ($error === "") {
        try {
            if ($isEdit) {
                $save = $pdo->prepare("UPDATE requirements SET name = ?, description = ?, is_required = ?, is_active = ? WHERE id = ?");
                $save->execute([$item["name"], $item["description"] ?: null, $item["is_required"], $item["is_active"], $requirementId]);
            } else {
                $save = $pdo->prepare("INSERT INTO requirements (name, description, is_required, is_active) VALUES (?, ?, ?, ?)");
                $save->execute([$item["name"], $item["description"] ?: null, $item["is_required"], $item["is_active"]]);
            }
            $_SESSION["admin_flash"] = ["success", $isEdit ? "Requirement updated. Existing applications retain the original saved checklist." : "Requirement created successfully."];
            header("Location: requirements.php"); exit;
        } catch (PDOException $exception) {
            if ($exception->getCode() === "23000") { $error = "A requirement with that name already exists."; }
            else { error_log("Requirement save failed: " . $exception->getMessage()); $error = "The requirement could not be saved."; }
        }
    }
}
$pageTitle = $isEdit ? "Edit Requirement" : "Create Requirement"; $activeNav = "requirements";
require __DIR__ . "/header.php";
?>
<section class="admin-panel">
    <div class="admin-panel-head"><div><h2><?= $isEdit ? "Update requirement" : "Add document requirement" ?></h2><p>Updates to this master list only affect applications submitted after the change.</p></div></div>
    <?php if ($error !== ""): ?><div class="admin-alert error"><?= e($error) ?></div><?php endif; ?>
    <form method="POST" class="admin-student-form">
        <?= csrf_field() ?><?php if ($isEdit): ?><input type="hidden" name="requirement_id" value="<?= $requirementId ?>"><?php endif; ?>
        <div class="admin-field"><label for="name">Requirement name *</label><input id="name" name="name" maxlength="150" value="<?= e($item["name"]) ?>" required></div>
        <div class="admin-field"><label for="description">Description / instructions</label><textarea id="description" name="description" maxlength="255" rows="4"><?= e($item["description"] ?? "") ?></textarea></div>
        <div class="admin-field admin-checkbox-field"><label><input type="checkbox" name="is_required" value="1" <?= (int) $item["is_required"] === 1 ? "checked" : "" ?>> Required document</label></div>
        <div class="admin-field admin-checkbox-field"><label><input type="checkbox" name="is_active" value="1" <?= (int) $item["is_active"] === 1 ? "checked" : "" ?>> Active for new applications</label></div>
        <div class="admin-form-actions"><button class="admin-btn" type="submit"><?= $isEdit ? "Save changes" : "Create requirement" ?></button><a class="admin-btn secondary" href="requirements.php">Cancel</a></div>
    </form>
</section>
<?php require __DIR__ . "/footer.php"; ?>
