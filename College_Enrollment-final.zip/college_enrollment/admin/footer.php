        <footer>© 2026 UniPortal. College Enrollment System.</footer>
    </main>
</div>
</body>
</html>
