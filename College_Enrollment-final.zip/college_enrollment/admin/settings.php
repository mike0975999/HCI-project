<?php
declare(strict_types=1);
require_once __DIR__ . "/auth_check.php";

$adminId = (int) $_SESSION["user_id"];
$stmt = $pdo->prepare(
    "SELECT email, password
     FROM users
     WHERE id = ? AND role = 'admin'
     LIMIT 1"
);
$stmt->execute([$adminId]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$admin) {
    http_response_code(404);
    exit("Administrator account not found.");
}

$form = [
    "email" => $admin["email"],
];
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $posted = static function (string $key): string {
        return isset($_POST[$key]) && is_string($_POST[$key])
            ? trim($_POST[$key])
            : "";
    };

    $form["email"] = strtolower($posted("email"));
    $currentPassword = isset($_POST["current_password"]) && is_string($_POST["current_password"])
        ? $_POST["current_password"]
        : "";
    $newPassword = isset($_POST["new_password"]) && is_string($_POST["new_password"])
        ? $_POST["new_password"]
        : "";
    $confirmPassword = isset($_POST["confirm_password"]) && is_string($_POST["confirm_password"])
        ? $_POST["confirm_password"]
        : "";

    if (!csrf_valid()) {
        $error = "Your session expired. Please refresh and try again.";
    } elseif (!password_verify($currentPassword, (string) $admin["password"])) {
        $error = "Your current password is incorrect.";
    } elseif (strlen($form["email"]) > 150 || !filter_var($form["email"], FILTER_VALIDATE_EMAIL)) {
        $error = "Enter a valid email address within 150 characters.";
    } elseif (($newPassword !== "" || $confirmPassword !== "")
        && (strlen($newPassword) < 8 || $newPassword !== $confirmPassword)) {
        $error = $newPassword === ""
            ? "Enter the new password in both password fields."
            : (strlen($newPassword) < 8
                ? "New password must be at least 8 characters."
                : "New passwords do not match.");
    }

    if ($error === "") {
        try {
            if ($newPassword !== "") {
                $save = $pdo->prepare(
                    "UPDATE users
                     SET first_name = 'System', last_name = 'Administrator',
                         email = ?, password = ?
                     WHERE id = ? AND role = 'admin'"
                );
                $save->execute([
                    $form["email"],
                    password_hash($newPassword, PASSWORD_DEFAULT),
                    $adminId,
                ]);
            } else {
                $save = $pdo->prepare(
                    "UPDATE users
                     SET first_name = 'System', last_name = 'Administrator',
                         email = ?
                     WHERE id = ? AND role = 'admin'"
                );
                $save->execute([
                    $form["email"],
                    $adminId,
                ]);
            }

            $_SESSION["name"] = "System Administrator";
            $_SESSION["email"] = $form["email"];
            session_regenerate_id(true);
            $_SESSION["csrf"] = bin2hex(random_bytes(32));
            $_SESSION["admin_flash"] = ["success", "Administrator account settings updated."];
            header("Location: settings.php");
            exit;
        } catch (PDOException $exception) {
            if ($exception->getCode() === "23000") {
                $error = "That email address is already in use.";
            } else {
                error_log("Administrator settings update failed: " . $exception->getMessage());
                $error = "Unable to update account settings. Please try again.";
            }
        }
    }
}

$pageTitle = "Account Settings";
$activeNav = "settings";
require __DIR__ . "/header.php";
?>
<section class="admin-panel">
    <div class="admin-panel-head">
        <div>
            <h2>Administrator account</h2>
            <p>The administrator name is fixed as System Administrator. Update your email or password below; your current password is required to save changes.</p>
        </div>
    </div>
    <?php if ($error !== ""): ?><div class="admin-alert error"><?= e($error) ?></div><?php endif; ?>
    <form method="POST" class="admin-student-form" autocomplete="off">
        <?= csrf_field() ?>
        <div class="admin-field">
            <label for="email">Email address *</label>
            <input id="email" name="email" type="email" maxlength="150" value="<?= e($form["email"]) ?>" autocomplete="username" required>
        </div>
        <div class="admin-field admin-field-narrow">
            <label for="current_password">Current password *</label>
            <input id="current_password" name="current_password" type="password" autocomplete="current-password" required>
        </div>
        <div class="admin-field admin-field-narrow">
            <label for="new_password">New password</label>
            <input id="new_password" name="new_password" type="password" minlength="8" autocomplete="new-password">
        </div>
        <div class="admin-field admin-field-narrow">
            <label for="confirm_password">Confirm new password</label>
            <input id="confirm_password" name="confirm_password" type="password" minlength="8" autocomplete="new-password">
        </div>
        <div class="admin-form-actions">
            <button class="admin-btn" type="submit">Save account settings</button>
        </div>
    </form>
</section>
<?php require __DIR__ . "/footer.php"; ?>
