<?php
require_once __DIR__ . "/auth_check.php";

$studentId = (int) ($_GET["id"] ?? $_POST["student_id"] ?? 0);
$isEdit = $studentId > 0;
$emptyStudent = [
    "first_name" => "",
    "last_name" => "",
    "email" => "",
    "student_number" => "",
    "phone" => "",
    "birthdate" => "",
    "gender" => "",
    "address" => "",
    "guardian_name" => "",
    "guardian_phone" => "",
];

if ($isEdit) {
    $stmt = $pdo->prepare(
        "SELECT u.id, u.first_name, u.last_name, u.email,
                sp.student_number, sp.phone, sp.birthdate, sp.gender, sp.address,
                sp.guardian_name, sp.guardian_phone
         FROM users u
         LEFT JOIN student_profiles sp ON sp.user_id = u.id
         WHERE u.id = ? AND u.role = 'student'"
    );
    $stmt->execute([$studentId]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$student) {
        http_response_code(404);
        exit("Student not found.");
    }
} else {
    $student = $emptyStudent;
}

$error = "";
$password = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    foreach ($emptyStudent as $field => $_) {
        $student[$field] = trim($_POST[$field] ?? "");
    }
    $password = $_POST["password"] ?? "";
    $confirmPassword = $_POST["confirm_password"] ?? "";
    $phonePattern = '/^[0-9+\-\s()]{7,30}$/';

    if (!csrf_valid()) {
        $error = "Your session expired. Please try again.";
    } elseif ($student["first_name"] === "" || $student["last_name"] === "" || $student["email"] === "") {
        $error = "First name, last name, and email are required.";
    } elseif (strlen($student["first_name"]) > 100 || strlen($student["last_name"]) > 100
              || strlen($student["email"]) > 150 || !filter_var($student["email"], FILTER_VALIDATE_EMAIL)) {
        $error = "Enter valid names and an email address within the allowed length.";
    } elseif ($student["student_number"] !== "" && strlen($student["student_number"]) > 30) {
        $error = "Student number must be 30 characters or fewer.";
    } elseif (strlen($student["phone"]) > 30
              || ($student["phone"] !== "" && !preg_match($phonePattern, $student["phone"]))) {
        $error = "Enter a valid phone number.";
    } elseif (strlen($student["guardian_phone"]) > 30
              || ($student["guardian_phone"] !== "" && !preg_match($phonePattern, $student["guardian_phone"]))) {
        $error = "Enter a valid guardian phone number.";
    } elseif (strlen($student["address"]) > 255 || strlen($student["guardian_name"]) > 150) {
        $error = "Address or guardian name exceeds the allowed length.";
    } elseif (!in_array($student["gender"], ["", "male", "female", "other"], true)) {
        $error = "Choose a valid gender.";
    } elseif ($student["birthdate"] !== "") {
        $birthdate = DateTimeImmutable::createFromFormat("!Y-m-d", $student["birthdate"]);
        $dateErrors = DateTimeImmutable::getLastErrors();
        if (!$birthdate || ($dateErrors !== false && ($dateErrors["warning_count"] || $dateErrors["error_count"]))
            || $birthdate->format("Y-m-d") !== $student["birthdate"]) {
            $error = "Enter a valid date of birth.";
        }
    }

    if ($error === "" && (!$isEdit || $password !== "")) {
        if (strlen($password) < 8) {
            $error = "Password must be at least 8 characters.";
        } elseif ($password !== $confirmPassword) {
            $error = "Passwords do not match.";
        }
    }

    if ($error === "") {
        try {
            $pdo->beginTransaction();
            if ($isEdit) {
                $profileStudentNumber = $student["student_number"];
                if ($profileStudentNumber === "") {
                    $profileStudentNumber = date("Y") . "-" . str_pad((string) $studentId, 4, "0", STR_PAD_LEFT);
                    $checkNumber = $pdo->prepare(
                        "SELECT 1 FROM student_profiles WHERE student_number = ? AND user_id <> ?"
                    );
                    $checkNumber->execute([$profileStudentNumber, $studentId]);
                    if ($checkNumber->fetchColumn()) {
                        $profileStudentNumber .= "-" . $studentId;
                    }
                }

                $updateUser = $pdo->prepare(
                    "UPDATE users SET first_name = ?, last_name = ?, email = ? WHERE id = ? AND role = 'student'"
                );
                $updateUser->execute([
                    $student["first_name"], $student["last_name"], $student["email"], $studentId,
                ]);
                if ($password !== "") {
                    $pdo->prepare("UPDATE users SET password = ? WHERE id = ? AND role = 'student'")
                        ->execute([password_hash($password, PASSWORD_DEFAULT), $studentId]);
                }

                $profile = $pdo->prepare("SELECT id FROM student_profiles WHERE user_id = ?");
                $profile->execute([$studentId]);
                $hasProfile = (bool) $profile->fetchColumn();
                if ($hasProfile) {
                    $saveProfile = $pdo->prepare(
                        "UPDATE student_profiles
                         SET student_number = ?, phone = ?, birthdate = ?, gender = ?, address = ?,
                             guardian_name = ?, guardian_phone = ?
                         WHERE user_id = ?"
                    );
                    $saveProfile->execute([
                        $profileStudentNumber,
                        $student["phone"] ?: null,
                        $student["birthdate"] ?: null,
                        $student["gender"] ?: null,
                        $student["address"] ?: null,
                        $student["guardian_name"] ?: null,
                        $student["guardian_phone"] ?: null,
                        $studentId,
                    ]);
                } else {
                    $saveProfile = $pdo->prepare(
                        "INSERT INTO student_profiles
                         (user_id, student_number, phone, birthdate, gender, address, guardian_name, guardian_phone)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
                    );
                    $saveProfile->execute([
                        $studentId, $profileStudentNumber, $student["phone"] ?: null,
                        $student["birthdate"] ?: null, $student["gender"] ?: null,
                        $student["address"] ?: null, $student["guardian_name"] ?: null,
                        $student["guardian_phone"] ?: null,
                    ]);
                }
            } else {
                $createUser = $pdo->prepare(
                    "INSERT INTO users (first_name, last_name, email, password, role)
                     VALUES (?, ?, ?, ?, 'student')"
                );
                $createUser->execute([
                    $student["first_name"], $student["last_name"], $student["email"],
                    password_hash($password, PASSWORD_DEFAULT),
                ]);
                $studentId = (int) $pdo->lastInsertId();
                $studentNumber = $student["student_number"] ?: date("Y") . "-" . str_pad((string) $studentId, 4, "0", STR_PAD_LEFT);
                $checkNumber = $pdo->prepare("SELECT 1 FROM student_profiles WHERE student_number = ?");
                $checkNumber->execute([$studentNumber]);
                if ($checkNumber->fetchColumn()) {
                    $studentNumber .= "-" . $studentId;
                }

                $createProfile = $pdo->prepare(
                    "INSERT INTO student_profiles
                     (user_id, student_number, phone, birthdate, gender, address, guardian_name, guardian_phone)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
                );
                $createProfile->execute([
                    $studentId, $studentNumber, $student["phone"] ?: null,
                    $student["birthdate"] ?: null, $student["gender"] ?: null,
                    $student["address"] ?: null, $student["guardian_name"] ?: null,
                    $student["guardian_phone"] ?: null,
                ]);
            }

            $pdo->commit();
            $_SESSION["admin_flash"] = ["success", $isEdit ? "Student record updated." : "Student account created."];
            header("Location: students.php");
            exit;
        } catch (PDOException $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            if ($exception->getCode() === "23000") {
                $error = "That email or student number is already in use.";
            } else {
                throw $exception;
            }
        }
    }
}

$pageTitle = $isEdit ? "Edit Student" : "Create Student";
$activeNav = "students";
require __DIR__ . "/header.php";
?>

<section class="admin-panel">
    <div class="admin-panel-head">
        <div>
            <h2><?= $isEdit ? "Update student record" : "Create student account" ?></h2>
            <p><?= $isEdit ? "Edit account and profile information. Leave password blank to keep it unchanged." : "Create an active student account and profile." ?></p>
        </div>
    </div>
    <?php if ($error !== ""): ?><div class="admin-alert error"><?= e($error) ?></div><?php endif; ?>

    <form method="POST" class="admin-student-form" autocomplete="on">
        <?= csrf_field() ?>
        <?php if ($isEdit): ?><input type="hidden" name="student_id" value="<?= $studentId ?>"><?php endif; ?>

        <div class="admin-field">
            <label for="first_name">First name *</label>
            <input id="first_name" name="first_name" maxlength="100" value="<?= e($student["first_name"]) ?>" required>
        </div>
        <div class="admin-field">
            <label for="last_name">Last name *</label>
            <input id="last_name" name="last_name" maxlength="100" value="<?= e($student["last_name"]) ?>" required>
        </div>
        <div class="admin-field">
            <label for="email">Email address *</label>
            <input id="email" name="email" type="email" maxlength="150" value="<?= e($student["email"]) ?>" required>
        </div>
        <div class="admin-field">
            <label for="student_number">Student number <?= $isEdit ? "*" : "(optional; auto-generated if blank)" ?></label>
            <input id="student_number" name="student_number" maxlength="30" value="<?= e($student["student_number"] ?? "") ?>">
        </div>
        <div class="admin-field">
            <label for="phone">Phone</label>
            <input id="phone" name="phone" maxlength="30" value="<?= e($student["phone"] ?? "") ?>">
        </div>
        <div class="admin-field">
            <label for="birthdate">Date of birth</label>
            <input id="birthdate" name="birthdate" type="date" value="<?= e($student["birthdate"] ?? "") ?>">
        </div>
        <div class="admin-field">
            <label for="gender">Gender</label>
            <select id="gender" name="gender">
                <option value="">Not specified</option>
                <?php foreach (["male" => "Male", "female" => "Female", "other" => "Other"] as $value => $label): ?>
                    <option value="<?= e($value) ?>" <?= ($student["gender"] ?? "") === $value ? "selected" : "" ?>><?= e($label) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="admin-field">
            <label for="address">Address</label>
            <input id="address" name="address" maxlength="255" value="<?= e($student["address"] ?? "") ?>">
        </div>
        <div class="admin-field">
            <label for="guardian_name">Guardian name</label>
            <input id="guardian_name" name="guardian_name" maxlength="150" value="<?= e($student["guardian_name"] ?? "") ?>">
        </div>
        <div class="admin-field">
            <label for="guardian_phone">Guardian phone</label>
            <input id="guardian_phone" name="guardian_phone" maxlength="30" value="<?= e($student["guardian_phone"] ?? "") ?>">
        </div>
        <div class="admin-field">
            <label for="password">Password <?= $isEdit ? "(optional)" : "*" ?></label>
            <input id="password" name="password" type="password" minlength="8" <?= $isEdit ? "" : "required" ?>>
        </div>
        <div class="admin-field">
            <label for="confirm_password">Confirm password <?= $isEdit ? "(if changing)" : "*" ?></label>
            <input id="confirm_password" name="confirm_password" type="password" minlength="8" <?= $isEdit ? "" : "required" ?>>
        </div>

        <div class="admin-form-actions">
            <button type="submit" class="admin-btn"><i class="fas fa-save"></i> <?= $isEdit ? "Save changes" : "Create student" ?></button>
            <a class="admin-btn secondary" href="students.php">Cancel</a>
        </div>
    </form>
</section>

<?php require __DIR__ . "/footer.php"; ?>
