<?php
require_once __DIR__ . "/../includes/auth.php";
require_once __DIR__ . "/../includes/brand.php";
require_role("admin");

$pageTitle = $pageTitle ?? "Administration";
$activeNav = $activeNav ?? "";
$initial = "S";
$nav = [
    "dashboard" => ["/admin/dashboard.php", "fa-house", "Dashboard"],
    "applications" => ["/admin/applications.php", "fa-file-signature", "Applications"],
    "students" => ["/admin/students.php", "fa-user-graduate", "Students"],
    "programs" => ["/admin/programs.php", "fa-graduation-cap", "Programs"],
    "requirements" => ["/admin/requirements.php", "fa-folder-open", "Requirements"],
    "academic_years" => ["/admin/academic_years.php", "fa-calendar-days", "Academic Years"],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?= e(csrf_token()) ?>">
    <title><?= e($pageTitle) ?> | UniPortal</title>
    <link rel="icon" href="<?= BASE_URL ?>/assets/images/uniportal-mark.svg" type="image/svg+xml">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/confirm.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/brand.css?v=1">
    <script src="<?= BASE_URL ?>/assets/js/logout-confirm.js" defer></script>
    <script src="<?= BASE_URL ?>/assets/js/live-search.js" defer></script>
</head>
<body>
<div class="dashboard">
    <aside class="sidebar">
        <?= uniportal_brand("Administration", BASE_URL . "/admin/dashboard.php", "brand-lockup brand-lockup--sidebar", "UniPortal admin dashboard") ?>
        <div class="menu-label">MAIN MENU</div>
        <nav>
            <?php foreach ($nav as $key => [$href, $icon, $label]): ?>
                <a href="<?= BASE_URL . $href ?>" class="nav-link<?= $key === $activeNav ? " active" : "" ?>">
                    <i class="fas <?= $icon ?>"></i><span><?= e($label) ?></span>
                </a>
            <?php endforeach; ?>
        </nav>
        <div class="menu-label">ACCOUNT</div>
        <nav>
            <a href="<?= BASE_URL ?>/admin/settings.php" class="nav-link<?= $activeNav === "settings" ? " active" : "" ?>">
                <i class="fas fa-gear"></i><span>Account Settings</span>
            </a>
            <a href="<?= BASE_URL ?>/logout.php" class="nav-link" data-confirm-logout>
                <i class="fas fa-right-from-bracket"></i><span>Log Out</span>
            </a>
        </nav>
        <div class="sidebar-bottom">
            <div class="profile">
                <div class="avatar"><?= e($initial) ?></div>
                <div><strong>System Administrator</strong><span>Administrator</span></div>
            </div>
        </div>
    </aside>
    <dialog class="confirm-dialog" id="logout-confirm-dialog" aria-labelledby="logout-confirm-title" aria-describedby="logout-confirm-message">
        <div class="confirm-icon"><i class="fas fa-right-from-bracket" aria-hidden="true"></i></div>
        <h2 id="logout-confirm-title">Log out?</h2>
        <p id="logout-confirm-message">Are you sure you want to log out of your account?</p>
        <div class="confirm-actions">
            <button type="button" class="confirm-button secondary" data-cancel-logout>Stay logged in</button>
            <button type="button" class="confirm-button primary" data-accept-logout>Log out</button>
        </div>
    </dialog>
    <main class="main-content">
        <header class="topbar">
            <div>
                <p class="breadcrumb">Administration / <?= e($pageTitle) ?></p>
                <h1><?= e($pageTitle) ?></h1>
            </div>
        </header>
        <?php if (!empty($_SESSION["admin_flash"])): ?>
            <?php [$flashType, $flashMessage] = $_SESSION["admin_flash"]; unset($_SESSION["admin_flash"]); ?>
            <div class="admin-alert <?= e($flashType) ?>"><?= e($flashMessage) ?></div>
        <?php endif; ?>
