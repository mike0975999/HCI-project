<?php
declare(strict_types=1);
require_once __DIR__ . "/auth_check.php";

$search = trim((string) ($_GET["search"] ?? ""));
$error = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $action = (string) ($_POST["action"] ?? "");
    $requirementId = (int) ($_POST["requirement_id"] ?? 0);
    if (!csrf_valid()) {
        $error = "Your session expired. Please refresh and try again.";
    } elseif ($requirementId < 1) {
        $error = "Choose a valid requirement.";
    } elseif ($action === "toggle_requirement") {
        $stmt = $pdo->prepare("SELECT is_active, name FROM requirements WHERE id = ?");
        $stmt->execute([$requirementId]);
        $item = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$item) { $error = "Requirement not found."; }
        else {
            $next = (int) $item["is_active"] === 1 ? 0 : 1;
            if ($next === 0 && (int) $pdo->query("SELECT COUNT(*) FROM requirements WHERE is_active = 1")->fetchColumn() <= 1) {
                $error = "At least one active document requirement must remain for new applications.";
            } else {
                $pdo->prepare("UPDATE requirements SET is_active = ? WHERE id = ?")->execute([$next, $requirementId]);
                $_SESSION["admin_flash"] = ["success", "Requirement " . ($next ? "restored for future applications." : "archived. Existing application checklists were not changed.")];
                header("Location: requirements.php"); exit;
            }
        }
    } elseif ($action === "delete_requirement") {
        $count = $pdo->prepare("SELECT COUNT(*) FROM enrollment_requirement_items WHERE source_requirement_id = ?");
        $count->execute([$requirementId]);
        if ((int) $count->fetchColumn() > 0) {
            $error = "This requirement is used by existing application snapshots. Archive it instead to preserve history.";
        } else {
            $pdo->prepare("DELETE FROM requirements WHERE id = ?")->execute([$requirementId]);
            $_SESSION["admin_flash"] = ["success", "Requirement permanently deleted."];
            header("Location: requirements.php"); exit;
        }
    } else { $error = "Unknown requirement action."; }
}

$where = "1 = 1"; $params = [];
if ($search !== "") {
    $where .= " AND (r.name LIKE ? OR r.description LIKE ?)";
    $term = "%" . $search . "%"; $params = [$term, $term];
}
$stmt = $pdo->prepare(
    "SELECT r.*,
            (SELECT COUNT(*) FROM enrollment_requirement_items eri WHERE eri.source_requirement_id = r.id) AS snapshot_count
     FROM requirements r WHERE $where ORDER BY r.is_active DESC, r.is_required DESC, r.name"
);
$stmt->execute($params); $requirements = $stmt->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = "Requirement Management"; $activeNav = "requirements";
require __DIR__ . "/header.php";
?>
<div id="admin-search-content" aria-live="polite" aria-busy="false">
<section class="admin-panel">
    <div class="admin-panel-head"><div><h2>Document requirements</h2><p>Manage the master checklist used for new applications. Existing applications keep their saved requirement snapshots.</p></div><a class="admin-btn" href="requirement_form.php"><i class="fas fa-plus"></i> Add requirement</a></div>
    <?php if ($error !== ""): ?><div class="admin-alert error"><?= e($error) ?></div><?php endif; ?>
    <form method="GET" action="requirements.php" class="admin-form" data-live-search>
        <label class="sr-only" for="requirement-search">Search requirements</label>
        <input id="requirement-search" type="search" name="search" value="<?= e($search) ?>" placeholder="Search requirement name or description" autocomplete="off">
        <?php if ($search !== ""): ?><a class="admin-btn secondary" href="requirements.php">Clear</a><?php endif; ?>
    </form>
    <?php if ($requirements): ?>
        <div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Requirement</th><th>Type</th><th>Saved in applications</th><th>Status</th><th>Actions</th></tr></thead><tbody>
        <?php foreach ($requirements as $item): ?>
            <tr>
                <td><strong><?= e($item["name"]) ?></strong><span class="subline"><?= e($item["description"] ?? "") ?></span></td>
                <td><?= (int) $item["is_required"] === 1 ? "Required" : "Optional" ?></td>
                <td><?= (int) $item["snapshot_count"] ?></td>
                <td><span class="admin-badge <?= (int) $item["is_active"] === 1 ? "active" : "inactive" ?>"><?= (int) $item["is_active"] === 1 ? "Active" : "Archived" ?></span></td>
                <td><div class="admin-actions">
                    <a class="admin-btn secondary small" href="requirement_form.php?id=<?= (int) $item["id"] ?>">Edit</a>
                    <form method="POST" class="admin-inline" data-confirm-submit="<?= (int) $item["is_active"] === 1 ? "Archive this requirement for future applications? Existing applications will not change." : "Restore this requirement for future applications?" ?>">
                        <?= csrf_field() ?><input type="hidden" name="action" value="toggle_requirement"><input type="hidden" name="requirement_id" value="<?= (int) $item["id"] ?>">
                        <button class="admin-btn small <?= (int) $item["is_active"] === 1 ? "danger" : "secondary" ?>" type="submit"><?= (int) $item["is_active"] === 1 ? "Archive" : "Restore" ?></button>
                    </form>
                    <?php if ((int) $item["snapshot_count"] === 0): ?>
                        <form method="POST" class="admin-inline" data-confirm-submit="Permanently delete this unused requirement?">
                            <?= csrf_field() ?><input type="hidden" name="action" value="delete_requirement"><input type="hidden" name="requirement_id" value="<?= (int) $item["id"] ?>">
                            <button class="admin-btn danger small" type="submit">Delete</button>
                        </form>
                    <?php endif; ?>
                </div></td>
            </tr>
        <?php endforeach; ?>
        </tbody></table></div>
    <?php else: ?><div class="admin-empty">No requirements matched your search.</div><?php endif; ?>
</section>
</div>
<?php require __DIR__ . "/footer.php"; ?>
