<?php
declare(strict_types=1);

require_once __DIR__ . "/auth_check.php";
require_once __DIR__ . "/../includes/application_audit.php";
require_once __DIR__ . "/../includes/notifications.php";

$applicationId = (int) ($_GET["id"] ?? $_POST["application_id"] ?? 0);
if ($applicationId < 1) {
    header("Location: applications.php");
    exit;
}

$error = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $remarks = trim((string) ($_POST["remarks"] ?? ""));
    $remarksLength = function_exists("mb_strlen") ? mb_strlen($remarks, "UTF-8") : strlen($remarks);

    if (!csrf_valid()) {
        $error = "Your session expired. Please try again.";
    } elseif ($remarksLength > 255) {
        $error = "Remarks must be 255 characters or fewer.";
    } else {
        $action = (string) ($_POST["action"] ?? "");
        try {
            $pdo->beginTransaction();
            $lock = $pdo->prepare("SELECT status, student_id FROM enrollments WHERE id = ? FOR UPDATE");
            $lock->execute([$applicationId]);
            $lockedApplication = $lock->fetch(PDO::FETCH_ASSOC);
            $applicationStatus = $lockedApplication["status"] ?? false;
            $applicationStudentId = (int) ($lockedApplication["student_id"] ?? 0);

            if ($applicationStatus === false) {
                $pdo->rollBack();
                http_response_code(404);
                exit("Application not found.");
            }

            if ($applicationStatus !== "pending") {
                $pdo->rollBack();
                $error = "This application has already been finalized and can no longer be changed.";
            } elseif ($action === "review_document") {
                $documentId = (int) ($_POST["document_id"] ?? 0);
                $documentStatus = (string) ($_POST["document_status"] ?? "");

                if (!in_array($documentStatus, ["verified", "rejected"], true)) {
                    $error = "Choose a valid document review status.";
                } elseif ($documentStatus === "rejected" && $remarks === "") {
                    $error = "Add a reason before rejecting a document.";
                } else {
                    $document = $pdo->prepare(
                        "SELECT er.id, er.status, er.file_path, eri.name
                         FROM enrollment_requirements er
                         JOIN enrollment_requirement_items eri
                           ON eri.id = er.requirement_item_id
                         WHERE er.id = ? AND er.enrollment_id = ? AND er.file_path IS NOT NULL
                         FOR UPDATE"
                    );
                    $document->execute([$documentId, $applicationId]);
                    $documentRow = $document->fetch(PDO::FETCH_ASSOC);

                    if (!$documentRow || resolve_stored_upload($documentRow["file_path"] ?? null) === null) {
                        $error = "The uploaded document file could not be found or is outside the protected uploads directory.";
                    } else {
                        $update = $pdo->prepare(
                            "UPDATE enrollment_requirements
                             SET status = ?, remarks = ?, reviewed_by = ?, reviewed_at = NOW()
                             WHERE id = ? AND enrollment_id = ?"
                        );
                        $update->execute([
                            $documentStatus,
                            $remarks !== "" ? $remarks : null,
                            (int) $_SESSION["user_id"],
                            $documentId,
                            $applicationId,
                        ]);

                        log_application_event(
                            $pdo,
                            $applicationId,
                            (int) $_SESSION["user_id"],
                            $documentStatus === "verified" ? "document_verified" : "document_rejected",
                            (string) $documentRow["status"],
                            $documentStatus,
                            $documentRow["name"] . ($remarks !== "" ? ": " . $remarks : ".")
                        );
                        $notificationType = $documentStatus === "verified" ? "document_verified" : "document_rejected";
                        $notificationTitle = $documentStatus === "verified" ? "Document verified" : "Document rejected";
                        $notificationMessage = $documentRow["name"] . ($documentStatus === "verified"
                            ? " was verified by admissions."
                            : " was rejected. Reason: " . $remarks);
                        create_notification(
                            $pdo,
                            $applicationStudentId,
                            $applicationId,
                            $notificationType,
                            $notificationTitle,
                            $notificationMessage,
                            "/student/requirements.php"
                        );
                    }
                }

                if ($error !== "") {
                    $pdo->rollBack();
                } else {
                    $pdo->commit();
                    $_SESSION["admin_flash"] = ["success", "Document review saved and recorded in application history."];
                    header("Location: review_application.php?id=" . $applicationId);
                    exit;
                }
            } elseif ($action === "decide_application") {
                $decision = (string) ($_POST["decision"] ?? "");
                if (!in_array($decision, ["approved", "rejected"], true)) {
                    $error = "Choose approve or reject.";
                } elseif ($decision === "rejected" && $remarks === "") {
                    $error = "Add a reason before rejecting an application.";
                } else {
                    if ($decision === "approved") {
                        $requiredStmt = $pdo->prepare(
                            "SELECT eri.id, er.file_path, er.status
                             FROM enrollment_requirement_items eri
                             LEFT JOIN enrollment_requirements er
                               ON er.requirement_item_id = eri.id AND er.enrollment_id = eri.enrollment_id
                             WHERE eri.enrollment_id = ? AND eri.is_required = 1
                             ORDER BY eri.id"
                        );
                        $requiredStmt->execute([$applicationId]);
                        $requiredRows = $requiredStmt->fetchAll(PDO::FETCH_ASSOC);

                        if (!$requiredRows) {
                            $error = "Approval is blocked because this application has no saved required-document checklist.";
                        } else {
                            foreach ($requiredRows as $requiredRow) {
                                if (
                                    $requiredRow["status"] !== "verified" ||
                                    empty($requiredRow["file_path"]) ||
                                    resolve_stored_upload($requiredRow["file_path"]) === null
                                ) {
                                    $error = "Approval is blocked until every required document is uploaded, physically available, and verified.";
                                    break;
                                }
                            }
                        }
                    }

                    if ($error !== "") {
                        $pdo->rollBack();
                    } else {
                        $update = $pdo->prepare(
                            "UPDATE enrollments
                             SET status = ?, remarks = ?, reviewed_by = ?, reviewed_at = NOW()
                             WHERE id = ? AND status = 'pending'"
                        );
                        $update->execute([
                            $decision,
                            $remarks !== "" ? $remarks : null,
                            (int) $_SESSION["user_id"],
                            $applicationId,
                        ]);

                        if ($update->rowCount() !== 1) {
                            $pdo->rollBack();
                            $error = "The application changed while you were reviewing it. Reload and try again.";
                        } else {
                            log_application_event(
                                $pdo,
                                $applicationId,
                                (int) $_SESSION["user_id"],
                                $decision === "approved" ? "application_approved" : "application_rejected",
                                "pending",
                                $decision,
                                $remarks !== "" ? $remarks : "Application " . $decision . "."
                            );
                            create_notification(
                                $pdo,
                                $applicationStudentId,
                                $applicationId,
                                $decision === "approved" ? "application_approved" : "application_rejected",
                                $decision === "approved" ? "Enrollment application approved" : "Enrollment application rejected",
                                $decision === "approved"
                                    ? "Congratulations! Your enrollment application has been approved." . ($remarks !== "" ? " Admissions note: " . $remarks : "")
                                    : "Your enrollment application was rejected. Reason: " . $remarks,
                                "/student/tracking.php"
                            );
                            $pdo->commit();
                            $_SESSION["admin_flash"] = ["success", "Application " . $decision . " successfully."];
                            header("Location: review_application.php?id=" . $applicationId);
                            exit;
                        }
                    }
                }
            } else {
                $pdo->rollBack();
                $error = "Unknown review action.";
            }
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log("Application review failed: " . $exception->getMessage());
            $error = "The review could not be saved. Please reload and try again.";
        }
    }
}

$stmt = $pdo->prepare(
    "SELECT e.*, u.first_name, u.last_name, u.email, u.status AS account_status,
            sp.student_number, sp.phone, sp.birthdate, sp.gender, sp.address,
            sp.guardian_name, sp.guardian_phone,
            p.code AS program_code, p.name AS program_name,
            ay.name AS academic_year
     FROM enrollments e
     JOIN users u ON u.id = e.student_id
     LEFT JOIN student_profiles sp ON sp.user_id = u.id
     JOIN programs p ON p.id = e.program_id
     JOIN academic_years ay ON ay.id = e.academic_year_id
     WHERE e.id = ?"
);
$stmt->execute([$applicationId]);
$app = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$app) {
    http_response_code(404);
    exit("Application not found.");
}

$docStmt = $pdo->prepare(
    "SELECT eri.id AS requirement_item_id, eri.name, eri.description, eri.is_required,
            er.id AS document_id, er.file_path, er.status AS document_status,
            er.remarks AS document_remarks, er.uploaded_at, er.reviewed_at,
            CONCAT_WS(' ', reviewer.first_name, reviewer.last_name) AS reviewer_name
     FROM enrollment_requirement_items eri
     LEFT JOIN enrollment_requirements er
       ON er.requirement_item_id = eri.id AND er.enrollment_id = eri.enrollment_id
     LEFT JOIN users reviewer ON reviewer.id = er.reviewed_by
     WHERE eri.enrollment_id = ?
     ORDER BY eri.is_required DESC, eri.id"
);
$docStmt->execute([$applicationId]);
$documents = $docStmt->fetchAll(PDO::FETCH_ASSOC);

$requiredCount = 0;
$verifiedCount = 0;
$submittedCount = 0;
$rejectedCount = 0;
$missingCount = 0;
foreach ($documents as $document) {
    if ((int) $document["is_required"] !== 1) {
        continue;
    }

    $requiredCount++;
    $physicalFileExists = !empty($document["file_path"])
        && resolve_stored_upload($document["file_path"]) !== null;

    if (!$physicalFileExists) {
        $missingCount++;
    } elseif ($document["document_status"] === "verified") {
        $verifiedCount++;
    } elseif ($document["document_status"] === "rejected") {
        $rejectedCount++;
    } else {
        $submittedCount++;
    }
}

$approvalReady = $requiredCount > 0 && $verifiedCount === $requiredCount;

$auditStmt = $pdo->prepare(
    "SELECT al.action, al.old_status, al.new_status, al.details, al.created_at,
            CONCAT_WS(' ', actor.first_name, actor.last_name) AS actor_name
     FROM application_audit_logs al
     LEFT JOIN users actor ON actor.id = al.actor_user_id
     WHERE al.enrollment_id = ?
     ORDER BY al.created_at DESC, al.id DESC"
);
$auditStmt->execute([$applicationId]);
$auditEvents = $auditStmt->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = "Review Application";
$activeNav = "applications";
require __DIR__ . "/header.php";
?>

<?php if ($error !== ""): ?><div class="admin-alert error"><?= e($error) ?></div><?php endif; ?>

<section class="admin-panel">
    <div class="admin-panel-head">
        <div>
            <h2>Application #<?= (int) $app["id"] ?></h2>
            <p><?= e($app["program_code"] . " · " . $app["program_name"]) ?>, academic year <?= e($app["academic_year"]) ?></p>
        </div>
        <span class="admin-badge <?= e($app["status"]) ?>"><?= e($app["status"]) ?></span>
    </div>
    <div class="admin-details">
        <div><span>Student</span><strong><?= e($app["first_name"] . " " . $app["last_name"]) ?></strong></div>
        <div><span>Email</span><strong><?= e($app["email"]) ?></strong></div>
        <div><span>Student number</span><strong><?= e($app["student_number"] ?? "Not assigned") ?></strong></div>
        <div><span>Phone</span><strong><?= e($app["phone"] ?? "Not provided") ?></strong></div>
        <div><span>Date of birth / gender</span><strong><?= e($app["birthdate"] ?? "—") ?> / <?= e($app["gender"] ?? "—") ?></strong></div>
        <div><span>Address</span><strong><?= e($app["address"] ?? "Not provided") ?></strong></div>
        <div><span>Guardian</span><strong><?= e($app["guardian_name"] ?? "Not provided") ?></strong></div>
        <div><span>Guardian phone</span><strong><?= e($app["guardian_phone"] ?? "Not provided") ?></strong></div>
        <div><span>Application details</span><strong>Year <?= (int) $app["year_level"] ?> · <?= e(ucfirst($app["semester"])) ?> semester</strong></div>
        <div><span>Submitted</span><strong><?= e(date("M d, Y H:i", strtotime($app["submitted_at"]))) ?></strong></div>
        <div><span>Required documents verified</span><strong><?= $verifiedCount ?> / <?= $requiredCount ?></strong></div>
        <div><span>Last review / status change</span><strong><?= $app["reviewed_at"] ? e(date("M d, Y H:i", strtotime($app["reviewed_at"]))) : ($app["status"] === "cancelled" ? e(date("M d, Y H:i", strtotime($app["updated_at"]))) : "Not reviewed") ?></strong></div>
    </div>
    <?php if ($app["remarks"]): ?>
        <p class="admin-muted"><strong>Application remarks:</strong> <?= e($app["remarks"]) ?></p>
    <?php endif; ?>
</section>

<section class="admin-review-summary" aria-label="Required document review summary">
    <div class="admin-review-stat"><span>Required</span><strong><?= $requiredCount ?></strong><small>Snapshot checklist items</small></div>
    <div class="admin-review-stat verified"><span>Verified</span><strong><?= $verifiedCount ?></strong><small>Ready for approval</small></div>
    <div class="admin-review-stat submitted"><span>Awaiting review</span><strong><?= $submittedCount ?></strong><small>Uploaded and available</small></div>
    <div class="admin-review-stat rejected"><span>Rejected</span><strong><?= $rejectedCount ?></strong><small>Needs replacement</small></div>
    <div class="admin-review-stat missing"><span>Missing / unavailable</span><strong><?= $missingCount ?></strong><small>Not available to review</small></div>
</section>

<section class="admin-panel">
    <div class="admin-panel-head">
        <div><h2>Required documents</h2><p>Review each uploaded file. Only verified required documents qualify the application for approval.</p></div>
        <span class="admin-badge <?= $approvalReady ? "verified" : "pending" ?>"><?= $approvalReady ? "Ready for decision" : "Review incomplete" ?></span>
    </div>
    <?php foreach ($documents as $document): ?>
        <?php
            $documentFileExists = !empty($document["file_path"]) && resolve_stored_upload($document["file_path"]) !== null;
            $displayDocumentStatus = $documentFileExists ? ($document["document_status"] ?? "missing") : "missing";
        ?>
        <article class="admin-document <?= e($displayDocumentStatus) ?>">
            <div class="admin-document-head">
                <div>
                    <h3><?= e($document["name"]) ?><?= (int) $document["is_required"] ? "" : " (Optional)" ?></h3>
                    <p><?= e($document["description"] ?? "") ?></p>
                    <?php if ($document["document_id"] && $documentFileExists): ?>
                        <p>Uploaded <?= e(date("M d, Y H:i", strtotime($document["uploaded_at"]))) ?> ·
                            <a class="admin-document-preview" href="<?= BASE_URL ?>/download.php?id=<?= (int) $document["document_id"] ?>" target="_blank" rel="noopener"> <i class="fas fa-eye" aria-hidden="true"></i> Preview / open document</a>
                        </p>
                    <?php elseif (!empty($document["file_path"])): ?>
                        <p class="admin-file-warning">The database lists a file, but the physical file is missing or unavailable. This item cannot be verified.</p>
                    <?php endif; ?>
                    <?php if ($document["document_remarks"]): ?>
                        <p><strong>Previous review note:</strong> <?= e($document["document_remarks"]) ?></p>
                    <?php endif; ?>
                    <?php if ($document["reviewed_at"]): ?>
                        <p class="admin-muted">Reviewed <?= e(date("M d, Y H:i", strtotime($document["reviewed_at"]))) ?><?= $document["reviewer_name"] ? " by " . e($document["reviewer_name"]) : "" ?></p>
                    <?php endif; ?>
                </div>
                <span class="admin-badge <?= e($displayDocumentStatus) ?>"><?= e($displayDocumentStatus) ?></span>
            </div>
            <?php if ($app["status"] === "pending" && $document["document_id"] && $documentFileExists): ?>
                <form method="POST" class="admin-form admin-document-review-form">
                    <?= csrf_field() ?>
                    <input type="hidden" name="application_id" value="<?= (int) $app["id"] ?>">
                    <input type="hidden" name="document_id" value="<?= (int) $document["document_id"] ?>">
                    <input type="hidden" name="action" value="review_document">
                    <label class="sr-only" for="document-remarks-<?= (int) $document["document_id"] ?>">Review note or rejection reason</label>
                    <input id="document-remarks-<?= (int) $document["document_id"] ?>" type="text" name="remarks" maxlength="255" value="<?= e($document["document_remarks"] ?? "") ?>" placeholder="Optional note; required when rejecting">
                    <button class="admin-btn small" type="submit" name="document_status" value="verified"><i class="fas fa-check" aria-hidden="true"></i> Verify</button>
                    <button class="admin-btn danger small" type="submit" name="document_status" value="rejected"><i class="fas fa-xmark" aria-hidden="true"></i> Reject</button>
                </form>
            <?php elseif (!$documentFileExists): ?>
                <p class="admin-muted">No reviewable file is currently available. The student must upload or replace this document before it can be verified.</p>
            <?php endif; ?>
        </article>
    <?php endforeach; ?>
</section>

<section class="admin-panel">
    <div class="admin-panel-head"><div><h2>Application decision</h2><p>Rejection requires a reason. Approval is enabled only after every required snapshot document is present, physically available, and verified.</p></div></div>
    <?php if ($app["status"] === "pending"): ?>
        <form method="POST">
            <?= csrf_field() ?>
            <input type="hidden" name="application_id" value="<?= (int) $app["id"] ?>">
            <input type="hidden" name="action" value="decide_application">
            <div class="admin-field">
                <label for="remarks">Remarks for student (optional for approval, required for rejection)</label>
                <textarea id="remarks" name="remarks" maxlength="255" rows="3"><?= e($app["remarks"] ?? "") ?></textarea>
            </div>
            <?php if ($approvalReady): ?>
                <div class="admin-readiness-note ready"><i class="fas fa-circle-check" aria-hidden="true"></i> All <?= $requiredCount ?> required documents are verified. This application is ready for an admissions decision.</div>
            <?php else: ?>
                <div class="admin-readiness-note blocked"><i class="fas fa-circle-exclamation" aria-hidden="true"></i> Approval is blocked. Complete the checklist first: <?= $verifiedCount ?> verified, <?= $submittedCount ?> awaiting review, <?= $rejectedCount ?> rejected, and <?= $missingCount ?> missing or unavailable.</div>
            <?php endif; ?>
            <div class="admin-actions">
                <button class="admin-btn" type="submit" name="decision" value="approved" <?= !$approvalReady ? "disabled" : "" ?>>
                    <i class="fas fa-check"></i> Approve application
                </button>
                <button class="admin-btn danger" type="submit" name="decision" value="rejected">
                    <i class="fas fa-xmark"></i> Reject application
                </button>
                <a class="admin-btn secondary" href="applications.php">Back to applications</a>
            </div>
        </form>
    <?php else: ?>
        <p class="admin-muted">This application is <?= e($app["status"]) ?> and cannot be changed here.</p>
        <a class="admin-btn secondary" href="applications.php">Back to applications</a>
    <?php endif; ?>
</section>

<section class="admin-panel">
    <div class="admin-panel-head">
        <div><h2>Application history</h2><p>Recorded actions for this application. History entries are retained when an application is cancelled.</p></div>
    </div>
    <?php if ($auditEvents): ?>
        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead><tr><th>Date / time</th><th>Action</th><th>Status change</th><th>Performed by</th><th>Details</th></tr></thead>
                <tbody>
                <?php foreach ($auditEvents as $event): ?>
                    <tr>
                        <td><?= e(date("M d, Y H:i", strtotime($event["created_at"]))) ?></td>
                        <td><?= e(ucwords(str_replace("_", " ", $event["action"]))) ?></td>
                        <td><?= e($event["old_status"] ? ucfirst($event["old_status"]) : "—") ?><?= $event["new_status"] ? " → " . e(ucfirst($event["new_status"])) : "" ?></td>
                        <td><?= e($event["actor_name"] ?: "System / unavailable") ?></td>
                        <td><?= e($event["details"] ?? "—") ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <p class="admin-muted">No history entries are available.</p>
    <?php endif; ?>
</section>

<?php require __DIR__ . "/footer.php"; ?>
