<?php
require_once __DIR__ . "/../includes/auth.php";
require_once __DIR__ . "/../includes/brand.php";

redirect_if_logged_in();

$error = "";
$email = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email    = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";

    if (!csrf_valid()) {
        $error = "Session expired. Please try again.";
    } elseif ($email === "" || $password === "") {
        $error = "Please enter your email and password.";
    } else {
        clean_old_login_attempts($pdo);

        $rateStatus = login_rate_limits($pdo, $email);

        if ($rateStatus["blocked"]) {
            $error = "Too many login attempts. Please try again later.";
        } else {
            $user = attempt_login($pdo, $email, $password, "admin");

            if ($user) {
                clear_login_failures($pdo, $email);
                start_user_session($user);
                redirect(dashboard_url("admin"));
            }

            record_login_failure($pdo, $email);
            $error = "Invalid email or password.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login | UniPortal</title>
    <link rel="icon" href="<?= BASE_URL ?>/assets/images/uniportal-mark.svg" type="image/svg+xml">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/auth.css">
    <link rel="stylesheet" href="../assets/css/brand.css?v=1">
    <script src="../assets/js/password-toggle.js" defer></script>
    <script src="../assets/js/dismiss-alerts.js" defer></script>
</head>
<body class="admin-login-page">
<div class="auth-card">
    <div class="auth-head admin">
        <?= uniportal_brand_mark("auth-brand-mark") ?>
        <div>
            <h1>Admin Login</h1>
            <p>UniPortal &middot; Administration</p>
        </div>
    </div>

    <div class="auth-body">
        <?php if (isset($_GET["loggedout"])): ?>
            <div class="alert success" data-dismiss-after="3000">You have been logged out.</div>
        <?php endif; ?>
        <?php if ($error !== ""): ?>
            <div class="alert error"><?= e($error) ?></div>
        <?php endif; ?>

        <form method="POST" autocomplete="on">
            <?= csrf_field() ?>

            <div class="field">
                <label for="email">Admin Email</label>
                <input type="email" id="email" name="email"
                       value="<?= e($email) ?>" autocomplete="username" required autofocus>
            </div>

            <div class="field">
                <label for="password">Password</label>
                <div class="password-input-wrap">
                    <input type="password" id="password" name="password" autocomplete="current-password" required>
                    <button class="password-toggle" type="button" aria-label="Show password"
                            aria-controls="password" aria-pressed="false" data-password-toggle>
                        <i class="fas fa-eye" aria-hidden="true"></i>
                    </button>
                </div>
            </div>

            <button type="submit" class="btn">Log In</button>
        </form>
    </div>

    <div class="auth-foot">
        <a href="../login.php">&larr; Student login</a>
    </div>
</div>
</body>
</html>
