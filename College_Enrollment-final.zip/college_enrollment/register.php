<?php
require_once __DIR__ . "/includes/auth.php";

redirect_if_logged_in();

$error = "";
$email = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";
    $confirm = $_POST["confirm_password"] ?? "";

    if (!csrf_valid()) {
        $error = "Session expired. Please try again.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 150) {
        $error = "Please enter a valid email address.";
    } elseif (strlen($password) < 8) {
        $error = "Password must be at least 8 characters.";
    } elseif ($password !== $confirm) {
        $error = "Passwords do not match.";
    } else {
        $localPart = strstr($email, "@", true);
        $firstName = trim(preg_replace('/\s+/', ' ', str_replace([".", "_", "-"], " ", explode("+", $localPart)[0])));
        $firstName = $firstName !== "" ? ucwords($firstName) : "Student";

        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare(
                "INSERT INTO users (first_name, last_name, email, password, role)
                 VALUES (?, '', ?, ?, 'student')"
            );
            $stmt->execute([
                $firstName,
                $email,
                password_hash($password, PASSWORD_DEFAULT),
            ]);
            $userId = (int) $pdo->lastInsertId();

            $studentNumber = date("Y") . "-" . str_pad((string) $userId, 4, "0", STR_PAD_LEFT);
            $check = $pdo->prepare("SELECT 1 FROM student_profiles WHERE student_number = ?");
            $check->execute([$studentNumber]);
            if ($check->fetchColumn()) {
                $studentNumber .= "-" . $userId;
            }

            $stmt = $pdo->prepare(
                "INSERT INTO student_profiles (user_id, student_number)
                 VALUES (?, ?)"
            );
            $stmt->execute([$userId, $studentNumber]);

            $pdo->commit();
            redirect(BASE_URL . "/login.php?registered=1");
        } catch (PDOException $ex) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = $ex->getCode() === "23000"
                ? "That email address is already registered."
                : "Unable to create your account. Please try again.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration | UniPortal</title>
    <link rel="icon" href="<?= BASE_URL ?>/assets/images/uniportal-mark.svg" type="image/svg+xml">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/auth.css?v=6">
    <link rel="stylesheet" href="assets/css/brand.css?v=1">
</head>
<body class="public-auth-page">
<?php require __DIR__ . "/includes/public_nav.php"; ?>
<div class="auth-card wide">
    <div class="auth-head">
        <?= uniportal_brand_mark("auth-brand-mark") ?>
        <div>
            <h1>Create Student Account</h1>
            <p>Register to start your enrollment</p>
        </div>
    </div>

    <div class="auth-body">
        <?php if ($error !== ""): ?>
            <div class="alert error"><?= e($error) ?></div>
        <?php endif; ?>

        <form method="POST" autocomplete="on">
            <?= csrf_field() ?>

            <div class="field">
                <label for="email">Email Address *</label>
                <input type="email" id="email" name="email" value="<?= e($email) ?>"
                       maxlength="150" autocomplete="email" required autofocus>
            </div>

            <div class="form-row">
                <div class="field">
                    <label for="password">Password *</label>
                    <input type="password" id="password" name="password" minlength="8" required>
                    <p class="hint">At least 8 characters.</p>
                </div>
                <div class="field">
                    <label for="confirm_password">Confirm Password *</label>
                    <input type="password" id="confirm_password" name="confirm_password" minlength="8" required>
                </div>
            </div>

            <button type="submit" class="btn">Create Account</button>
        </form>
    </div>

    <div class="auth-foot">
        Already have an account? <a href="login.php">Log in</a>
    </div>
</div>
</body>
</html>
