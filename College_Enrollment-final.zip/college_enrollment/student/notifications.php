<?php
$pageTitle = "Notifications";
$activeNav = "notifications";
require_once __DIR__ . "/../includes/student_header.php";
require_once __DIR__ . "/../includes/notifications.php";

$userId = (int) $_SESSION["user_id"];
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (!csrf_valid()) {
        $error = "Your session expired. Please refresh and try again.";
    } else {
        $action = (string) ($_POST["action"] ?? "");
        if ($action === "mark_read") {
            $notificationId = filter_var(
                $_POST["notification_id"] ?? null,
                FILTER_VALIDATE_INT
            );
            if (!$notificationId || $notificationId < 1) {
                $error = "Invalid notification.";
            } else {
                $stmt = $pdo->prepare(
                    "UPDATE notifications
                     SET is_read = 1, read_at = COALESCE(read_at, NOW())
                     WHERE id = ? AND user_id = ?"
                );
                $stmt->execute([(int) $notificationId, $userId]);
            }
        } elseif ($action === "mark_all_read") {
            $stmt = $pdo->prepare(
                "UPDATE notifications
                 SET is_read = 1, read_at = COALESCE(read_at, NOW())
                 WHERE user_id = ? AND is_read = 0"
            );
            $stmt->execute([$userId]);
        } elseif ($action === "delete") {
            $notificationId = filter_var($_POST["notification_id"] ?? null, FILTER_VALIDATE_INT);
            if (!$notificationId || $notificationId < 1) {
                $error = "Invalid notification.";
            } else {
                $stmt = $pdo->prepare("DELETE FROM notifications WHERE id = ? AND user_id = ?");
                $stmt->execute([(int) $notificationId, $userId]);
            }
        } else {
            $error = "Unknown notification action.";
        }

        if ($error === "") {
            redirect(BASE_URL . "/student/notifications.php");
        }
    }
}

$filter = (string) ($_GET["filter"] ?? "all");
if (!in_array($filter, ["all", "unread", "read"], true)) {
    $filter = "all";
}
$page = max(1, (int) ($_GET["page"] ?? 1));
$perPage = 20;
$where = "user_id = ?";
$params = [$userId];
if ($filter === "unread") {
    $where .= " AND is_read = 0";
} elseif ($filter === "read") {
    $where .= " AND is_read = 1";
}

$count = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE $where");
$count->execute($params);
$total = (int) $count->fetchColumn();
$pages = max(1, (int) ceil($total / $perPage));
$page = min($page, $pages);
$offset = ($page - 1) * $perPage;

$list = $pdo->prepare(
    "SELECT id, type, title, message, link_url, is_read, created_at
     FROM notifications
     WHERE $where
     ORDER BY created_at DESC, id DESC
     LIMIT $perPage OFFSET $offset"
);
$list->execute($params);
$notifications = $list->fetchAll(PDO::FETCH_ASSOC);

$unreadStmt = $pdo->prepare(
    "SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0"
);
$unreadStmt->execute([$userId]);
$unreadCount = (int) $unreadStmt->fetchColumn();
?>

<section class="sp-card notification-page-card">
    <div class="notification-page-head">
        <div>
            <h3>Your notifications</h3>
            <p class="sub">Enrollment decisions, document reviews, and application updates appear here.</p>
        </div>
        <?php if ($unreadCount > 0): ?>
            <form method="POST">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="mark_all_read">
                <button type="submit" class="sp-btn secondary small">Mark all as read</button>
            </form>
        <?php endif; ?>
    </div>

    <?php if ($error !== ""): ?><div class="sp-alert error"><?= e($error) ?></div><?php endif; ?>

    <nav class="notification-filters" aria-label="Notification filters">
        <?php foreach (["all" => "All", "unread" => "Unread", "read" => "Read"] as $value => $label): ?>
            <a class="<?= $filter === $value ? "active" : "" ?>" href="?filter=<?= e($value) ?>"><?= e($label) ?></a>
        <?php endforeach; ?>
    </nav>

    <?php if ($notifications): ?>
        <div class="notification-page-list">
            <?php foreach ($notifications as $notice): ?>
                <article class="notification-page-item<?= (int) $notice["is_read"] === 0 ? " unread" : "" ?>">
                    <div class="notification-page-icon" aria-hidden="true"><i class="fas <?= in_array($notice["type"], ["application_approved", "document_verified"], true) ? "fa-check" : (in_array($notice["type"], ["application_rejected", "document_rejected"], true) ? "fa-circle-exclamation" : "fa-bell") ?>"></i></div>
                    <div class="notification-page-body">
                        <div class="notification-page-title-row">
                            <strong><?= e($notice["title"]) ?></strong>
                            <span class="notification-type-label"><?= e(notification_type_label($notice["type"])) ?></span>
                        </div>
                        <p><?= e($notice["message"]) ?></p>
                        <time datetime="<?= e(date(DATE_ATOM, strtotime($notice["created_at"]))) ?>"><?= e(date("M d, Y · g:i A", strtotime($notice["created_at"]))) ?></time>
                        <?php if (!empty($notice["link_url"])): ?>
                            <a class="notification-action-link" href="<?= e(notification_url($notice["link_url"])) ?>">Open related page <i class="fas fa-arrow-right"></i></a>
                        <?php endif; ?>
                    </div>
                    <div class="notification-actions">
                        <?php if ((int) $notice["is_read"] === 0): ?>
                            <form method="POST" class="notification-read-form">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="mark_read">
                                <input type="hidden" name="notification_id" value="<?= (int) $notice["id"] ?>">
                                <button type="submit" class="sp-btn secondary small">Mark read</button>
                            </form>
                        <?php else: ?>
                            <span class="notification-read-label">Read</span>
                        <?php endif; ?>
                        <form method="POST" class="notification-read-form" data-confirm-submit="Delete this notification from your inbox?">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="notification_id" value="<?= (int) $notice["id"] ?>">
                            <button type="submit" class="sp-btn danger small">Delete</button>
                        </form>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>

        <?php if ($pages > 1): ?>
            <div class="notification-pagination">
                <span>Page <?= $page ?> of <?= $pages ?></span>
                <div>
                    <?php if ($page > 1): ?><a class="sp-btn secondary small" href="?<?= e(http_build_query(["filter" => $filter, "page" => $page - 1])) ?>">Previous</a><?php endif; ?>
                    <?php if ($page < $pages): ?><a class="sp-btn secondary small" href="?<?= e(http_build_query(["filter" => $filter, "page" => $page + 1])) ?>">Next</a><?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    <?php else: ?>
        <div class="sp-empty notification-page-empty"><i class="fas fa-bell-slash"></i><p>No notifications in this view.</p></div>
    <?php endif; ?>
</section>

<?php require __DIR__ . "/../includes/student_footer.php"; ?>
