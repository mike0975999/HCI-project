<?php
$pageTitle = "Enrollment Form";
$activeNav = "enroll";
require_once __DIR__ . "/../includes/student_header.php";
require_once __DIR__ . "/../includes/application_audit.php";
require_once __DIR__ . "/../includes/notifications.php";

$uid = (int) $_SESSION["user_id"];
$profile = get_profile($pdo, $uid);
$year = get_active_year($pdo);
$error = "";

$activeYearCount = (int) $pdo->query(
    "SELECT COUNT(*) FROM academic_years WHERE is_active = 1"
)->fetchColumn();

if ($activeYearCount > 1) {
    echo '<div class="sp-card sp-empty"><i class="fas fa-triangle-exclamation"></i>
          <p>Enrollment is temporarily unavailable because the academic-year settings need administrator attention.</p></div>';
    require __DIR__ . "/../includes/student_footer.php";
    exit;
}

if (!$year) {
    echo '<div class="sp-card sp-empty"><i class="fas fa-lock"></i>
          <p>Enrollment is currently closed. Please check back later.</p></div>';
    require __DIR__ . "/../includes/student_footer.php";
    exit;
}

// This project intentionally allows one application per student per academic year.
$stmt = $pdo->prepare(
    "SELECT id, status FROM enrollments WHERE student_id = ? AND academic_year_id = ? LIMIT 1"
);
$stmt->execute([$uid, $year["id"]]);
$existingApplication = $stmt->fetch(PDO::FETCH_ASSOC);
if ($existingApplication) {
    flash(
        "info",
        "You already have an application record for " . $year["name"] . ". " .
        ($existingApplication["status"] === "cancelled"
            ? "Cancelled applications remain in the academic-year record; contact admissions if you need assistance."
            : "You can view its current status and requirements.")
    );
    redirect(BASE_URL . "/student/tracking.php");
}

if (!profile_ready_to_enroll($profile)) {
    flash("info", "Please complete your date of birth, gender and address before applying.");
    redirect(BASE_URL . "/student/profile.php");
}

$stmt = $pdo->prepare(
    "SELECT p.*,
            (SELECT COUNT(*) FROM enrollments e
             WHERE e.program_id = p.id AND e.academic_year_id = ?
               AND e.status IN ('pending','approved')) AS taken
     FROM programs p
     WHERE p.is_active = 1
     ORDER BY p.name"
);
$stmt->execute([$year["id"]]);
$programs = $stmt->fetchAll(PDO::FETCH_ASSOC);

$selected = (int) ($_POST["program_id"] ?? 0);
$level = (int) ($_POST["year_level"] ?? 1);
$semester = (string) ($_POST["semester"] ?? "1st");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $program = null;
    foreach ($programs as $candidate) {
        if ((int) $candidate["id"] === $selected) {
            $program = $candidate;
            break;
        }
    }

    if (!csrf_valid()) {
        $error = "Session expired. Please try again.";
    } elseif (!$program) {
        $error = "Please choose an active program.";
    } elseif ($level < 1 || $level > (int) $program["duration_years"]) {
        $error = "Please choose a valid year level for this program.";
    } elseif (!in_array($semester, ["1st", "2nd", "summer"], true)) {
        $error = "Please choose a valid semester.";
    } elseif (empty($_POST["confirm"])) {
        $error = "Please confirm that your information is correct.";
    } else {
        try {
            $pdo->beginTransaction();

            // Lock and revalidate the active academic year inside the transaction.
            $yearLock = $pdo->prepare(
                "SELECT id, name FROM academic_years WHERE id = ? AND is_active = 1 FOR UPDATE"
            );
            $yearLock->execute([(int) $year["id"]]);
            $lockedYear = $yearLock->fetch(PDO::FETCH_ASSOC);

            if (!$lockedYear) {
                throw new RuntimeException("The active academic year changed. Reload the enrollment form.");
            }

            // Lock the program row so concurrent applications cannot take the last slot.
            $programLock = $pdo->prepare(
                "SELECT id, slots, duration_years
                 FROM programs
                 WHERE id = ? AND is_active = 1
                 FOR UPDATE"
            );
            $programLock->execute([$selected]);
            $lockedProgram = $programLock->fetch(PDO::FETCH_ASSOC);

            if (!$lockedProgram) {
                throw new RuntimeException("The selected program is no longer available.");
            }

            if ($level < 1 || $level > (int) $lockedProgram["duration_years"]) {
                throw new RuntimeException("The selected year level is not valid for this program.");
            }

            $count = $pdo->prepare(
                "SELECT COUNT(*) FROM enrollments
                 WHERE program_id = ? AND academic_year_id = ?
                   AND status IN ('pending','approved')"
            );
            $count->execute([$selected, (int) $lockedYear["id"]]);

            if ((int) $count->fetchColumn() >= (int) $lockedProgram["slots"]) {
                throw new RuntimeException("Sorry, that program has no slots left.");
            }

            $insert = $pdo->prepare(
                "INSERT INTO enrollments
                    (student_id, program_id, academic_year_id, year_level, semester)
                 VALUES (?, ?, ?, ?, ?)"
            );
            $insert->execute([
                $uid,
                $selected,
                (int) $lockedYear["id"],
                $level,
                $semester,
            ]);
            $enrollmentId = (int) $pdo->lastInsertId();

            // Freeze the document rules for this application at submission time.
            $snapshot = $pdo->prepare(
                "INSERT INTO enrollment_requirement_items
                    (enrollment_id, source_requirement_id, name, description, is_required)
                 SELECT ?, id, name, description, is_required
                 FROM requirements
                 WHERE is_active = 1
                 ORDER BY id"
            );
            $snapshot->execute([$enrollmentId]);

            if ($snapshot->rowCount() < 1) {
                throw new RuntimeException("No enrollment document requirements are configured. Please contact admissions.");
            }

            log_application_event(
                $pdo,
                $enrollmentId,
                $uid,
                "application_submitted",
                null,
                "pending",
                "Application submitted for academic year " . $lockedYear["name"] . "."
            );
            create_notification(
                $pdo,
                $uid,
                $enrollmentId,
                "application_submitted",
                "Application submitted",
                "Your enrollment application for " . $lockedYear["name"] . " was received. You can track its progress and upload required documents from your portal.",
                "/student/tracking.php"
            );

            $pdo->commit();

            flash("success", "Application submitted! Your document checklist has been saved for this application.");
            redirect(BASE_URL . "/student/requirements.php");
        } catch (RuntimeException $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = $exception->getMessage();
        } catch (PDOException $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log("Enrollment submission failed: " . $exception->getMessage());
            $error = $exception->getCode() === "23000"
                ? "An application already exists for this academic year. Open your tracking page to review it."
                : "Unable to submit your application. Please try again.";
        }
    }
}
?>

<form method="POST">
    <?= csrf_field() ?>

    <div class="sp-card">
        <h3>1. Choose your program</h3>
        <p class="sub">Academic year <?= e($year["name"]) ?>. Programs with no slots left can't be selected.</p>

        <?php if ($error !== ""): ?>
            <div class="sp-alert error"><?= e($error) ?></div>
        <?php endif; ?>

        <div class="sp-programs">
            <?php foreach ($programs as $p):
                $left = max(0, (int) $p["slots"] - (int) $p["taken"]); ?>
                <label class="sp-program">
                    <input type="radio" name="program_id" value="<?= (int) $p["id"] ?>"
                           <?= $left === 0 ? "disabled" : "" ?>
                           <?= $selected === (int) $p["id"] ? "checked" : "" ?>>
                    <span class="box">
                        <span class="code"><?= e($p["code"]) ?></span>
                        <span class="name"><?= e($p["name"]) ?></span>
                        <span class="desc"><?= e($p["description"]) ?></span>
                        <span class="meta">
                            <span><?= e($p["department"]) ?> &middot; <?= (int) $p["duration_years"] ?> yrs</span>
                            <strong><?= $left > 0 ? "$left slots left" : "Full" ?></strong>
                        </span>
                    </span>
                </label>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="sp-card">
        <h3>2. Year level and semester</h3>
        <p class="sub">This project currently accepts one application per academic year. First-time students should choose 1st year, 1st semester.</p>

        <div class="sp-grid">
            <div class="sp-field">
                <label>Year level</label>
                <select name="year_level">
                    <?php for ($i = 1; $i <= 5; $i++): ?>
                        <option value="<?= $i ?>" <?= $level === $i ? "selected" : "" ?>>Year <?= $i ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="sp-field">
                <label>Semester</label>
                <select name="semester">
                    <?php foreach (["1st" => "1st Semester", "2nd" => "2nd Semester", "summer" => "Summer"] as $v => $l): ?>
                        <option value="<?= e($v) ?>" <?= $semester === $v ? "selected" : "" ?>><?= e($l) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
    </div>

    <div class="sp-card">
        <h3>3. Review and submit</h3>
        <p class="sub">Applying as <strong><?= e($profile["first_name"] . " " . $profile["last_name"]) ?></strong>
            (<?= e($profile["student_number"]) ?>). <a href="profile.php" style="color:#2563eb;">Edit profile</a></p>

        <label style="display:flex;gap:8px;font-size:13px;margin-bottom:18px;">
            <input type="checkbox" name="confirm" value="1" required>
            I confirm that the information I provided is correct.
        </label>

        <button type="submit" class="sp-btn">Submit application</button>
    </div>
</form>

<?php require __DIR__ . "/../includes/student_footer.php"; ?>
