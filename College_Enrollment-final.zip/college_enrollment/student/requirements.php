<?php
$pageTitle = "Requirements";
$activeNav = "requirements";
require_once __DIR__ . "/../includes/student_header.php";
require_once __DIR__ . "/../includes/application_audit.php";
require_once __DIR__ . "/../includes/notifications.php";

$uid = (int) $_SESSION["user_id"];
$enrollment = get_current_enrollment($pdo, $uid);

if (!$enrollment) {
    echo '<div class="sp-card sp-empty"><i class="fas fa-folder-open"></i>
          <p>Submit an enrollment application first, then upload your documents here.</p>
          <a class="sp-btn" href="enroll.php">Go to enrollment form</a></div>';
    require __DIR__ . "/../includes/student_footer.php";
    exit;
}

$enrollmentId = (int) $enrollment["id"];
$canUpload = $enrollment["status"] === "pending";

if ($_SERVER["REQUEST_METHOD"] === "POST" && ($_POST["action"] ?? "") === "remove_document") {
    $itemId = (int) ($_POST["requirement_item_id"] ?? 0);
    $oldRelativePath = null;
    try {
        if (!csrf_valid()) throw new RuntimeException("Session expired. Please try again.");
        if (!$canUpload) throw new RuntimeException("This application is no longer open for document changes.");
        if ($itemId < 1) throw new RuntimeException("Invalid document requirement.");

        $pdo->beginTransaction();
        $applicationLock = $pdo->prepare("SELECT status FROM enrollments WHERE id = ? AND student_id = ? FOR UPDATE");
        $applicationLock->execute([$enrollmentId, $uid]);
        if ($applicationLock->fetchColumn() !== "pending") throw new RuntimeException("This application is no longer open for document changes.");

        $documentLock = $pdo->prepare(
            "SELECT er.id, er.file_path, er.status, eri.name
             FROM enrollment_requirements er
             JOIN enrollment_requirement_items eri ON eri.id = er.requirement_item_id
             WHERE er.enrollment_id = ? AND er.requirement_item_id = ?
             FOR UPDATE"
        );
        $documentLock->execute([$enrollmentId, $itemId]);
        $document = $documentLock->fetch(PDO::FETCH_ASSOC);
        if (!$document || empty($document["file_path"])) throw new RuntimeException("No uploaded file was found for this requirement.");
        if ($document["status"] === "verified") throw new RuntimeException("A verified document cannot be removed. Contact admissions if a correction is necessary.");

        $oldRelativePath = $document["file_path"];
        $remove = $pdo->prepare(
            "UPDATE enrollment_requirements
             SET file_path = NULL, status = 'withdrawn', remarks = 'Removed by student', reviewed_by = NULL, reviewed_at = NULL
             WHERE id = ? AND enrollment_id = ?"
        );
        $remove->execute([(int) $document["id"], $enrollmentId]);
        log_application_event($pdo, $enrollmentId, $uid, "document_removed", $document["status"], "withdrawn", "Student removed uploaded file for " . $document["name"] . ".");
        $pdo->commit();

        $referenceCheck = $pdo->prepare("SELECT COUNT(*) FROM enrollment_requirements WHERE file_path = ?");
        $referenceCheck->execute([$oldRelativePath]);
        if ((int) $referenceCheck->fetchColumn() === 0) delete_stored_file($oldRelativePath);

        flash("success", "The uploaded document was removed. You can upload a replacement while the application is pending.");
    } catch (RuntimeException $exception) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash("error", $exception->getMessage());
    } catch (Throwable $exception) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        error_log("Document removal failed: " . $exception->getMessage());
        flash("error", "The document could not be removed. Please try again.");
    }
    redirect(BASE_URL . "/student/requirements.php");
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $itemId = (int) ($_POST["requirement_item_id"] ?? 0);
    $file = $_FILES["document"] ?? null;
    $uploadError = is_array($file) ? (int) ($file["error"] ?? UPLOAD_ERR_NO_FILE) : UPLOAD_ERR_NO_FILE;
    $fail = "";
    $newRelativePath = null;
    $newAbsolutePath = null;
    $oldRelativePath = null;

    if (!csrf_valid()) {
        $fail = "Session expired. Please try again.";
    } elseif (!$canUpload) {
        $fail = "This application is no longer open for document changes.";
    } elseif (!$file || $uploadError === UPLOAD_ERR_NO_FILE) {
        $fail = "Please choose a file to upload.";
    } elseif ($uploadError !== UPLOAD_ERR_OK) {
        $fail = in_array($uploadError, [UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE], true)
            ? "That file is too large (maximum 5 MB)."
            : "The upload failed. Please try again.";
    } elseif (empty($file["tmp_name"]) || !is_uploaded_file($file["tmp_name"])) {
        $fail = "The uploaded file could not be verified.";
    } elseif ((int) $file["size"] > UPLOAD_MAX_BYTES) {
        $fail = "That file is too large (maximum 5 MB).";
    }

    $requirementItem = null;
    if ($fail === "") {
        $check = $pdo->prepare(
            "SELECT id, source_requirement_id, name
             FROM enrollment_requirement_items
             WHERE id = ? AND enrollment_id = ?
             LIMIT 1"
        );
        $check->execute([$itemId, $enrollmentId]);
        $requirementItem = $check->fetch(PDO::FETCH_ASSOC);
        if (!$requirementItem) {
            $fail = "This document requirement does not belong to your application.";
        } else {
            $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file["tmp_name"]);
            if (!isset(UPLOAD_TYPES[$mime])) {
                $fail = "Only PDF, JPG or PNG files are allowed.";
            }
        }
    }

    if ($fail === "") {
        $fileName = bin2hex(random_bytes(16)) . "." . UPLOAD_TYPES[$mime];
        $newAbsolutePath = upload_dir() . DIRECTORY_SEPARATOR . $fileName;
        $newRelativePath = UPLOAD_DIR_NAME . "/" . $fileName;

        if (!move_uploaded_file($file["tmp_name"], $newAbsolutePath)) {
            $fail = "Could not save the file on the server.";
        } else {
            try {
                $pdo->beginTransaction();

                // Re-check ownership and application status while holding a row lock.
                $applicationLock = $pdo->prepare(
                    "SELECT status FROM enrollments
                     WHERE id = ? AND student_id = ? FOR UPDATE"
                );
                $applicationLock->execute([$enrollmentId, $uid]);
                $lockedStatus = $applicationLock->fetchColumn();

                if ($lockedStatus !== "pending") {
                    throw new RuntimeException("This application is no longer open for document changes.");
                }

                $old = $pdo->prepare(
                    "SELECT id, file_path, status
                     FROM enrollment_requirements
                     WHERE enrollment_id = ? AND requirement_item_id = ?
                     FOR UPDATE"
                );
                $old->execute([$enrollmentId, $itemId]);
                $previous = $old->fetch(PDO::FETCH_ASSOC);

                if ($previous && $previous["status"] === "verified") {
                    throw new RuntimeException("That document was already verified and cannot be replaced.");
                }

                $oldRelativePath = $previous["file_path"] ?? null;
                $action = $oldRelativePath ? "document_replaced" : "document_uploaded";
                $oldStatus = $previous["status"] ?? null;

                $save = $pdo->prepare(
                    "INSERT INTO enrollment_requirements
                        (enrollment_id, requirement_item_id, requirement_id, file_path, status, remarks, reviewed_by, reviewed_at)
                     VALUES (?, ?, ?, ?, 'submitted', NULL, NULL, NULL)
                     ON DUPLICATE KEY UPDATE
                        requirement_id = VALUES(requirement_id),
                        file_path = VALUES(file_path),
                        status = 'submitted',
                        remarks = NULL,
                        reviewed_by = NULL,
                        reviewed_at = NULL,
                        uploaded_at = CURRENT_TIMESTAMP"
                );
                $save->execute([
                    $enrollmentId,
                    $itemId,
                    $requirementItem["source_requirement_id"],
                    $newRelativePath,
                ]);

                log_application_event(
                    $pdo,
                    $enrollmentId,
                    $uid,
                    $action,
                    $oldStatus,
                    "submitted",
                    ($action === "document_replaced" ? "Replaced " : "Uploaded ") . $requirementItem["name"] . "."
                );
                create_notification(
                    $pdo,
                    $uid,
                    $enrollmentId,
                    "document_submitted",
                    $action === "document_replaced" ? "Document replaced" : "Document uploaded",
                    $requirementItem["name"] . " was " . ($action === "document_replaced" ? "replaced" : "uploaded") . " successfully and is waiting for admissions review.",
                    "/student/requirements.php"
                );

                $pdo->commit();

                if ($oldRelativePath && $oldRelativePath !== $newRelativePath) {
                    $references = $pdo->prepare(
                        "SELECT COUNT(*) FROM enrollment_requirements WHERE file_path = ?"
                    );
                    $references->execute([$oldRelativePath]);
                    if ((int) $references->fetchColumn() === 0) {
                        delete_stored_file($oldRelativePath);
                    }
                }

                flash("success", "Document uploaded successfully.");
                redirect(BASE_URL . "/student/requirements.php");
            } catch (RuntimeException $exception) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                if ($newAbsolutePath && is_file($newAbsolutePath)) {
                    @unlink($newAbsolutePath);
                }
                $fail = $exception->getMessage();
            } catch (Throwable $exception) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                if ($newAbsolutePath && is_file($newAbsolutePath)) {
                    @unlink($newAbsolutePath);
                }
                error_log("Requirement upload failed: " . $exception->getMessage());
                $fail = "The document could not be saved. Please try again.";
            }
        }
    }

    flash("error", $fail);
    redirect(BASE_URL . "/student/requirements.php");
}

$stmt = $pdo->prepare(
    "SELECT eri.id AS requirement_item_id, eri.name, eri.description, eri.is_required,
            er.id AS er_id, er.file_path, er.status, er.remarks,
            er.uploaded_at, er.reviewed_at
     FROM enrollment_requirement_items eri
     LEFT JOIN enrollment_requirements er
            ON er.requirement_item_id = eri.id AND er.enrollment_id = eri.enrollment_id
     WHERE eri.enrollment_id = ?
     ORDER BY eri.is_required DESC, eri.id"
);
$stmt->execute([$enrollmentId]);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

[$total, $submitted] = requirement_progress($pdo, $enrollmentId);
$pct = $total > 0 ? (int) round($submitted / $total * 100) : 100;
?>

<div class="sp-card">
    <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;">
        <div>
            <h3><?= e($enrollment["program_name"]) ?> &middot; <?= e($enrollment["academic_year"]) ?></h3>
            <p class="sub" style="margin-bottom:0;">These are the document requirements saved when this application was submitted. Accepted files: PDF, JPG or PNG, up to 5 MB each.</p>
        </div>
        <div><?= status_badge($enrollment["status"]) ?></div>
    </div>
    <div class="sp-progress"><div style="width:<?= $pct ?>%"></div></div>
    <span style="font-size:12px;color:#64748b;"><?= $submitted ?> of <?= $total ?> required documents submitted</span>
</div>

<?php if (!$canUpload): ?>
    <div class="sp-alert info">
        <?php if ($enrollment["status"] === "cancelled"): ?>
            This application was cancelled. Its original requirement checklist is retained for historical reference, but uploads are closed.
        <?php else: ?>
            This application has been <?= e($enrollment["status"]) ?>, so documents can no longer be changed.
        <?php endif; ?>
    </div>
<?php endif; ?>

<div class="sp-card">
    <?php foreach ($rows as $r):
        $state = $r["status"] ?? "missing"; ?>
        <div class="sp-req">
            <div class="info">
                <h4>
                    <?= e($r["name"]) ?>
                    <?= (int) $r["is_required"] ? "" : '<span class="sp-badge optional">Optional</span>' ?>
                    <?= status_badge($state) ?>
                </h4>
                <p><?= e($r["description"] ?? "") ?></p>
                <?php if ($r["er_id"] && $r["file_path"]): ?>
                    <p class="file"><a href="<?= BASE_URL ?>/download.php?id=<?= (int) $r["er_id"] ?>" target="_blank" rel="noopener">View uploaded file</a></p>
                    <?php if ($r["uploaded_at"]): ?><p class="file">Uploaded <?= e(date("M d, Y H:i", strtotime($r["uploaded_at"]))) ?></p><?php endif; ?>
                <?php endif; ?>
                <?php if ($state === "rejected" && $r["remarks"]): ?>
                    <p class="note">Reason: <?= e($r["remarks"]) ?></p>
                <?php endif; ?>
            </div>

            <?php if ($canUpload && $state !== "verified"): ?>
                <div class="sp-document-actions">
                    <form method="POST" enctype="multipart/form-data">
                        <?= csrf_field() ?>
                        <input type="hidden" name="requirement_item_id" value="<?= (int) $r["requirement_item_id"] ?>">
                        <input type="file" name="document" accept=".pdf,.jpg,.jpeg,.png" required>
                        <button type="submit" class="sp-btn small">
                            <?= !empty($r["file_path"]) ? "Replace" : "Upload" ?>
                        </button>
                    </form>
                    <?php if (!empty($r["file_path"])): ?>
                        <form method="POST" data-confirm-submit="Remove this uploaded document? You can upload a replacement while the application is pending.">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="remove_document">
                            <input type="hidden" name="requirement_item_id" value="<?= (int) $r["requirement_item_id"] ?>">
                            <button type="submit" class="sp-btn danger small">Remove</button>
                        </form>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</div>

<?php require __DIR__ . "/../includes/student_footer.php"; ?>
