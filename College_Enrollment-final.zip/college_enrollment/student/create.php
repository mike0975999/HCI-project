<?php
// Legacy URL retained for bookmarked admin links. The maintained CRUD form is admin/student_form.php.
require_once __DIR__ . "/../includes/auth.php";
require_role("admin");
redirect(BASE_URL . "/admin/student_form.php");
