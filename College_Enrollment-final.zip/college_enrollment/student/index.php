<?php
// Legacy URL retained for bookmarked admin links. The maintained CRUD screen is admin/students.php.
require_once __DIR__ . "/../includes/auth.php";
require_role("admin");
redirect(BASE_URL . "/admin/students.php");
