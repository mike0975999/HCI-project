<?php
$pageTitle = "Track Enrollment";
$activeNav = "tracking";
require_once __DIR__ . "/../includes/student_header.php";
require_once __DIR__ . "/../includes/application_audit.php";
require_once __DIR__ . "/../includes/notifications.php";

$uid = (int) $_SESSION["user_id"];

/* ---------- cancel a pending application without deleting its history ---------- */
if ($_SERVER["REQUEST_METHOD"] === "POST" && ($_POST["action"] ?? "") === "cancel") {
    $id = (int) ($_POST["enrollment_id"] ?? 0);

    if (!csrf_valid()) {
        flash("error", "Session expired. Please try again.");
    } else {
        $paths = [];
        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare(
                "SELECT id, status FROM enrollments
                 WHERE id = ? AND student_id = ?
                 FOR UPDATE"
            );
            $stmt->execute([$id, $uid]);
            $application = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$application || $application["status"] !== "pending") {
                throw new RuntimeException("That application cannot be cancelled.");
            }

            $fileStmt = $pdo->prepare(
                "SELECT file_path FROM enrollment_requirements
                 WHERE enrollment_id = ? AND file_path IS NOT NULL
                 FOR UPDATE"
            );
            $fileStmt->execute([$id]);
            $paths = $fileStmt->fetchAll(PDO::FETCH_COLUMN);

            // Keep document rows for history, but detach and remove private file bytes.
            $pdo->prepare(
                "UPDATE enrollment_requirements
                 SET file_path = NULL, status = 'withdrawn'
                 WHERE enrollment_id = ? AND file_path IS NOT NULL"
            )->execute([$id]);

            $pdo->prepare(
                "UPDATE enrollments
                 SET status = 'cancelled',
                     remarks = CASE WHEN remarks IS NULL OR remarks = '' THEN 'Cancelled by student' ELSE remarks END
                 WHERE id = ? AND student_id = ? AND status = 'pending'"
            )->execute([$id, $uid]);

            log_application_event(
                $pdo,
                $id,
                $uid,
                "application_cancelled",
                "pending",
                "cancelled",
                "Student cancelled the application. Uploaded files were removed; the application and audit history were retained."
            );
            create_notification(
                $pdo,
                $uid,
                $id,
                "application_cancelled",
                "Application cancelled",
                "Your application was cancelled. Its history remains available in your enrollment tracking page.",
                "/student/tracking.php"
            );

            $pdo->commit();

            $referenceCheck = $pdo->prepare(
                "SELECT COUNT(*) FROM enrollment_requirements WHERE file_path = ?"
            );
            foreach ($paths as $path) {
                // Do not delete a physical file if another database row still references it.
                $referenceCheck->execute([$path]);
                if ((int) $referenceCheck->fetchColumn() === 0) {
                    delete_stored_file($path);
                }
            }

            flash("success", "Your application was cancelled. Its record and history were retained. Only one application is allowed per academic year, so contact admissions if you need to request a new submission.");
        } catch (RuntimeException $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            flash("error", $exception->getMessage());
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log("Application cancellation failed: " . $exception->getMessage());
            flash("error", "The application could not be cancelled. Please try again.");
        }
    }

    redirect(BASE_URL . "/student/tracking.php");
}

$enrollments = get_enrollments($pdo, $uid);

if (!$enrollments) {
    echo '<div class="sp-card sp-empty"><i class="fas fa-route"></i>
          <p>You have not applied yet.</p>
          <a class="sp-btn" href="enroll.php">Start enrollment</a></div>';
    require __DIR__ . "/../includes/student_footer.php";
    exit;
}

foreach ($enrollments as $en):
    $status = $en["status"];
    [$total, $submitted, $verified] = requirement_progress($pdo, (int) $en["id"]);
    $docsDone = $submitted >= $total;
    $finalized = in_array($status, ["approved", "rejected", "cancelled"], true);
    $decisionClass = $status === "approved" ? "ok" : ($status === "rejected" ? "bad" : "");
?>
<div class="sp-card">
    <div class="sp-track-head">
        <div>
            <h3><?= e($en["program_name"]) ?></h3>
            <p class="sub" style="margin:2px 0 0;"><?= e($en["program_code"]) ?> &middot; Academic year <?= e($en["academic_year"]) ?></p>
        </div>
        <?= status_badge($status) ?>
    </div>

    <div class="sp-steps">
        <div class="sp-step done">
            <div class="dot"><i class="fas fa-check"></i></div>
            Submitted
            <small><?= e(date("M d, Y", strtotime($en["submitted_at"]))) ?></small>
        </div>
        <div class="sp-step <?= $docsDone ? "done" : "current" ?>">
            <div class="dot"><i class="fas <?= $docsDone ? "fa-check" : "fa-folder-open" ?>"></i></div>
            Documents
            <small><?= $submitted ?> / <?= $total ?> required</small>
        </div>
        <div class="sp-step <?= $finalized ? "done" : ($docsDone ? "current" : "") ?>">
            <div class="dot"><i class="fas <?= $finalized ? "fa-check" : "fa-hourglass-half" ?>"></i></div>
            Under review
            <small><?= $finalized ? "Completed" : "Waiting for admissions" ?></small>
        </div>
        <div class="sp-step <?= $decisionClass ?>">
            <div class="dot"><i class="fas <?= $status === "approved" ? "fa-check" : ($status === "rejected" ? "fa-xmark" : ($status === "cancelled" ? "fa-ban" : "fa-flag")) ?>"></i></div>
            Decision
            <small><?= $finalized
                ? e(ucfirst($status) . (($en["reviewed_at"] ?? null) ? " · " . date("M d, Y", strtotime($en["reviewed_at"])) : ($status === "cancelled" ? " · " . date("M d, Y", strtotime($en["updated_at"])) : "")))
                : "Pending" ?></small>
        </div>
    </div>

    <div class="sp-detail">
        <div><span>Year level</span><strong>Year <?= (int) $en["year_level"] ?></strong></div>
        <div><span>Semester</span><strong><?= e(ucfirst($en["semester"])) ?></strong></div>
        <div><span>Documents verified</span><strong><?= $verified ?> / <?= $total ?></strong></div>
        <div><span>Last update</span><strong><?= e(date("M d, Y", strtotime($en["updated_at"]))) ?></strong></div>
    </div>

    <?php if ($status === "approved"): ?>
        <div class="sp-remarks ok"><strong>Congratulations!</strong> Your enrollment was approved.
            <?= $en["remarks"] ? "<br>" . e($en["remarks"]) : "" ?></div>
    <?php elseif ($status === "rejected"): ?>
        <div class="sp-remarks"><strong>Not approved.</strong>
            <?= $en["remarks"] ? e($en["remarks"]) : "Please contact the admissions office for details." ?></div>
    <?php elseif ($status === "cancelled"): ?>
        <div class="sp-remarks"><strong>Application cancelled.</strong>
            The application record and its audit history are retained. A second application for this academic year is not allowed by the current one-application-per-year rule. Contact admissions if you need assistance.</div>
    <?php endif; ?>

    <?php if ($status === "pending"): ?>
        <div style="display:flex;gap:10px;flex-wrap:wrap;">
            <?php if (!$docsDone): ?>
                <a class="sp-btn" href="requirements.php">Upload missing documents</a>
            <?php else: ?>
                <a class="sp-btn secondary" href="requirements.php">View documents</a>
            <?php endif; ?>

            <form method="POST" data-confirm-submit="Cancel this application? The record will be retained, but its uploaded files will be removed.">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="cancel">
                <input type="hidden" name="enrollment_id" value="<?= (int) $en["id"] ?>">
                <button type="submit" class="sp-btn danger">Cancel application</button>
            </form>
        </div>
    <?php endif; ?>
</div>
<?php endforeach; ?>

<?php require __DIR__ . "/../includes/student_footer.php"; ?>
