<?php
$pageTitle = "My Profile";
$activeNav = "profile";
require_once __DIR__ . "/../includes/student_header.php";

$uid     = (int) $_SESSION["user_id"];
$profile = get_profile($pdo, $uid);
$errors  = [];
$pwErrors = [];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $action = $_POST["action"] ?? "";

    if (!csrf_valid()) {
        $errors[] = "Session expired. Please try again.";
    } elseif ($action === "profile") {
        $in = [];
        foreach (["first_name", "last_name", "phone", "birthdate", "gender",
                  "address", "guardian_name", "guardian_phone"] as $k) {
            $in[$k] = trim($_POST[$k] ?? "");
        }
        $phoneRx = '/^[0-9+\-\s()]{7,20}$/';

        if ($in["first_name"] === "" || $in["last_name"] === "") {
            $errors[] = "First and last name are required.";
        }
        if (text_len($in["first_name"]) > 100 || text_len($in["last_name"]) > 100) {
            $errors[] = "Names must be 100 characters or fewer.";
        }
        if ($in["phone"] !== "" && !preg_match($phoneRx, $in["phone"])) {
            $errors[] = "Please enter a valid phone number.";
        }
        if ($in["guardian_phone"] !== "" && !preg_match($phoneRx, $in["guardian_phone"])) {
            $errors[] = "Please enter a valid guardian phone number.";
        }
        if ($in["birthdate"] !== "") {
            $d = DateTime::createFromFormat("Y-m-d", $in["birthdate"]);
            if (!$d || $d->format("Y-m-d") !== $in["birthdate"]) {
                $errors[] = "Please enter a valid date of birth.";
            } elseif ($d > new DateTime("today") || (int) $d->format("Y") < 1900) {
                $errors[] = "Date of birth is not realistic.";
            }
        }
        if ($in["gender"] !== "" && !in_array($in["gender"], ["male", "female", "other"], true)) {
            $errors[] = "Please choose a valid gender option.";
        }
        if (text_len($in["address"]) > 255) {
            $errors[] = "Address must be 255 characters or fewer.";
        }
        if (text_len($in["guardian_name"]) > 150) {
            $errors[] = "Guardian name must be 150 characters or fewer.";
        }

        if (!$errors) {
            try {
                $pdo->beginTransaction();
                $pdo->prepare("UPDATE users SET first_name = ?, last_name = ? WHERE id = ?")
                    ->execute([$in["first_name"], $in["last_name"], $uid]);
                $pdo->prepare(
                    "UPDATE student_profiles
                     SET phone = ?, birthdate = ?, gender = ?, address = ?,
                         guardian_name = ?, guardian_phone = ?
                     WHERE user_id = ?"
                )->execute([
                    $in["phone"] ?: null, $in["birthdate"] ?: null, $in["gender"] ?: null,
                    $in["address"] ?: null, $in["guardian_name"] ?: null,
                    $in["guardian_phone"] ?: null, $uid,
                ]);
                $pdo->commit();

                $_SESSION["name"] = $in["first_name"] . " " . $in["last_name"];
                flash("success", "Profile updated.");
                redirect(BASE_URL . "/student/profile.php");
            } catch (PDOException $ex) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                $errors[] = "Unable to save your profile. Please try again.";
            }
        }
        // show what they typed again
        $profile = array_merge($profile, $in);

    } elseif ($action === "password") {
        $current = $_POST["current_password"] ?? "";
        $new     = $_POST["new_password"] ?? "";
        $confirm = $_POST["confirm_password"] ?? "";

        $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
        $stmt->execute([$uid]);
        $hash = (string) $stmt->fetchColumn();

        if (!password_verify($current, $hash)) {
            $pwErrors[] = "Your current password is incorrect.";
        } elseif (strlen($new) < 8) {
            $pwErrors[] = "New password must be at least 8 characters.";
        } elseif ($new !== $confirm) {
            $pwErrors[] = "New passwords do not match.";
        } else {
            $pdo->prepare("UPDATE users SET password = ? WHERE id = ?")
                ->execute([password_hash($new, PASSWORD_DEFAULT), $uid]);
            session_regenerate_id(true);
            flash("success", "Password changed.");
            redirect(BASE_URL . "/student/profile.php");
        }
    }
}
?>

<form method="POST" class="sp-card">
    <h3>Personal information</h3>
    <p class="sub">Keep this up to date. Fields marked * are needed before you can apply.</p>

    <?php foreach ($errors as $err): ?>
        <div class="sp-alert error"><?= e($err) ?></div>
    <?php endforeach; ?>

    <?= csrf_field() ?>
    <input type="hidden" name="action" value="profile">

    <div class="sp-grid">
        <div class="sp-field">
            <label>First name *</label>
            <input type="text" name="first_name" value="<?= e($profile["first_name"]) ?>" maxlength="100" required>
        </div>
        <div class="sp-field">
            <label>Last name *</label>
            <input type="text" name="last_name" value="<?= e($profile["last_name"]) ?>" maxlength="100" required>
        </div>
        <div class="sp-field">
            <label>Email address</label>
            <input type="email" value="<?= e($profile["email"]) ?>" readonly>
            <p class="sp-hint">Your email is your login and can't be changed here.</p>
        </div>
        <div class="sp-field">
            <label>Student number</label>
            <input type="text" value="<?= e($profile["student_number"]) ?>" readonly>
        </div>
        <div class="sp-field">
            <label>Phone number</label>
            <input type="text" name="phone" value="<?= e($profile["phone"]) ?>" maxlength="20">
        </div>
        <div class="sp-field">
            <label>Date of birth *</label>
            <input type="date" name="birthdate" value="<?= e($profile["birthdate"]) ?>" max="<?= date("Y-m-d") ?>">
        </div>
        <div class="sp-field">
            <label>Gender *</label>
            <select name="gender">
                <option value="">Select...</option>
                <?php foreach (["male" => "Male", "female" => "Female", "other" => "Other"] as $v => $l): ?>
                    <option value="<?= $v ?>" <?= ($profile["gender"] ?? "") === $v ? "selected" : "" ?>><?= $l ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="sp-field full">
            <label>Home address *</label>
            <input type="text" name="address" value="<?= e($profile["address"]) ?>" maxlength="255">
        </div>
        <div class="sp-field">
            <label>Guardian name</label>
            <input type="text" name="guardian_name" value="<?= e($profile["guardian_name"]) ?>" maxlength="150">
        </div>
        <div class="sp-field">
            <label>Guardian phone</label>
            <input type="text" name="guardian_phone" value="<?= e($profile["guardian_phone"]) ?>" maxlength="20">
        </div>
    </div>

    <button type="submit" class="sp-btn">Save changes</button>
</form>

<form method="POST" class="sp-card">
    <h3>Change password</h3>
    <p class="sub">Use at least 8 characters.</p>

    <?php foreach ($pwErrors as $err): ?>
        <div class="sp-alert error"><?= e($err) ?></div>
    <?php endforeach; ?>

    <?= csrf_field() ?>
    <input type="hidden" name="action" value="password">

    <div class="sp-grid">
        <div class="sp-field full" style="max-width:340px;">
            <label>Current password</label>
            <input type="password" name="current_password" autocomplete="current-password" required>
        </div>
        <div class="sp-field">
            <label>New password</label>
            <input type="password" name="new_password" minlength="8" autocomplete="new-password" required>
        </div>
        <div class="sp-field">
            <label>Confirm new password</label>
            <input type="password" name="confirm_password" minlength="8" autocomplete="new-password" required>
        </div>
    </div>

    <button type="submit" class="sp-btn secondary">Update password</button>
</form>

<?php require __DIR__ . "/../includes/student_footer.php"; ?>
