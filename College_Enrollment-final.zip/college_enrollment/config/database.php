<?php

declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| Database configuration
|--------------------------------------------------------------------------
| Local development uses config/database.local.php.
| Production can provide DB_HOST, DB_NAME, DB_USER and DB_PASS as
| environment variables.
|--------------------------------------------------------------------------
*/

$localConfigFile = __DIR__ . "/database.local.php";

if (is_file($localConfigFile)) {
    $config = require $localConfigFile;
} else {
    $config = [
        "host"     => getenv("DB_HOST") ?: "127.0.0.1",
        "dbname"   => getenv("DB_NAME") ?: "college_enrollment",
        "username" => getenv("DB_USER") ?: "",
        "password" => getenv("DB_PASS") ?: "",
    ];
}

$host = (string) ($config["host"] ?? "");
$dbname = (string) ($config["dbname"] ?? "");
$username = (string) ($config["username"] ?? "");
$password = (string) ($config["password"] ?? "");

if ($host === "" || $dbname === "" || $username === "") {
    error_log("Database configuration is incomplete.");
    http_response_code(500);
    exit("The system is not configured correctly. Please contact the administrator.");
}

try {
    $pdo = new PDO(
        "mysql:host={$host};dbname={$dbname};charset=utf8mb4",
        $username,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log("Database connection failed: " . $e->getMessage());
    http_response_code(503);
    exit("The system is temporarily unavailable. Please try again later.");
}
