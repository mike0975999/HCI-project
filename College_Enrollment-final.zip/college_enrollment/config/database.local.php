<?php

/*
 * Local XAMPP development settings.
 * Keep this file out of version control.
 */

return [
    "host" => "127.0.0.1",
    "dbname" => "college_enrollment",
    "username" => "root",
    "password" => "",
];
