<?php

declare(strict_types=1);

require_once __DIR__ . "/includes/auth.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    header("Allow: POST");
    exit("Method Not Allowed");
}

if (!csrf_valid()) {
    http_response_code(403);
    exit("Invalid request.");
}

$wasAdmin = ($_SESSION["role"] ?? "") === "admin";
logout_user();

redirect(BASE_URL . ($wasAdmin ? "/admin/login.php" : "/login.php") . "?loggedout=1");
